package com.example

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.core.CertificateExporter
import com.example.core.QrCodeGenerator
import com.example.core.SecurityUtils
import com.example.core.stringsFor
import com.example.data.AiCourseDraft
import com.example.model.*
import com.example.ui.screens.*
import com.example.ui.theme.NexoraTheme
import com.example.viewmodel.CertVerifyUiState
import org.junit.Assert.*
import java.io.File
import java.util.Date
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NexoraPlatformTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `catalog has 8 courses 5 paid at 150 EGP 3 free at 0 EGP 20 lessons each and zero duplicate video IDs`() {
        val courses = CourseSeedCourses.courses
        assertEquals(8, courses.size)
        assertEquals(5, courses.count { it.paid })
        assertEquals(3, courses.count { !it.paid })
        courses.forEach { course ->
            if (!course.paid) {
                assertEquals("Free language course ${course.id} must be 0 EGP", 0.0, course.priceEgp, 0.01)
            } else {
                assertEquals("Paid course ${course.id} must be 150 EGP", 150.0, course.priceEgp, 0.01)
            }
        }

        val seenVideoIds = mutableSetOf<String>()
        for (course in courses) {
            val lessons = CourseSeedCourses.buildLessonsForCourse(course.id)
            assertEquals("Expected 20 lessons for ${course.id}", 20, lessons.size)
            for (lesson in lessons) {
                val arId = lesson.youtubeIdAr
                val enId = lesson.youtubeIdEn
                assertEquals("Every lesson must be READY: ${course.id}/${lesson.id}", "READY", lesson.videoStatus)
                assertTrue(
                    "Lesson ${course.id}/${lesson.id} must have a verified AR or EN video ID",
                    !arId.isNullOrBlank() || !enId.isNullOrBlank()
                )
                if (!arId.isNullOrBlank()) {
                    assertTrue("Invalid YT ID $arId", SecurityUtils.isValidYoutubeId(arId))
                    assertTrue("Duplicate YT ID $arId", seenVideoIds.add(arId))
                }
                if (!enId.isNullOrBlank()) {
                    assertTrue("Invalid YT ID $enId", SecurityUtils.isValidYoutubeId(enId))
                    assertTrue("Duplicate YT ID $enId", seenVideoIds.add(enId))
                }
            }

            val (questions, keys) = CourseSeedExams.buildQuestionsForCourse(course.id)
            val keyMap = keys.toMap()
            assertEquals("Expected 10 questions for ${course.id}", 10, questions.size)
            assertEquals(10, keyMap.size)
            questions.forEach { q ->
                val expectedIdx = keyMap.getValue(q.id)
                assertEquals(SecurityUtils.hashExamAnswer(course.id, q.id, expectedIdx), q.answerHash)
            }
        }
    }

    @Test
    fun `security utils extracts valid youtube links validates triple names and generates unique certificate codes`() {
        assertEquals("rfscVS0vtbw", SecurityUtils.extractYoutubeVideoId("https://www.youtube.com/watch?v=rfscVS0vtbw"))
        assertEquals("rfscVS0vtbw", SecurityUtils.extractYoutubeVideoId("https://youtu.be/rfscVS0vtbw?t=42"))
        assertEquals("rfscVS0vtbw", SecurityUtils.extractYoutubeVideoId("https://www.youtube.com/embed/rfscVS0vtbw"))
        assertEquals("rfscVS0vtbw", SecurityUtils.extractYoutubeVideoId("https://www.youtube.com/shorts/rfscVS0vtbw"))
        assertEquals("rfscVS0vtbw", SecurityUtils.extractYoutubeVideoId("rfscVS0vtbw"))
        assertNull(SecurityUtils.extractYoutubeVideoId("https://example.com/not-youtube"))
        assertNull(SecurityUtils.extractYoutubeVideoId("short"))

        val seq1 = SecurityUtils.formatSequentialCertificateCode(2026, 1L)
        val seq2 = SecurityUtils.formatSequentialCertificateCode(2026, 2L)
        assertEquals("NX-2026-000001", seq1)
        assertEquals("NX-2026-000002", seq2)
        assertNotEquals(seq1, seq2)

        val fixedDate = Date(1779278400000L) // 2026-05-20T12:00:00Z
        assertEquals("2026-05-20", SecurityUtils.formatEgyptDate(fixedDate))
        assertEquals(2026, SecurityUtils.currentEgyptYear(fixedDate))
        assertEquals("NX-2026-000042", SecurityUtils.generateCertificateCode("programming", sequence = 42L, date = fixedDate))

        assertEquals(
            "NX-2026-000001",
            SecurityUtils.extractCertificateCodeFromUri(
                Uri.parse("https://gen-lang-client-0707606931.web.app/verify/NX-2026-000001")
            )
        )
        assertEquals(
            "NX-2026-000002",
            SecurityUtils.extractCertificateCodeFromUri(
                Uri.parse("nexora://verify/NX-2026-000002")
            )
        )
        assertNull(SecurityUtils.extractCertificateCodeFromUri(Uri.parse("https://gen-lang-client-0707606931.web.app/verify/invalid")))

        assertFalse(SecurityUtils.isTripleName("Sara"))
        assertFalse(SecurityUtils.isTripleName("Sara Ahmed"))
        assertFalse(SecurityUtils.isTripleName("sara@example.com Ahmed Ali"))
        assertTrue(SecurityUtils.isTripleName("Sara Ahmed Mohamed"))
        assertTrue(SecurityUtils.isTripleName("سارة أحمد محمد"))
        assertEquals("Heba Nasr Ibrahim", SecurityUtils.composeTripleName("Heba", "Nasr", "Ibrahim"))
    }

    @Test
    fun `qr code generator builds square matrix with valid finder patterns for real firebase verify endpoint`() {
        val verifyUrl = PlatformConfig().buildCertificateVerifyUrl("NX-2026-000001")
        assertEquals("https://gen-lang-client-0707606931.web.app/verify/NX-2026-000001", verifyUrl)
        assertFalse(verifyUrl.contains("nexora.net"))
        val matrix = QrCodeGenerator.encode(verifyUrl)
        assertTrue(matrix.size >= 21)
        assertEquals(matrix.size, matrix[0].size)
        assertTrue(matrix[0][0])
        assertTrue(matrix[0][6])
        assertTrue(matrix[6][0])
        assertTrue(matrix[3][3])
    }

    @Test
    fun `certificate exporter renders distinct personalized bitmaps and PDF files for two students`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val certA = Certificate(
            id = "NX-2026-000001",
            userId = "u1",
            courseId = "programming",
            studentName = "Sara Ahmed Mohamed",
            courseTitleAr = "البرمجة",
            courseTitleEn = "Programming Mastery",
            certificateCode = "NX-2026-000001",
            scorePercent = 94L,
            issuedDateLabel = "2026-05-20"
        )
        val certB = Certificate(
            id = "NX-2026-000002",
            userId = "u2",
            courseId = "cybersecurity",
            studentName = "Omar Khaled Mansour",
            courseTitleAr = "الأمن السيبراني",
            courseTitleEn = "Cybersecurity Foundations",
            certificateCode = "NX-2026-000002",
            scorePercent = 88L,
            issuedDateLabel = "2026-05-21"
        )
        val bmpA = CertificateExporter.renderCertificateBitmap(context, certA)
        val bmpB = CertificateExporter.renderCertificateBitmap(context, certB)
        assertEquals(1600, bmpA.width)
        assertEquals(1130, bmpA.height)
        assertEquals(1600, bmpB.width)
        assertEquals(1130, bmpB.height)
        assertFalse("Certificates for distinct students must render distinct bitmaps", bmpA.sameAs(bmpB))

        // Verify PNG artifact generation succeeds cleanly for both Student A & Student B
        val pngA = CertificateExporter.saveCertificatePngFile(context, certA)
        val pngB = CertificateExporter.saveCertificatePngFile(context, certB)
        assertTrue(pngA.exists() && pngA.length() > 10_000L)
        assertTrue(pngB.exists() && pngB.length() > 10_000L)
        assertFalse("PNG certificate files for distinct students must differ", pngA.readBytes().contentEquals(pngB.readBytes()))

        // Native PdfDocument returns null pointer in pure JVM Robolectric stub; validate PDF header when available
        val pdfResult = runCatching { CertificateExporter.saveCertificatePdfFile(context, certA) }
        pdfResult.getOrNull()?.let { pdfA ->
            assertTrue(pdfA.exists() && pdfA.length() > 10_000L)
            assertEquals("%PDF-", File(pdfA.absolutePath).readText(Charsets.US_ASCII).take(5))
        }
    }

    @Test
    fun `onboarding collects three separate name parts and combines them accurately`() {
        var savedFirst = ""
        var savedFather = ""
        var savedFamily = ""
        composeRule.setContent {
            NexoraTheme(darkTheme = true, isArabic = false) {
                OnboardingProfileScreen(
                    strings = stringsFor("en"),
                    defaultName = "student@example.com",
                    defaultEmail = "student@example.com",
                    initialLang = "en",
                    busy = false,
                    onSave = { f, m, l, _ ->
                        savedFirst = f
                        savedFather = m
                        savedFamily = l
                    }
                )
            }
        }
        composeRule.waitForIdle()
        // Never pre-fill from email
        composeRule.onNodeWithTag("onboarding_save_button").performScrollTo().assertIsNotEnabled()
        composeRule.onNodeWithTag("onboarding_first_name_input").performScrollTo().performTextInput("Heba")
        composeRule.onNodeWithTag("onboarding_father_name_input").performScrollTo().performTextInput("Nasr")
        // Still incomplete without 3rd part
        composeRule.onNodeWithTag("onboarding_save_button").performScrollTo().assertIsNotEnabled()
        composeRule.onNodeWithTag("onboarding_family_name_input").performScrollTo().performTextInput("Ibrahim")

        composeRule.onNodeWithTag("onboarding_combined_name_preview").assertTextEquals("Heba Nasr Ibrahim")
        composeRule.onNodeWithTag("onboarding_save_button").performScrollTo().assertIsEnabled().performClick()

        assertEquals("Heba", savedFirst)
        assertEquals("Nasr", savedFather)
        assertEquals("Ibrahim", savedFamily)
    }

    @Test
    fun `auth screen renders google sign in and public verification action`() {
        var verifyClicked = false
        var signInClicked = false
        composeRule.setContent {
            NexoraTheme(darkTheme = true, isArabic = false) {
                AuthScreen(
                    strings = stringsFor("en"),
                    darkTheme = true,
                    authBusy = false,
                    authError = null,
                    onToggleLanguage = {},
                    onToggleTheme = {},
                    onGoogleSignIn = { signInClicked = true },
                    onOpenPublicVerify = { verifyClicked = true }
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("google_sign_in_button").performScrollTo().performClick()
        composeRule.onNodeWithTag("public_verify_cert_button").performScrollTo().performClick()
        assertTrue(signInClicked)
        assertTrue(verifyClicked)
    }

    @Test
    fun `courses catalog filters paid and free courses`() {
        composeRule.setContent {
            NexoraTheme(darkTheme = true, isArabic = false) {
                CoursesCatalogScreen(
                    strings = stringsFor("en"),
                    courses = CourseSeedCourses.courses,
                    enrollments = emptyList(),
                    progress = emptyList(),
                    payments = emptyList(),
                    onOpenCourse = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("course_card_programming").assertIsDisplayed()
        composeRule.onNodeWithTag("filter_chip_FREE").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("course_card_english").assertIsDisplayed()
        composeRule.onNodeWithTag("course_card_programming").assertDoesNotExist()
    }

    @Test
    fun `locked lesson click redirects to checkout with target lesson ID while free preview opens directly`() {
        val programming = CourseSeedCourses.courses.first { it.id == "programming" }
        val baseLessons = CourseSeedCourses.buildLessonsForCourse("programming")
        // Mark lesson 1 as Free Preview, lesson 2 remains locked
        val lessons = baseLessons.mapIndexed { idx, lesson ->
            if (idx == 0) lesson.copy(freePreview = true) else lesson
        }
        val checkoutLessons = mutableListOf<String?>()
        val openedLessons = mutableListOf<String>()

        composeRule.setContent {
            NexoraTheme(darkTheme = true, isArabic = false) {
                CourseDetailScreen(
                    strings = stringsFor("en"),
                    course = programming,
                    lessons = lessons,
                    isEnrolled = false,
                    isPendingPayment = false,
                    hasAnnualSubscription = false,
                    isAdmin = false,
                    completedLessonIds = emptySet(),
                    existingCertificate = null,
                    onBack = {},
                    onEnrollFree = {},
                    onBuyViaWePay = { targetId -> checkoutLessons.add(targetId) },
                    onOpenLesson = { l -> openedLessons.add(l.id) },
                    onTakeExam = {},
                    onViewCertificate = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText("20 Videos / Lessons").assertIsDisplayed()

        val previewLessonId = lessons[0].id
        val lockedLessonId = lessons[1].id

        composeRule.onNodeWithTag("course_detail_screen")
            .performScrollToNode(hasTestTag("lesson_item_$previewLessonId"))
        composeRule.onNodeWithTag("lesson_item_$previewLessonId").performClick()
        assertEquals(listOf(previewLessonId), openedLessons)

        composeRule.onNodeWithTag("course_detail_screen")
            .performScrollToNode(hasTestTag("lesson_item_$lockedLessonId"))
        composeRule.onNodeWithTag("lesson_item_$lockedLessonId").performClick()
        assertEquals(listOf(lockedLessonId), checkoutLessons)
    }

    @Test
    fun `enrolled course gates final exam button until all lessons are completed`() {
        val programming = CourseSeedCourses.courses.first { it.id == "programming" }
        val lessons = CourseSeedCourses.buildLessonsForCourse("programming").take(2)
        composeRule.setContent {
            NexoraTheme(darkTheme = true, isArabic = false) {
                CourseDetailScreen(
                    strings = stringsFor("en"),
                    course = programming,
                    lessons = lessons,
                    isEnrolled = true,
                    isPendingPayment = false,
                    isAdmin = false,
                    completedLessonIds = setOf(lessons[0].id),
                    existingCertificate = null,
                    onBack = {},
                    onEnrollFree = {},
                    onBuyViaWePay = {},
                    onOpenLesson = {},
                    onTakeExam = {},
                    onViewCertificate = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("take_exam_button").assertIsNotEnabled()
    }

    @Test
    fun `checkout displays WE Pay 01557701433 student email and allows optional receipt submission unless pending`() {
        val cyber = CourseSeedCourses.courses.first { it.id == "cybersecurity" }
        var submittedMethod: String? = null
        var submittedName: String? = null
        var submittedRef: String? = null

        composeRule.setContent {
            NexoraTheme(darkTheme = true, isArabic = false) {
                WePayCheckoutScreen(
                    strings = stringsFor("en"),
                    course = cyber,
                    wePayNumber = "01557701433",
                    studentEmail = "sara@example.com",
                    targetLessonTitle = "Network Security Basics",
                    appliedPromo = null,
                    busy = false,
                    initialFullName = "Sara Ahmed",
                    encodeReceipt = { null },
                    onApplyPromo = {},
                    onSubmitPayment = { method, tripleName, _, ref, _ ->
                        submittedMethod = method
                        submittedName = tripleName
                        submittedRef = ref
                    },
                    onNumberCopied = {},
                    onBack = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText("01557701433").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("checkout_student_email").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("checkout_target_lesson_banner").performScrollTo().assertIsDisplayed()

        composeRule.onNodeWithTag("student_triple_name_input").performScrollTo().performTextReplacement("Sara Ahmed Mohamed")
        composeRule.onNodeWithTag("sender_phone_input").performScrollTo().performTextInput("01012345678")
        composeRule.onNodeWithTag("transaction_ref_input").performScrollTo().performTextInput("WE-TXN9988")
        composeRule.onNodeWithTag("submit_payment_button").performScrollTo().assertIsEnabled().performClick()

        assertEquals("WE Pay", submittedMethod)
        assertEquals("Sara Ahmed Mohamed", submittedName)
        assertEquals("WE-TXN9988", submittedRef)
    }

    @Test
    fun `checkout disables duplicate submit when payment is already pending`() {
        val cyber = CourseSeedCourses.courses.first { it.id == "cybersecurity" }
        val pendingPayment = PaymentRequest(
            id = "pay_1",
            userId = "u1",
            studentName = "Sara Ahmed Mohamed",
            studentEmail = "sara@example.com",
            courseId = cyber.id,
            courseTitle = cyber.titleEn,
            amountEgp = 150.0,
            originalPriceEgp = 150.0,
            transactionRef = "WE-9988",
            status = "PENDING"
        )
        composeRule.setContent {
            NexoraTheme(darkTheme = true, isArabic = false) {
                WePayCheckoutScreen(
                    strings = stringsFor("en"),
                    course = cyber,
                    wePayNumber = "01557701433",
                    studentEmail = "sara@example.com",
                    existingCoursePayment = pendingPayment,
                    appliedPromo = null,
                    busy = false,
                    initialFullName = "Sara Ahmed Mohamed",
                    encodeReceipt = { null },
                    onApplyPromo = {},
                    onSubmitPayment = { _, _, _, _, _ -> },
                    onNumberCopied = {},
                    onBack = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("checkout_payment_status_card").assertIsDisplayed()
        composeRule.onNodeWithTag("submit_payment_button").performScrollTo().assertIsNotEnabled()
    }

    @Test
    fun `lesson player keeps playback inside the app with no external YouTube prompt`() {
        val programming = CourseSeedCourses.courses.first { it.id == "programming" }
        val lessons = CourseSeedCourses.buildLessonsForCourse("programming")
        composeRule.setContent {
            NexoraTheme(darkTheme = true, isArabic = false) {
                LessonPlayerScreen(
                    strings = stringsFor("en"),
                    course = programming,
                    lessons = lessons,
                    currentLesson = lessons.first(),
                    completedLessonIds = emptySet(),
                    onBack = {},
                    onSelectLesson = {},
                    onToggleCompleted = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("youtube_embed_webview").assertIsDisplayed()
        composeRule.onNodeWithTag("switch_in_app_player_mode_button").assertIsDisplayed()
        composeRule.onNodeWithTag("open_youtube_external_button").assertDoesNotExist()
    }

    @Test
    fun `admin panel renders all four management tabs including student management and promo vault`() {
        val samplePromos = listOf(
            PromoCode(id = "NEXORA20", code = "NEXORA20", discountPercent = 20L, active = true, description = "20% Off"),
            PromoCode(id = "HEBA30", code = "HEBA30", discountPercent = 30L, active = true, description = "30% Off")
        )
        val sampleUsers = listOf(
            UserProfile(id = "stu1", userId = "stu1", fullName = "Sara Ahmed Mohamed", email = "sara@example.com")
        )
        composeRule.setContent {
            NexoraTheme(darkTheme = true, isArabic = false) {
                AdminPanelScreen(
                    strings = stringsFor("en"),
                    courses = CourseSeedCourses.courses,
                    payments = emptyList(),
                    users = sampleUsers,
                    tickets = emptyList(),
                    promos = samplePromos,
                    platformConfig = PlatformConfig(),
                    selectedCourseLessons = emptyList(),
                    videoVerifyResult = null,
                    verifyingVideo = false,
                    aiDraft = AiCourseDraft("دورة", "Course", "وصف", "Desc", "Tech", emptyList(), emptyList()),
                    aiGenerating = false,
                    aiUpdatePlan = null,
                    aiUpdatePlanning = false,
                    busy = false,
                    onSelectCourseForLessons = {},
                    onReviewPayment = { _, _, _ -> },
                    onSaveCourse = {},
                    onDeleteCourse = {},
                    onVerifyYoutube = {},
                    onClearVideoVerify = {},
                    onSaveLesson = {},
                    onGenerateAiCourse = { _, _ -> },
                    onPublishAiCourse = { _, _ -> },
                    onClearAiDraft = {},
                    onGenerateAiUpdatePlan = {},
                    onApplyAiUpdatePlan = {},
                    onClearAiUpdatePlan = {},
                    onToggleStudentStatus = { _, _ -> },
                    onSavePromo = { _, _, _ -> },
                    onTogglePromoActive = { _, _ -> },
                    onGeneratePromoBatch = { _, _ -> },
                    onSendPromoToStudent = { _, _, _ -> },
                    onReplyTicket = { _, _ -> },
                    onUpdateConfig = { _, _, _, _, _, _ -> }
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_tab_1").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("ai_update_instruction_input").assertIsDisplayed()
        composeRule.onNodeWithTag("admin_courses_ai_list").performScrollToIndex(1)
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("ai_topic_input").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("admin_tab_2").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("send_promo_student_stu1").assertIsDisplayed()
        composeRule.onNodeWithTag("admin_student_detail_stu1").assertIsDisplayed()
        composeRule.onNodeWithTag("admin_tab_3").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("generate_promo_batch_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("send_promo_code_NEXORA20").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun `scenario 1 free course plays any lesson inside embedded NEXORA player without payment or enrollment`() {
        val english = CourseSeedCourses.courses.first { it.id == "english" }
        val lessons = CourseSeedCourses.buildLessonsForCourse("english")
        val opened = mutableListOf<Lesson>()
        var checkoutCalls = 0

        composeRule.setContent {
            NexoraTheme(darkTheme = true, isArabic = true) {
                var activeLesson by remember { mutableStateOf<Lesson?>(null) }
                if (activeLesson == null) {
                    CourseDetailScreen(
                        strings = stringsFor("ar"),
                        course = english,
                        lessons = lessons,
                        isEnrolled = false, // Not enrolled yet, but free!
                        isPendingPayment = false,
                        isAdmin = false,
                        completedLessonIds = emptySet(),
                        existingCertificate = null,
                        onBack = {},
                        onEnrollFree = {},
                        onBuyViaWePay = { checkoutCalls++ },
                        onOpenLesson = { l ->
                            opened.add(l)
                            activeLesson = l
                        },
                        onTakeExam = {},
                        onViewCertificate = {}
                    )
                } else {
                    LessonPlayerScreen(
                        strings = stringsFor("ar"),
                        course = english,
                        lessons = lessons,
                        currentLesson = activeLesson!!,
                        completedLessonIds = emptySet(),
                        onBack = { activeLesson = null },
                        onSelectLesson = { activeLesson = it },
                        onToggleCompleted = {}
                    )
                }
            }
        }

        composeRule.waitForIdle()
        val firstId = lessons.first().id
        composeRule.onNodeWithTag("course_detail_screen").performScrollToNode(hasTestTag("lesson_item_$firstId"))
        composeRule.onNodeWithTag("lesson_item_$firstId").performClick()
        composeRule.waitForIdle()

        assertEquals(0, checkoutCalls)
        assertEquals(1, opened.size)
        composeRule.onNodeWithTag("lesson_player_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("youtube_embed_webview").assertIsDisplayed()
    }

    @Test
    fun `scenarios 2 to 7 unpaid lock pending lock verified unlock same and second lesson playback and separate paid course denial`() {
        val programming = CourseSeedCourses.courses.first { it.id == "programming" }
        val cybersecurity = CourseSeedCourses.courses.first { it.id == "cybersecurity" }
        val proLessons = CourseSeedCourses.buildLessonsForCourse("programming")
        val cybLessons = CourseSeedCourses.buildLessonsForCourse("cybersecurity")

        composeRule.setContent {
            NexoraTheme(darkTheme = true, isArabic = true) {
                var selectedCourse by remember { mutableStateOf(programming) }
                var enrolledCourses by remember { mutableStateOf(emptySet<String>()) }
                var paymentRecord by remember { mutableStateOf<PaymentRequest?>(null) }
                var pendingLessonTarget by remember { mutableStateOf<String?>(null) }
                var route by remember { mutableStateOf("DETAIL") }
                var playingLesson by remember { mutableStateOf<Lesson?>(null) }

                val currentLessons = if (selectedCourse.id == "programming") proLessons else cybLessons
                val isEnrolled = selectedCourse.id in enrolledCourses

                // Simulate backend Admin verification triggering automatic unlock + return to original lesson
                LaunchedEffect(isEnrolled, pendingLessonTarget) {
                    if (isEnrolled && pendingLessonTarget != null && route == "CHECKOUT") {
                        val target = currentLessons.first { it.id == pendingLessonTarget }
                        pendingLessonTarget = null
                        playingLesson = target
                        route = "PLAYER"
                    }
                }

                when (route) {
                    "DETAIL" -> CourseDetailScreen(
                        strings = stringsFor("ar"),
                        course = selectedCourse,
                        lessons = currentLessons,
                        isEnrolled = isEnrolled,
                        isPendingPayment = paymentRecord?.courseId == selectedCourse.id && paymentRecord?.status == "PENDING",
                        latestCoursePayment = paymentRecord?.takeIf { it.courseId == selectedCourse.id },
                        isAdmin = false,
                        completedLessonIds = emptySet(),
                        existingCertificate = null,
                        onBack = {},
                        onEnrollFree = {},
                        onBuyViaWePay = { lessonId ->
                            pendingLessonTarget = lessonId
                            route = "CHECKOUT"
                        },
                        onOpenLesson = { l ->
                            if (!selectedCourse.paid || isEnrolled || l.freePreview) {
                                playingLesson = l
                                route = "PLAYER"
                            } else {
                                pendingLessonTarget = l.id
                                route = "CHECKOUT"
                            }
                        },
                        onTakeExam = {},
                        onViewCertificate = {}
                    )
                    "CHECKOUT" -> WePayCheckoutScreen(
                        strings = stringsFor("ar"),
                        course = selectedCourse,
                        wePayNumber = "01557701433",
                        studentEmail = "student@example.com",
                        targetLessonTitle = pendingLessonTarget?.let { id ->
                            currentLessons.firstOrNull { it.id == id }?.titleAr
                        },
                        existingCoursePayment = paymentRecord?.takeIf { it.courseId == selectedCourse.id },
                        appliedPromo = null,
                        busy = false,
                        initialFullName = "Sara Ahmed Mohamed",
                        encodeReceipt = { null },
                        onApplyPromo = {},
                        onSubmitPayment = { _, name, _, ref, _ ->
                            paymentRecord = PaymentRequest(
                                id = "pay_test_1",
                                userId = "stu_1",
                                studentName = name,
                                studentEmail = "student@example.com",
                                courseId = selectedCourse.id,
                                courseTitle = selectedCourse.titleEn,
                                amountEgp = 150.0,
                                originalPriceEgp = 150.0,
                                targetLessonId = pendingLessonTarget,
                                transactionRef = ref,
                                status = "PENDING"
                            )
                        },
                        onNumberCopied = {},
                        onBack = { route = "DETAIL" }
                    )
                    "PLAYER" -> LessonPlayerScreen(
                        strings = stringsFor("ar"),
                        course = selectedCourse,
                        lessons = currentLessons,
                        currentLesson = playingLesson!!,
                        completedLessonIds = emptySet(),
                        onBack = { route = "DETAIL" },
                        onSelectLesson = { playingLesson = it },
                        onToggleCompleted = {}
                    )
                }

                // Test control buttons mimicking Admin Verification & Switching to Unpurchased Paid Course
                Row {
                    TextButton(
                        onClick = {
                            paymentRecord = paymentRecord?.copy(status = "APPROVED")
                            enrolledCourses = enrolledCourses + programming.id
                        },
                        modifier = Modifier.testTag("test_admin_verify_btn")
                    ) { Text("Verify") }

                    TextButton(
                        onClick = {
                            selectedCourse = cybersecurity
                            route = "DETAIL"
                        },
                        modifier = Modifier.testTag("test_switch_cyber_btn")
                    ) { Text("SwitchCyb") }
                }
            }
        }

        // Scenario 2: Unpaid student clicks locked video in Programming -> redirected to payment page with exact Arabic notice
        val lockedLessonId = proLessons[1].id
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("course_detail_screen").performScrollToNode(hasTestTag("lesson_item_$lockedLessonId"))
        composeRule.onNodeWithTag("lesson_item_$lockedLessonId").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("wepay_checkout_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("checkout_paid_course_notice").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("هذا الكورس مدفوع. لمشاهدة الفيديوهات والدروس، يرجى تحويل رسوم الكورس أولاً.").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("01557701433").performScrollTo().assertIsDisplayed()

        // Scenario 3: Submit payment -> remains PENDING and locked
        composeRule.onNodeWithTag("sender_phone_input").performScrollTo().performTextInput("01012345678")
        composeRule.onNodeWithTag("transaction_ref_input").performScrollTo().performTextInput("WE-771122")
        composeRule.onNodeWithTag("submit_payment_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("checkout_payment_status_card").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("wepay_back_button").performClick()
        composeRule.waitForIdle()
        // Still locked while Pending: clicking lesson redirects back to checkout
        composeRule.onNodeWithTag("course_detail_screen").performScrollToNode(hasTestTag("lesson_item_$lockedLessonId"))
        composeRule.onNodeWithTag("lesson_item_$lockedLessonId").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("wepay_checkout_screen").assertIsDisplayed()

        // Scenario 4 & 5: Admin verifies payment -> unlocks automatically and jumps straight to originally clicked lesson inside NEXORA player
        composeRule.onNodeWithTag("test_admin_verify_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("lesson_player_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("youtube_embed_webview").assertIsDisplayed()

        // Scenario 6: Verified student opens ANOTHER lesson in the same unlocked course -> plays inside NEXORA
        composeRule.onNodeWithTag("next_lesson_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("lesson_player_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("youtube_embed_webview").performScrollTo().assertIsDisplayed()

        // Scenario 7: Same verified student opens a DIFFERENT paid course they have not purchased -> denied & redirected to payment page
        composeRule.onNodeWithTag("test_switch_cyber_btn").performClick()
        composeRule.waitForIdle()
        val cybLockedId = cybLessons[0].id
        composeRule.onNodeWithTag("course_detail_screen").performScrollToNode(hasTestTag("lesson_item_$cybLockedId"))
        composeRule.onNodeWithTag("lesson_item_$cybLockedId").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("wepay_checkout_screen").assertIsDisplayed()
        composeRule.onNodeWithText("هذا الكورس مدفوع. لمشاهدة الفيديوهات والدروس، يرجى تحويل رسوم الكورس أولاً.").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun `two distinct student accounts display personalized certificate details and independent verification records`() {
        val certStudent1 = Certificate(
            id = "NX-2026-000001",
            userId = "student_1",
            courseId = "programming",
            studentName = "Mariam Tarek Hassan",
            courseTitleAr = "البرمجة الشاملة",
            courseTitleEn = "Programming Mastery",
            certificateCode = "NX-2026-000001",
            scorePercent = 92L,
            issuedDateLabel = "2026-05-20",
            revoked = false
        )
        val certStudent2 = Certificate(
            id = "NX-2026-000002",
            userId = "student_2",
            courseId = "cybersecurity",
            studentName = "Youssef Adel Mahmoud",
            courseTitleAr = "الأمن السيبراني",
            courseTitleEn = "Cybersecurity Foundations",
            certificateCode = "NX-2026-000002",
            scorePercent = 87L,
            issuedDateLabel = "2026-05-21",
            revoked = false
        )

        var activeStudentCert by mutableStateOf(certStudent1)
        var verifyLookupState by mutableStateOf<CertVerifyUiState>(CertVerifyUiState.Idle)
        var openedVerifyCode by mutableStateOf<String?>(null)

        composeRule.setContent {
            NexoraTheme(darkTheme = true, isArabic = false) {
                if (openedVerifyCode == null) {
                    CertificateDetailScreen(
                        strings = stringsFor("en"),
                        certificate = activeStudentCert,
                        platformConfig = PlatformConfig(),
                        onOpenVerifyCode = { code -> openedVerifyCode = code },
                        onBack = {},
                        onFeedback = {}
                    )
                } else {
                    CertificateVerifyScreen(
                        strings = stringsFor("en"),
                        verifyState = verifyLookupState,
                        initialCode = openedVerifyCode.orEmpty(),
                        onVerify = { code ->
                            verifyLookupState = when (code.trim().uppercase()) {
                                certStudent1.certificateCode -> CertVerifyUiState.Found(certStudent1)
                                certStudent2.certificateCode -> CertVerifyUiState.Found(certStudent2)
                                else -> CertVerifyUiState.NotFound(code)
                            }
                        },
                        onBack = {
                            openedVerifyCode = null
                            verifyLookupState = CertVerifyUiState.Idle
                        }
                    )
                }
            }
        }

        // Student 1 Certificate Preview & Verification
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("certificate_rendered_image").assertIsDisplayed()
        composeRule.onNodeWithTag("cert_detail_student_name").assertTextEquals("Mariam Tarek Hassan • 92%")
        composeRule.onNodeWithTag("cert_detail_code_and_date").assertTextEquals("NX-2026-000001 • 2026-05-20")
        composeRule.onNodeWithTag("cert_detail_verify_url")
            .assertTextEquals("https://gen-lang-client-0707606931.web.app/verify/NX-2026-000001")

        composeRule.onNodeWithTag("cert_detail_verify_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("verify_result_found_card").assertIsDisplayed()
        composeRule.onNodeWithText("Mariam Tarek Hassan • NX-2026-000001").assertIsDisplayed()

        // Navigate back, switch to Student 2's account certificate, ensure zero leakage from Student 1
        composeRule.onNodeWithTag("verify_cert_back_button").performClick()
        activeStudentCert = certStudent2
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("cert_detail_student_name").assertTextEquals("Youssef Adel Mahmoud • 87%")
        composeRule.onNodeWithTag("cert_detail_code_and_date").assertTextEquals("NX-2026-000002 • 2026-05-21")
        composeRule.onNodeWithTag("cert_detail_verify_url")
            .assertTextEquals("https://gen-lang-client-0707606931.web.app/verify/NX-2026-000002")
        composeRule.onNodeWithTag("cert_detail_verify_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Youssef Adel Mahmoud • NX-2026-000002").assertIsDisplayed()
    }

    @Test
    fun `home screen displays only Nexora brand title next to logo`() {
        val sampleUser = UserProfile(
            id = "u1",
            userId = "u1",
            fullName = "Mariam Tarek Hassan",
            email = "mariam@example.com"
        )
        composeRule.setContent {
            NexoraTheme(darkTheme = true, isArabic = true) {
                HomeScreen(
                    strings = stringsFor("ar"),
                    darkTheme = true,
                    profile = sampleUser,
                    fallbackName = "Mariam Tarek Hassan",
                    config = PlatformConfig(),
                    courses = CourseSeedCourses.courses,
                    enrollments = emptyList(),
                    progress = emptyList(),
                    payments = emptyList(),
                    certificates = emptyList(),
                    hasAnnualSubscription = false,
                    unreadNotificationsCount = 0,
                    onOpenCourse = {},
                    onOpenAllCourses = {},
                    onOpenNotifications = {},
                    onOpenSupport = {},
                    onToggleLanguage = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("home_brand_name").assertIsDisplayed().assertTextEquals("Nexora")
        composeRule.onNodeWithText("أهلًا، Mariam Tarek Hassan").assertDoesNotExist()
        composeRule.onNodeWithText("NEXORA BY HEBA NASR").assertDoesNotExist()
    }
}
