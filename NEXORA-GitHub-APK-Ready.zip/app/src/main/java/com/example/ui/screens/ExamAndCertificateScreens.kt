package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.AppStrings
import com.example.core.CertificateExporter
import com.example.core.QrCodeGenerator
import com.example.core.SecurityUtils
import com.example.model.Certificate
import com.example.model.Course
import com.example.model.ExamAttempt
import com.example.model.ExamQuestion
import com.example.ui.components.NexoraLogoBadge
import com.example.ui.components.QrCodeMatrixCanvas
import com.example.ui.components.StatusPill
import com.example.viewmodel.CertVerifyUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExamScreen(
    strings: AppStrings,
    course: Course,
    questions: List<ExamQuestion>,
    busy: Boolean,
    onBack: () -> Unit,
    onSubmit: (Map<String, Int>) -> Unit
) {
    BackHandler(onBack = onBack)

    val answers = remember(course.id) { mutableStateMapOf<String, Int>() }

    Scaffold(
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                title = { Text("${strings.examTitle}: ${if (strings.isArabic) course.titleAr else course.titleEn}") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("exam_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("exam_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = strings.examNoTimerNote,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = strings.examHiddenAnswersNote,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            items(questions, key = { it.id }) { q ->
                val options = if (strings.isArabic) q.optionsAr else q.optionsEn
                val selected = answers[q.id] ?: -1

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = MaterialTheme.shapes.large,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "${q.orderIndex}. ${if (strings.isArabic) q.questionAr else q.questionEn}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        options.forEachIndexed { idx, opt ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize()
                                    .testTag("exam_q_${q.id}_opt_$idx")
                            ) {
                                RadioButton(
                                    selected = selected == idx,
                                    onClick = { answers[q.id] = idx }
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                TextButton(
                                    onClick = { answers[q.id] = idx },
                                    contentPadding = PaddingValues(horizontal = 4.dp)
                                ) {
                                    Text(
                                        text = opt,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = { onSubmit(answers.toMap()) },
                    enabled = !busy && answers.size == questions.size && questions.isNotEmpty(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("submit_exam_button")
                ) {
                    if (busy) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    } else {
                        Text(
                            text = "${strings.submitExam} (${answers.size}/${questions.size})",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ExamResultScreen(
    strings: AppStrings,
    course: Course,
    attempt: ExamAttempt,
    existingCertificate: Certificate?,
    studentName: String = "",
    busy: Boolean,
    onSaveMissingTripleName: ((String, String, String) -> Unit)? = null,
    onRetake: () -> Unit,
    onClaimCertificate: () -> Unit,
    onViewCertificate: (Certificate) -> Unit,
    onBackToCourse: () -> Unit
) {
    BackHandler(onBack = onBackToCourse)
    val hasValidTripleName = SecurityUtils.isTripleName(studentName)
    var missingFirst by remember { mutableStateOf("") }
    var missingFather by remember { mutableStateOf("") }
    var missingFamily by remember { mutableStateOf("") }
    val inlineTripleValid = SecurityUtils.isValidNamePart(missingFirst) &&
        SecurityUtils.isValidNamePart(missingFather) &&
        SecurityUtils.isValidNamePart(missingFamily) &&
        SecurityUtils.isTripleName(SecurityUtils.composeTripleName(missingFirst, missingFather, missingFamily))

    Box(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
            .testTag("exam_result_screen"),
        contentAlignment = Alignment.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = MaterialTheme.shapes.extraLarge,
            modifier = Modifier.widthIn(max = 520.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = if (attempt.passed) Icons.Default.WorkspacePremium else Icons.Default.Replay,
                    contentDescription = null,
                    tint = if (attempt.passed) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "${attempt.scorePercent}%",
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (attempt.passed) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (attempt.passed) strings.examPassed else strings.examFailed,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "${attempt.correctCount} / ${attempt.totalQuestions}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = strings.examHiddenAnswersNote,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                if (attempt.passed && hasValidTripleName) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (strings.isArabic) "ستصدر الشهادة باسم: $studentName" else "Certificate name: $studentName",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(22.dp))

                if (attempt.passed) {
                    if (existingCertificate != null) {
                        Button(
                            onClick = { onViewCertificate(existingCertificate) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("result_view_cert_button")
                        ) {
                            Text(strings.viewCertificate, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        if (!hasValidTripleName && onSaveMissingTripleName != null) {
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.75f),
                                shape = MaterialTheme.shapes.medium,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = if (strings.isArabic) {
                                            "يرجى إدخال اسمك الثلاثي كاملًا ليُحفظ في حسابك ويُطبع على الشهادة:"
                                        } else {
                                            "Please complete your First, Father's, and Family name before issuing your certificate:"
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    OutlinedTextField(
                                        value = missingFirst,
                                        onValueChange = { missingFirst = it },
                                        label = { Text(strings.firstNameLabel) },
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("exam_missing_first_name")
                                    )
                                    OutlinedTextField(
                                        value = missingFather,
                                        onValueChange = { missingFather = it },
                                        label = { Text(strings.fatherNameLabel) },
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("exam_missing_father_name")
                                    )
                                    OutlinedTextField(
                                        value = missingFamily,
                                        onValueChange = { missingFamily = it },
                                        label = { Text(strings.familyNameLabel) },
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("exam_missing_family_name")
                                    )
                                    FilledTonalButton(
                                        onClick = {
                                            onSaveMissingTripleName(
                                                missingFirst.trim(),
                                                missingFather.trim(),
                                                missingFamily.trim()
                                            )
                                        },
                                        enabled = !busy && inlineTripleValid,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("save_missing_triple_name_button")
                                    ) {
                                        Text(if (strings.isArabic) "حفظ الاسم الثلاثي" else "Save Full Name")
                                    }
                                }
                            }
                        }

                        Button(
                            onClick = onClaimCertificate,
                            enabled = !busy && hasValidTripleName,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("claim_certificate_button")
                        ) {
                            if (busy) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            } else {
                                Text(strings.claimCertificate, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                OutlinedButton(
                    onClick = onRetake,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("retake_exam_button")
                ) {
                    Text(strings.retakeExam)
                }

                Spacer(modifier = Modifier.height(8.dp))
                TextButton(
                    onClick = onBackToCourse,
                    modifier = Modifier.testTag("result_back_course_button")
                ) {
                    Text(if (strings.isArabic) "العودة للكورس" else "Back to Course")
                }
            }
        }
    }
}

@Composable
fun CertificatesScreen(
    strings: AppStrings,
    certificates: List<Certificate>,
    onOpenCertificate: (Certificate) -> Unit,
    onOpenVerify: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("certificates_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.navCertificates,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                OutlinedButton(
                    onClick = onOpenVerify,
                    modifier = Modifier.testTag("certs_verify_lookup_button")
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.verifyNow)
                }
            }
        }

        if (certificates.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (strings.isArabic) {
                                "لا توجد شهادات مُصدرة بعد. اجتز امتحان أي كورس بنسبة 75% لإصدار شهادتك."
                            } else {
                                "No certificates issued yet. Pass any course exam with 75%+ to unlock your certificate."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(certificates, key = { it.id }) { cert ->
                Card(
                    onClick = { onOpenCertificate(cert) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("cert_card_${cert.certificateCode}")
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (strings.isArabic) cert.courseTitleAr else cert.courseTitleEn,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${cert.studentName} • ${cert.certificateCode}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${cert.issuedDateLabel} • ${cert.scorePercent}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                        if (cert.revoked) {
                            StatusPill(
                                text = if (strings.isArabic) "ملغاة" else "REVOKED",
                                containerColor = MaterialTheme.colorScheme.errorContainer,
                                contentColor = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CertificateDetailScreen(
    strings: AppStrings,
    certificate: Certificate,
    platformConfig: com.example.model.PlatformConfig = com.example.model.PlatformConfig(),
    onOpenVerifyCode: (String) -> Unit = {},
    onBack: () -> Unit,
    onFeedback: (String) -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val verifyBaseUrl = remember(platformConfig.verificationBaseUrl) {
        platformConfig.effectiveVerificationBaseUrl()
    }
    val verifyUrl = remember(verifyBaseUrl, certificate.certificateCode) {
        platformConfig.buildCertificateVerifyUrl(certificate.certificateCode)
    }
    val renderedBitmap = remember(
        certificate.id,
        certificate.studentName,
        certificate.courseTitleEn,
        certificate.scorePercent,
        certificate.issuedDateLabel,
        certificate.certificateCode,
        verifyBaseUrl
    ) {
        CertificateExporter.renderCertificateBitmap(
            context = context,
            cert = certificate,
            verificationBaseUrl = verifyBaseUrl
        )
    }

    Scaffold(
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                title = { Text(certificate.certificateCode) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("cert_detail_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .testTag("certificate_detail_screen"),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (certificate.revoked) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = strings.certRevoked,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            // Exact Official Reference Certificate Visual Preview (matches PNG / PDF / Print 1:1)
            Card(
                shape = MaterialTheme.shapes.large,
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxWidth()
                    .testTag("certificate_visual_preview_card")
            ) {
                Image(
                    bitmap = renderedBitmap.asImageBitmap(),
                    contentDescription = "NEXORA Certificate for ${certificate.studentName} (${certificate.certificateCode})",
                    contentScale = androidx.compose.ui.layout.ContentScale.FillWidth,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1600f / 1130f)
                        .testTag("certificate_rendered_image")
                )
            }

            // Verified Data & Direct Browser Verification Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "${certificate.studentName} • ${certificate.scorePercent}%",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.testTag("cert_detail_student_name")
                    )
                    Text(
                        text = "${certificate.certificateCode} • ${certificate.issuedDateLabel}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.testTag("cert_detail_code_and_date")
                    )
                    Text(
                        text = verifyUrl,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.testTag("cert_detail_verify_url")
                    )
                    OutlinedButton(
                        onClick = { onOpenVerifyCode(certificate.certificateCode) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("cert_detail_verify_button")
                    ) {
                        Icon(Icons.Default.Verified, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (strings.isArabic) "التحقق المباشر من الشهادة" else "Verify Certificate Record")
                    }
                }
            }

            Row(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        CertificateExporter.shareCertificatePng(context, certificate, verifyBaseUrl)
                            .onFailure { onFeedback(it.localizedMessage ?: "Export failed") }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("export_png_button")
                ) {
                    Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.exportPng)
                }
                Button(
                    onClick = {
                        CertificateExporter.shareCertificatePdf(context, certificate, verifyBaseUrl)
                            .onFailure { onFeedback(it.localizedMessage ?: "PDF export failed") }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("export_pdf_button")
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.exportPdf)
                }
            }

            OutlinedButton(
                onClick = { CertificateExporter.printCertificate(context, certificate, verifyBaseUrl) },
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("print_cert_button")
            ) {
                Icon(Icons.Default.Print, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(strings.printCert)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CertificateVerifyScreen(
    strings: AppStrings,
    verifyState: CertVerifyUiState,
    initialCode: String = "",
    onVerify: (String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    var codeInput by remember(initialCode) { mutableStateOf(initialCode.trim().uppercase()) }

    LaunchedEffect(initialCode) {
        val clean = initialCode.trim().uppercase()
        if (clean.isNotEmpty() && verifyState is CertVerifyUiState.Idle) {
            onVerify(clean)
        }
    }

    Scaffold(
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                title = { Text(strings.verifyTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("verify_cert_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .testTag("certificate_verify_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = codeInput,
                onValueChange = { codeInput = it.uppercase() },
                label = { Text(strings.enterCertCode) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("verify_code_input")
            )

            Button(
                onClick = { onVerify(codeInput) },
                enabled = codeInput.trim().isNotEmpty() && verifyState !is CertVerifyUiState.Loading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("verify_submit_button")
            ) {
                if (verifyState is CertVerifyUiState.Loading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Text(strings.verifyNow, fontWeight = FontWeight.Bold)
                }
            }

            when (verifyState) {
                is CertVerifyUiState.Found -> {
                    val cert = verifyState.certificate
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (cert.revoked) {
                                MaterialTheme.colorScheme.errorContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("verify_result_found_card")
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = if (cert.revoked) strings.certRevoked else strings.certValid,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (cert.revoked) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary
                            )
                            Text("${cert.studentName} • ${cert.certificateCode}", fontWeight = FontWeight.SemiBold)
                            Text(if (strings.isArabic) cert.courseTitleAr else cert.courseTitleEn)
                            Text("${cert.issuedDateLabel} • ${cert.scorePercent}%", style = MaterialTheme.typography.bodySmall)
                            Text(cert.issuerName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                is CertVerifyUiState.NotFound -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("verify_result_not_found_card")
                    ) {
                        Text(
                            text = "${strings.certInvalid}: ${verifyState.code}",
                            modifier = Modifier.padding(16.dp),
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
                is CertVerifyUiState.Error -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = verifyState.message,
                            modifier = Modifier.padding(16.dp),
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
                CertVerifyUiState.Idle, CertVerifyUiState.Loading -> Unit
            }
        }
    }
}
