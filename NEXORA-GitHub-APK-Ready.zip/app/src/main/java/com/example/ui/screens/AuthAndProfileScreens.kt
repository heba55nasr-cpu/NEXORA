package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.AppStrings
import com.example.core.SecurityUtils
import com.example.model.ExamAttempt
import com.example.model.PaymentRequest
import com.example.model.UserProfile
import com.example.ui.components.NexoraLogoBadge
import com.example.ui.components.StatusPill

@Composable
fun AuthScreen(
    strings: AppStrings,
    darkTheme: Boolean,
    authBusy: Boolean,
    authError: String?,
    onToggleLanguage: () -> Unit,
    onToggleTheme: () -> Unit,
    onGoogleSignIn: () -> Unit,
    onOpenPublicVerify: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxSize()
            .testTag("auth_screen"),
        color = androidx.compose.ui.graphics.Color.Transparent
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.widthIn(max = 480.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onToggleLanguage,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("auth_toggle_lang_button")
                    ) {
                        Icon(Icons.Default.Language, contentDescription = strings.languageLabel)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.switchLangButton)
                    }

                    IconButton(
                        onClick = onToggleTheme,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("auth_toggle_theme_button")
                    ) {
                        Icon(
                            imageVector = if (darkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle Theme"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                NexoraLogoBadge(darkTheme = darkTheme, size = 104.dp)

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = strings.appTitle,
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = strings.byFounder,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = strings.tagline,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(28.dp))

                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = strings.signInTitle,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = strings.signInSubtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))

                        if (authError != null) {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                contentColor = MaterialTheme.colorScheme.onErrorContainer,
                                shape = MaterialTheme.shapes.medium,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp)
                            ) {
                                Text(
                                    text = authError,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        Button(
                            onClick = onGoogleSignIn,
                            enabled = !authBusy,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("google_sign_in_button")
                        ) {
                            if (authBusy) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                            } else {
                                Icon(Icons.Default.AccountCircle, contentDescription = strings.signInGoogle)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(strings.signInGoogle, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedButton(
                    onClick = onOpenPublicVerify,
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("public_verify_cert_button")
                ) {
                    Icon(Icons.Default.Verified, contentDescription = strings.verifyCertPublic)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(strings.verifyCertPublic)
                }
            }
        }
    }
}

@Composable
fun OnboardingProfileScreen(
    strings: AppStrings,
    defaultName: String,
    defaultEmail: String,
    initialLang: String,
    busy: Boolean,
    onSave: (String, String, String, String) -> Unit
) {
    val sanitizedDefault = remember(defaultName) {
        if (defaultName.contains('@')) "" else defaultName
    }
    val initialSplit = remember(sanitizedDefault) { SecurityUtils.splitTripleName(sanitizedDefault) }
    var firstName by remember(initialSplit) { mutableStateOf(initialSplit.first) }
    var fatherName by remember(initialSplit) { mutableStateOf(initialSplit.second) }
    var familyName by remember(initialSplit) { mutableStateOf(initialSplit.third) }
    var selectedLang by remember(initialLang) { mutableStateOf(initialLang) }

    val combinedFullName = SecurityUtils.composeTripleName(firstName, fatherName, familyName)
    val isFirstValid = SecurityUtils.isValidNamePart(firstName)
    val isFatherValid = SecurityUtils.isValidNamePart(fatherName)
    val isFamilyValid = SecurityUtils.isValidNamePart(familyName)
    val isTripleValid = isFirstValid && isFatherValid && isFamilyValid && SecurityUtils.isTripleName(combinedFullName)

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .testTag("onboarding_profile_screen"),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.widthIn(max = 520.dp)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = strings.onboardingTitle,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = defaultEmail,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (strings.isArabic) {
                            "أدخل اسمك الثلاثي كاملًا (الاسم الأول + اسم الأب + اسم العائلة) ليُحفظ في حسابك ويُطبع بدقة على الشهادات."
                        } else {
                            "Enter your First Name, Father's Name, and Family Name. Your verified 3-part name will be printed on certificates."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = firstName,
                        onValueChange = { firstName = it },
                        label = { Text(strings.firstNameLabel) },
                        isError = firstName.isNotBlank() && !isFirstValid,
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("onboarding_first_name_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = fatherName,
                        onValueChange = { fatherName = it },
                        label = { Text(strings.fatherNameLabel) },
                        isError = fatherName.isNotBlank() && !isFatherValid,
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("onboarding_father_name_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = familyName,
                        onValueChange = { familyName = it },
                        label = { Text(strings.familyNameLabel) },
                        isError = familyName.isNotBlank() && !isFamilyValid,
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("onboarding_family_name_input")
                    )

                    if (combinedFullName.isNotBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = if (strings.isArabic) "الاسم المعتمد للشهادة:" else "Certificate Full Name Preview:",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = combinedFullName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.testTag("onboarding_combined_name_preview")
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = strings.languageLabel,
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        FilterChip(
                            selected = selectedLang == "ar",
                            onClick = { selectedLang = "ar" },
                            label = { Text("العربية (الافتراضي)") },
                            modifier = Modifier.testTag("lang_chip_ar")
                        )
                        FilterChip(
                            selected = selectedLang == "en",
                            onClick = { selectedLang = "en" },
                            label = { Text("English") },
                            modifier = Modifier.testTag("lang_chip_en")
                        )
                    }

                    Spacer(modifier = Modifier.height(22.dp))

                    Button(
                        onClick = {
                            if (isTripleValid) {
                                onSave(firstName.trim(), fatherName.trim(), familyName.trim(), selectedLang)
                            }
                        },
                        enabled = !busy && isTripleValid,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("onboarding_save_button")
                    ) {
                        if (busy) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(strings.saveContinue, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(
    strings: AppStrings,
    profile: UserProfile?,
    fallbackEmail: String,
    fallbackName: String,
    darkTheme: Boolean,
    unreadNotificationsCount: Int,
    courses: List<com.example.model.Course> = emptyList(),
    enrollments: List<com.example.model.Enrollment> = emptyList(),
    progress: List<com.example.model.LessonProgress> = emptyList(),
    certificates: List<com.example.model.Certificate> = emptyList(),
    payments: List<PaymentRequest>,
    examAttempts: List<ExamAttempt>,
    busy: Boolean,
    onSaveProfile: (String, String, String, String) -> Unit,
    onToggleTheme: () -> Unit,
    onToggleLanguage: () -> Unit,
    onOpenCourse: (com.example.model.Course) -> Unit = {},
    onOpenCertificate: (com.example.model.Certificate) -> Unit = {},
    onOpenNotifications: () -> Unit,
    onOpenSupport: () -> Unit,
    onOpenVerifyCertificate: () -> Unit,
    onSignOut: () -> Unit
) {
    val safeFallback = remember(fallbackName) { if (fallbackName.contains('@')) "" else fallbackName }
    val currentFullName = profile?.fullName?.ifBlank { safeFallback } ?: safeFallback
    val initialSplit = remember(profile?.firstName, profile?.fatherName, profile?.familyName, currentFullName) {
        if (profile != null &&
            profile.firstName.isNotBlank() &&
            profile.fatherName.isNotBlank() &&
            profile.familyName.isNotBlank()
        ) {
            Triple(profile.firstName, profile.fatherName, profile.familyName)
        } else {
            SecurityUtils.splitTripleName(currentFullName)
        }
    }
    var firstName by remember(initialSplit) { mutableStateOf(initialSplit.first) }
    var fatherName by remember(initialSplit) { mutableStateOf(initialSplit.second) }
    var familyName by remember(initialSplit) { mutableStateOf(initialSplit.third) }

    val combinedEditingName = SecurityUtils.composeTripleName(firstName, fatherName, familyName)
    val profileTripleValid = SecurityUtils.isValidNamePart(firstName) &&
        SecurityUtils.isValidNamePart(fatherName) &&
        SecurityUtils.isValidNamePart(familyName) &&
        SecurityUtils.isTripleName(combinedEditingName)

    val hasAnnualSub = profile?.hasActiveAnnualSubscription() == true
    val enrolledIds = remember(enrollments) { enrollments.map { it.courseId }.toSet() }
    val completedByCourse = remember(progress) {
        progress.filter { it.completed }.groupBy { it.courseId }.mapValues { it.value.size }
    }
    val unlockedCoursesCount = remember(courses, enrolledIds, hasAnnualSub) {
        courses.count { !it.paid || it.id in enrolledIds || hasAnnualSub }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("profile_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        NexoraLogoBadge(darkTheme = darkTheme, size = 56.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = currentFullName.ifBlank {
                                    if (strings.isArabic) "يرجى استكمال الاسم الثلاثي" else "Complete Full Name"
                                },
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = profile?.email?.ifBlank { fallbackEmail } ?: fallbackEmail,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (hasAnnualSub) {
                            StatusPill(
                                text = if (strings.isArabic) "اشتراك سنوي" else "ANNUAL PASS",
                                containerColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.25f),
                                contentColor = MaterialTheme.colorScheme.tertiary
                            )
                        }
                        if (profile?.accountStatus == "SUSPENDED") {
                            Spacer(modifier = Modifier.width(6.dp))
                            StatusPill(
                                text = if (strings.isArabic) "موقوف" else "SUSPENDED",
                                containerColor = MaterialTheme.colorScheme.errorContainer,
                                contentColor = MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedTextField(
                        value = firstName,
                        onValueChange = { firstName = it },
                        label = { Text(strings.firstNameLabel) },
                        isError = firstName.isNotBlank() && !SecurityUtils.isValidNamePart(firstName),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_first_name_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = fatherName,
                        onValueChange = { fatherName = it },
                        label = { Text(strings.fatherNameLabel) },
                        isError = fatherName.isNotBlank() && !SecurityUtils.isValidNamePart(fatherName),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_father_name_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = familyName,
                        onValueChange = { familyName = it },
                        label = { Text(strings.familyNameLabel) },
                        isError = familyName.isNotBlank() && !SecurityUtils.isValidNamePart(familyName),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_family_name_input")
                    )
                    if (!profileTripleValid) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (strings.isArabic) {
                                "يجب كتابة الاسم الثلاثي (الاسم الأول + اسم الأب + اسم العائلة) ليظهر في الشهادات"
                            } else {
                                "Please enter First, Father's, and Family names so certificates print accurately"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            if (profileTripleValid) {
                                onSaveProfile(
                                    firstName.trim(),
                                    fatherName.trim(),
                                    familyName.trim(),
                                    if (strings.isArabic) "ar" else "en"
                                )
                            }
                        },
                        enabled = !busy && profileTripleValid,
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("profile_save_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (strings.isArabic) "حفظ التغييرات" else "Save Profile Changes")
                    }
                }
            }
        }

        // Student Dashboard Summary & Course Access Matrix
        if (courses.isNotEmpty()) {
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("student_dashboard_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = if (strings.isArabic) "لوحة تحكم الطالب" else "Student Dashboard",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            DashboardStatChip(
                                label = if (strings.isArabic) "كورسات مفتوحة" else "Unlocked",
                                value = "$unlockedCoursesCount/${courses.size}",
                                modifier = Modifier.weight(1f)
                            )
                            DashboardStatChip(
                                label = if (strings.isArabic) "دروس مكتملة" else "Completed",
                                value = "${progress.count { it.completed }}",
                                modifier = Modifier.weight(1f)
                            )
                            DashboardStatChip(
                                label = if (strings.isArabic) "الشهادات" else "Certificates",
                                value = "${certificates.count { !it.revoked }}",
                                modifier = Modifier.weight(1f)
                            )
                        }

                        HorizontalDivider()

                        courses.forEach { c ->
                            val isUnlocked = !c.paid || (c.id in enrolledIds) || hasAnnualSub
                            val doneCount = completedByCourse[c.id] ?: 0
                            val totalLessons = c.lessonCount.toInt().coerceAtLeast(1)
                            val pct = ((doneCount * 100) / totalLessons).coerceIn(0, 100)
                            val examEligible = isUnlocked && doneCount >= totalLessons
                            val hasCert = certificates.any { it.courseId == c.id && !it.revoked }

                            Surface(
                                onClick = { onOpenCourse(c) },
                                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f),
                                shape = MaterialTheme.shapes.medium,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("dashboard_course_${c.id}")
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (strings.isArabic) c.titleAr else c.titleEn,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.weight(1f)
                                        )
                                        StatusPill(
                                            text = when {
                                                hasCert -> if (strings.isArabic) "شهادة صادرة ✓" else "Certified ✓"
                                                examEligible -> if (strings.isArabic) "مؤهل للامتحان" else "Exam Ready"
                                                isUnlocked -> if (strings.isArabic) "مفتوح ($pct%)" else "Unlocked ($pct%)"
                                                else -> if (strings.isArabic) "مقفل • ${c.effectivePriceEgp.toInt()} ج.م" else "Locked • ${c.effectivePriceEgp.toInt()} EGP"
                                            },
                                            containerColor = when {
                                                hasCert || examEligible -> MaterialTheme.colorScheme.tertiary.copy(alpha = 0.24f)
                                                isUnlocked -> MaterialTheme.colorScheme.primaryContainer
                                                else -> MaterialTheme.colorScheme.secondaryContainer
                                            },
                                            contentColor = when {
                                                hasCert || examEligible -> MaterialTheme.colorScheme.tertiary
                                                isUnlocked -> MaterialTheme.colorScheme.onPrimaryContainer
                                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                                            }
                                        )
                                    }
                                    LinearProgressIndicator(
                                        progress = { pct / 100f },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(5.dp)
                                            .clip(MaterialTheme.shapes.small)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (certificates.isNotEmpty()) {
            item {
                Text(
                    text = if (strings.isArabic) "الشهادات المكتسبة" else "Earned Certificates",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            items(certificates, key = { it.id }) { cert ->
                Card(
                    onClick = { onOpenCertificate(cert) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(if (strings.isArabic) cert.courseTitleAr else cert.courseTitleEn, fontWeight = FontWeight.Bold)
                            Text(
                                text = "${cert.studentName} • ${cert.certificateCode}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                    }
                }
            }
        }

        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    ListItem(
                        headlineContent = { Text(strings.languageLabel) },
                        supportingContent = { Text(if (strings.isArabic) "العربية" else "English") },
                        leadingContent = { Icon(Icons.Default.Language, contentDescription = null) },
                        trailingContent = {
                            TextButton(
                                onClick = onToggleLanguage,
                                modifier = Modifier.testTag("profile_lang_button")
                            ) {
                                Text(strings.switchLangButton)
                            }
                        }
                    )
                    HorizontalDivider()
                    ListItem(
                        headlineContent = { Text(if (strings.isArabic) "المظهر" else "Appearance") },
                        supportingContent = {
                            Text(
                                if (darkTheme) {
                                    if (strings.isArabic) "الوضع الداكن" else "Dark Mode"
                                } else {
                                    if (strings.isArabic) "الوضع الفاتح" else "Light Mode"
                                }
                            )
                        },
                        leadingContent = {
                            Icon(
                                if (darkTheme) Icons.Default.DarkMode else Icons.Default.LightMode,
                                contentDescription = null
                            )
                        },
                        trailingContent = {
                            Switch(
                                checked = darkTheme,
                                onCheckedChange = { onToggleTheme() },
                                modifier = Modifier.testTag("profile_theme_switch")
                            )
                        }
                    )
                    HorizontalDivider()
                    ListItem(
                        headlineContent = { Text(strings.notificationsTitle) },
                        leadingContent = { Icon(Icons.Default.Notifications, contentDescription = null) },
                        trailingContent = {
                            if (unreadNotificationsCount > 0) {
                                Badge { Text("$unreadNotificationsCount") }
                            }
                        },
                        modifier = Modifier
                            .clip(MaterialTheme.shapes.medium)
                            .minimumInteractiveComponentSize()
                            .testTag("profile_notifications_item")
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onOpenNotifications,
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("open_notifications_button")
                        ) {
                            Icon(Icons.Default.Notifications, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(strings.notificationsTitle)
                        }
                        OutlinedButton(
                            onClick = onOpenSupport,
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("open_support_button")
                        ) {
                            Icon(Icons.Default.SupportAgent, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (strings.isArabic) "الدعم" else "Support")
                        }
                    }
                    OutlinedButton(
                        onClick = onOpenVerifyCertificate,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .minimumInteractiveComponentSize()
                            .testTag("profile_verify_cert_button")
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.verifyCertPublic)
                    }
                }
            }
        }

        if (payments.isNotEmpty()) {
            item {
                Text(
                    text = if (strings.isArabic) "سجل المدفوعات (WE Pay)" else "Payment History (WE Pay)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            items(payments, key = { it.id }) { pay ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(pay.courseTitle, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            StatusPill(
                                text = pay.displayStatus(strings.isArabic),
                                containerColor = when (pay.status) {
                                    "APPROVED" -> MaterialTheme.colorScheme.tertiary.copy(alpha = 0.25f)
                                    "REJECTED" -> MaterialTheme.colorScheme.errorContainer
                                    else -> MaterialTheme.colorScheme.primaryContainer
                                },
                                contentColor = when (pay.status) {
                                    "APPROVED" -> MaterialTheme.colorScheme.tertiary
                                    "REJECTED" -> MaterialTheme.colorScheme.error
                                    else -> MaterialTheme.colorScheme.onPrimaryContainer
                                }
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${pay.amountEgp.toInt()} ${strings.egpCurrency} • Ref: ${pay.transactionRef}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        pay.adminNote?.takeIf { it.isNotBlank() }?.let { note ->
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = note,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }
        }

        if (examAttempts.isNotEmpty()) {
            item {
                Text(
                    text = if (strings.isArabic) "سجل محاولات الامتحانات" else "Exam Attempt History",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            items(examAttempts, key = { it.id }) { att ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(att.courseTitle, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = "${att.scorePercent}% (${att.correctCount}/${att.totalQuestions})",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        StatusPill(
                            text = if (att.passed) {
                                if (strings.isArabic) "ناجح" else "PASSED"
                            } else {
                                if (strings.isArabic) "إعادة" else "RETRY"
                            },
                            containerColor = if (att.passed) {
                                MaterialTheme.colorScheme.tertiary.copy(alpha = 0.25f)
                            } else {
                                MaterialTheme.colorScheme.secondaryContainer
                            },
                            contentColor = if (att.passed) {
                                MaterialTheme.colorScheme.tertiary
                            } else {
                                MaterialTheme.colorScheme.onSecondaryContainer
                            }
                        )
                    }
                }
            }
        }

        item {
            OutlinedButton(
                onClick = onSignOut,
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MaterialTheme.colorScheme.error
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("sign_out_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = strings.signOut)
                Spacer(modifier = Modifier.width(8.dp))
                Text(strings.signOut, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun DashboardStatChip(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f),
        shape = MaterialTheme.shapes.medium,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}
