package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// NEXORA by HEBA NASR — Obsidian Black & Matte Royal Purple Mix Palette
val NexoraBlackPure = Color(0xFF040208)
val NexoraNavyBg = Color(0xFF090412)
val NexoraNavyDeep = Color(0xFF05020A)
val NexoraPurpleDeep = Color(0xFF1D0C36)
val NexoraPurpleRich = Color(0xFF2B124E)
val NexoraNavySurface = Color(0xFF130B22)
val NexoraCardDark = Color(0xFF1A102C)
val NexoraCardElevated = Color(0xFF271842)

val NexoraMauve = Color(0xFF9B7BC2)
val NexoraMauvePressed = Color(0xFF7D5EA6)
val NexoraLavender = Color(0xFFC8B4E6)
val NexoraMauveContainer = Color(0xFF352154)

val NexoraTextWhite = Color(0xFFF5F3FA)
val NexoraSilver = Color(0xFFB3AAC9)
val NexoraBorderSilver = Color(0xFF473369)

// Light Theme Surfaces
val NexoraLightBg = Color(0xFFF7F4FB)
val NexoraLightPurpleMist = Color(0xFFE9E0F7)
val NexoraLightSurface = Color(0xFFFFFFFF)
val NexoraLightCard = Color(0xFFF0EBF8)
val NexoraLightInk = Color(0xFF140D24)
val NexoraLightMuted = Color(0xFF5E5573)
val NexoraLightMauve = Color(0xFF6B4D96)
val NexoraLightBorder = Color(0xFFD5C8EB)

// Semantic Status
val NexoraSuccess = Color(0xFF4FB286)
val NexoraSuccessContainer = Color(0xFF17382C)
val NexoraWarning = Color(0xFFE0B463)
val NexoraWarningContainer = Color(0xFF3C2F18)
val NexoraError = Color(0xFFD96D7B)
val NexoraErrorContainer = Color(0xFF3D1C23)

fun nexoraBackgroundBrush(darkTheme: Boolean): Brush {
    return if (darkTheme) {
        Brush.linearGradient(
            colors = listOf(
                NexoraPurpleRich,
                NexoraNavyBg,
                NexoraBlackPure,
                NexoraPurpleDeep,
                NexoraBlackPure
            )
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                NexoraLightBg,
                NexoraLightPurpleMist,
                NexoraLightBg
            )
        )
    }
}
