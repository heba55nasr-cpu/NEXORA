package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.AppStrings
import com.example.model.Course
import com.example.model.Lesson
import com.example.ui.components.YouTubeEmbedPlayer

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonPlayerScreen(
    strings: AppStrings,
    course: Course,
    lessons: List<Lesson>,
    currentLesson: Lesson,
    completedLessonIds: Set<String>,
    onBack: () -> Unit,
    onSelectLesson: (Lesson) -> Unit,
    onToggleCompleted: (Boolean) -> Unit
) {
    BackHandler(onBack = onBack)

    var selectedVideoLang by remember(currentLesson.id, strings.isArabic) {
        mutableStateOf(if (strings.isArabic) "ar" else "en")
    }
    val hasAr = !currentLesson.youtubeIdAr.isNullOrBlank()
    val hasEn = !currentLesson.youtubeIdEn.isNullOrBlank()
    val resolvedVideoId = currentLesson.resolveYoutubeId(selectedVideoLang)

    val currentIndex = lessons.indexOfFirst { it.id == currentLesson.id }
    val prevLesson = if (currentIndex > 0) lessons[currentIndex - 1] else null
    val nextLesson = if (currentIndex in 0 until lessons.lastIndex) lessons[currentIndex + 1] else null
    val isCompleted = currentLesson.id in completedLessonIds
    val lessonTitle = if (strings.isArabic) currentLesson.titleAr else currentLesson.titleEn

    Scaffold(
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                title = {
                    Text(
                        text = "${currentLesson.orderIndex}. $lessonTitle",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("lesson_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 920.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
                    .testTag("lesson_player_screen"),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                YouTubeEmbedPlayer(
                    videoId = resolvedVideoId,
                    lessonTitle = lessonTitle,
                    strings = strings
                )

            if (course.supportsBilingual && (hasAr || hasEn)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    FilterChip(
                        selected = selectedVideoLang == "ar",
                        onClick = { selectedVideoLang = "ar" },
                        enabled = hasAr,
                        label = { Text(strings.videoSourceAr) },
                        modifier = Modifier.testTag("video_source_ar_chip")
                    )
                    FilterChip(
                        selected = selectedVideoLang == "en",
                        onClick = { selectedVideoLang = "en" },
                        enabled = hasEn,
                        label = { Text(strings.videoSourceEn) },
                        modifier = Modifier.testTag("video_source_en_chip")
                    )
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = lessonTitle,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${if (strings.isArabic) currentLesson.moduleTitleAr else currentLesson.moduleTitleEn} • ${currentLesson.durationLabel}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (strings.isArabic) currentLesson.descriptionAr else currentLesson.descriptionEn,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    val objectives = if (strings.isArabic) currentLesson.objectivesAr else currentLesson.objectivesEn
                    if (objectives.isNotBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (strings.isArabic) "أهداف الدرس:" else "Learning Objectives:",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = objectives,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Button(
                onClick = { onToggleCompleted(!isCompleted) },
                colors = if (isCompleted) {
                    ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.tertiary,
                        contentColor = MaterialTheme.colorScheme.onTertiary
                    )
                } else {
                    ButtonDefaults.buttonColors()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("mark_lesson_completed_button")
            ) {
                Icon(
                    imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = null
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isCompleted) strings.completedLabel else strings.markCompleted,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { prevLesson?.let(onSelectLesson) },
                    enabled = prevLesson != null,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("prev_lesson_button")
                ) {
                    Text(strings.prevLesson)
                }
                Button(
                    onClick = { nextLesson?.let(onSelectLesson) },
                    enabled = nextLesson != null,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("next_lesson_button")
                ) {
                    Text(strings.nextLesson)
                }
            }
        }
        }
    }
}
