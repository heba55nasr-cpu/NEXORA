package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.core.AppStrings
import com.example.model.*
import com.example.ui.components.CourseCard
import com.example.ui.components.NexoraLogoBadge
import com.example.ui.components.StatusPill
import com.example.ui.theme.NexoraPurpleDeep
import com.example.ui.theme.SpaceGroteskFamily

@Composable
fun HomeScreen(
    strings: AppStrings,
    darkTheme: Boolean,
    profile: UserProfile?,
    fallbackName: String,
    config: PlatformConfig,
    courses: List<Course>,
    enrollments: List<Enrollment>,
    progress: List<LessonProgress>,
    payments: List<PaymentRequest>,
    certificates: List<Certificate> = emptyList(),
    hasAnnualSubscription: Boolean = false,
    unreadNotificationsCount: Int,
    onOpenCourse: (Course) -> Unit,
    onBuyCourseDirect: (Course) -> Unit = onOpenCourse,
    onOpenAllCourses: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenSupport: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    val enrolledIds = remember(enrollments) { enrollments.map { it.courseId }.toSet() }
    val pendingCourseIds = remember(payments) {
        payments.filter { it.status == "PENDING" }.map { it.courseId }.toSet()
    }
    val completedByCourse = remember(progress) {
        progress.filter { it.completed }.groupBy { it.courseId }.mapValues { it.value.size }
    }
    val safeFallback = remember(fallbackName) { if (fallbackName.contains('@')) "" else fallbackName }
    val greetingName = profile?.fullName?.ifBlank { safeFallback } ?: safeFallback
    val myActiveCourses = remember(courses, enrolledIds, hasAnnualSubscription) {
        courses.filter { (it.id in enrolledIds) || (it.paid && hasAnnualSubscription) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    NexoraLogoBadge(darkTheme = darkTheme, size = 46.dp)
                    Spacer(modifier = Modifier.width(12.dp))
                    val brandText = @Composable {
                        Text(
                            text = "Nexora",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontFamily = SpaceGroteskFamily,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 26.sp,
                                letterSpacing = 0.8.sp,
                                shadow = Shadow(
                                    color = Color(0xAA16072B),
                                    offset = Offset(0f, 2f),
                                    blurRadius = 10f
                                )
                            ),
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("home_brand_name")
                        )
                    }
                    if (darkTheme) {
                        brandText()
                    } else {
                        Surface(
                            color = NexoraPurpleDeep,
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Box(modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                                brandText()
                            }
                        }
                    }
                }

                Row {
                    IconButton(
                        onClick = onToggleLanguage,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("home_lang_button")
                    ) {
                        Icon(Icons.Default.Language, contentDescription = strings.languageLabel)
                    }
                    IconButton(
                        onClick = onOpenNotifications,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("home_notifications_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadNotificationsCount > 0) {
                                    Badge { Text("$unreadNotificationsCount") }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Notifications, contentDescription = strings.notificationsTitle)
                        }
                    }
                    IconButton(
                        onClick = onOpenSupport,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("home_support_button")
                    ) {
                        Icon(Icons.Default.SupportAgent, contentDescription = strings.supportTitle)
                    }
                }
            }
        }

        // Hero Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .clip(MaterialTheme.shapes.large)
                    .testTag("home_hero_banner")
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_nexora_hero_banner),
                    contentDescription = "NEXORA Learning Hero",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color.Transparent,
                                    MaterialTheme.colorScheme.background.copy(alpha = 0.88f)
                                )
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(18.dp)
                ) {
                    Text(
                        text = strings.tagline,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (strings.isArabic) config.announcementAr else config.announcementEn,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        // Active Offer Banner & Annual Pass Banner
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (hasAnnualSubscription) {
                    Surface(
                        color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.18f),
                        contentColor = MaterialTheme.colorScheme.tertiary,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.WorkspacePremium, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (strings.isArabic) {
                                    "الاشتراك السنوي مُفعّل — جميع الكورسات المدفوعة مفتوحة لك!"
                                } else {
                                    "Annual Subscription Active — All 5 paid courses unlocked!"
                                },
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                val offerText = if (strings.isArabic) config.activeOfferBannerAr else config.activeOfferBannerEn
                if (offerText.isNotBlank()) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = offerText,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Quick Stats Summary
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatMiniCard(
                    label = if (strings.isArabic) "كورساتي" else "My Courses",
                    value = "${myActiveCourses.size}",
                    modifier = Modifier.weight(1f)
                )
                StatMiniCard(
                    label = if (strings.isArabic) "دروس مكتملة" else "Done",
                    value = "${progress.count { it.completed }}",
                    modifier = Modifier.weight(1f)
                )
                StatMiniCard(
                    label = if (strings.isArabic) "شهاداتي" else "Certs",
                    value = "${certificates.count { !it.revoked }}",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // My Courses Dashboard Shelf
        if (myActiveCourses.isNotEmpty()) {
            item {
                Text(
                    text = if (strings.isArabic) "كورساتي المسجلة" else "My Enrolled Courses",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(myActiveCourses, key = { "my_${it.id}" }) { course ->
                        Box(modifier = Modifier.width(290.dp)) {
                            CourseCard(
                                course = course,
                                strings = strings,
                                isEnrolled = course.id in enrolledIds,
                                isPendingPayment = false,
                                hasAnnualSubscription = hasAnnualSubscription,
                                completedLessons = completedByCourse[course.id] ?: 0,
                                onClick = { onOpenCourse(course) }
                            )
                        }
                    }
                }
            }
        }

        // Free Language Tracks Horizontal Shelf
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (strings.isArabic) "كورسات اللغات المجانية" else "Free Language Tracks",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                TextButton(onClick = onOpenAllCourses) {
                    Text(if (strings.isArabic) "عرض الكل" else "View All")
                }
            }
        }

        item {
            val freeCourses = courses.filter { !it.paid }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(freeCourses, key = { it.id }) { course ->
                    Box(modifier = Modifier.width(290.dp)) {
                        CourseCard(
                            course = course,
                            strings = strings,
                            isEnrolled = course.id in enrolledIds,
                            isPendingPayment = false,
                            hasAnnualSubscription = hasAnnualSubscription,
                            completedLessons = completedByCourse[course.id] ?: 0,
                            onClick = { onOpenCourse(course) }
                        )
                    }
                }
            }
        }

        // Featured Paid Tracks
        item {
            Text(
                text = if (strings.isArabic) "مسارات المهارات الاحترافية" else "Professional Career Tracks",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(courses.filter { it.paid }, key = { it.id }) { course ->
            CourseCard(
                course = course,
                strings = strings,
                isEnrolled = course.id in enrolledIds,
                isPendingPayment = course.id in pendingCourseIds,
                hasAnnualSubscription = hasAnnualSubscription,
                completedLessons = completedByCourse[course.id] ?: 0,
                onClick = { onOpenCourse(course) },
                onLockedVideoClick = { onBuyCourseDirect(course) }
            )
        }
    }
}

@Composable
private fun StatMiniCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun CoursesCatalogScreen(
    strings: AppStrings,
    courses: List<Course>,
    enrollments: List<Enrollment>,
    progress: List<LessonProgress>,
    payments: List<PaymentRequest>,
    hasAnnualSubscription: Boolean = false,
    onOpenCourse: (Course) -> Unit,
    onBuyCourseDirect: (Course) -> Unit = onOpenCourse
) {
    var searchQuery by remember { mutableStateOf("") }
    var filterMode by remember { mutableStateOf("ALL") } // ALL | FREE | PAID | ENROLLED

    val enrolledIds = remember(enrollments) { enrollments.map { it.courseId }.toSet() }
    val pendingCourseIds = remember(payments) {
        payments.filter { it.status == "PENDING" }.map { it.courseId }.toSet()
    }
    val completedByCourse = remember(progress) {
        progress.filter { it.completed }.groupBy { it.courseId }.mapValues { it.value.size }
    }

    val filtered = remember(courses, searchQuery, filterMode, enrolledIds, hasAnnualSubscription) {
        courses.filter { c ->
            val matchesFilter = when (filterMode) {
                "FREE" -> !c.paid
                "PAID" -> c.paid
                "ENROLLED" -> (c.id in enrolledIds) || (c.paid && hasAnnualSubscription)
                else -> true
            }
            val q = searchQuery.trim().lowercase()
            val matchesSearch = q.isEmpty() ||
                c.titleAr.lowercase().contains(q) ||
                c.titleEn.lowercase().contains(q) ||
                c.category.lowercase().contains(q)
            matchesFilter && matchesSearch
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("courses_catalog_screen")
    ) {
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            placeholder = {
                Text(if (strings.isArabic) "ابحث عن كورس أو مهارة..." else "Search courses or tracks...")
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("courses_search_input")
        )
        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val chips = listOf(
                "ALL" to (if (strings.isArabic) "الكل" else "All"),
                "FREE" to strings.freeBadge,
                "PAID" to strings.paidBadge,
                "ENROLLED" to strings.enrolledBadge
            )
            items(chips) { (key, label) ->
                FilterChip(
                    selected = filterMode == key,
                    onClick = { filterMode = key },
                    label = { Text(label) },
                    modifier = Modifier.testTag("filter_chip_$key")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filtered, key = { it.id }) { course ->
                CourseCard(
                    course = course,
                    strings = strings,
                    isEnrolled = course.id in enrolledIds,
                    isPendingPayment = course.id in pendingCourseIds,
                    hasAnnualSubscription = hasAnnualSubscription,
                    completedLessons = completedByCourse[course.id] ?: 0,
                    onClick = { onOpenCourse(course) },
                    onLockedVideoClick = { onBuyCourseDirect(course) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CourseDetailScreen(
    strings: AppStrings,
    course: Course,
    lessons: List<Lesson>,
    isEnrolled: Boolean,
    isPendingPayment: Boolean,
    hasAnnualSubscription: Boolean = false,
    latestCoursePayment: PaymentRequest? = null,
    isAdmin: Boolean,
    completedLessonIds: Set<String>,
    existingCertificate: Certificate?,
    onBack: () -> Unit,
    onEnrollFree: () -> Unit,
    onBuyViaWePay: (String?) -> Unit,
    onPendingPaymentClick: () -> Unit = {},
    onOpenLesson: (Lesson) -> Unit,
    onTakeExam: () -> Unit,
    onViewCertificate: (Certificate) -> Unit
) {
    BackHandler(onBack = onBack)

    val hasAccess = !course.paid || isEnrolled || hasAnnualSubscription || isAdmin
    val completedCount = lessons.count { it.id in completedLessonIds }
    val allLessonsCompleted = lessons.isEmpty() || completedCount >= lessons.size
    val progressRatio = if (lessons.isNotEmpty()) completedCount.toFloat() / lessons.size else 0f
    val groupedModules = remember(lessons) { lessons.groupBy { it.moduleTitleEn to it.moduleTitleAr } }
    val totalDurationLabel = remember(lessons, strings.isArabic) {
        Lesson.estimateTotalDurationLabel(lessons, strings.isArabic)
    }
    val preferredVideoLang = if (strings.isArabic) "ar" else "en"
    val heroPreviewUrl = remember(lessons, preferredVideoLang) {
        lessons.firstOrNull()?.previewThumbnailUrl(preferredVideoLang)
    }
    val firstLockedLessonId = remember(lessons) {
        lessons.firstOrNull { !it.freePreview }?.id ?: lessons.firstOrNull()?.id
    }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = {
                    Text(
                        text = if (strings.isArabic) course.titleAr else course.titleEn,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("course_detail_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("course_detail_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.88f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Video Preview Frame from outside (Thumbnail + Video Count + Duration + Lock state)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(168.dp)
                                .clip(MaterialTheme.shapes.medium)
                                .background(MaterialTheme.colorScheme.surface)
                                .clickable {
                                    if (hasAccess) {
                                        lessons.firstOrNull()?.let(onOpenLesson)
                                    } else if (course.paid) {
                                        onBuyViaWePay(firstLockedLessonId)
                                    }
                                }
                                .testTag("course_hero_video_preview")
                        ) {
                            if (!heroPreviewUrl.isNullOrBlank()) {
                                AsyncImage(
                                    model = heroPreviewUrl,
                                    contentDescription = if (strings.isArabic) course.titleAr else course.titleEn,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(
                                                Color.Black.copy(alpha = 0.25f),
                                                Color.Black.copy(alpha = 0.78f)
                                            )
                                        )
                                    )
                            )
                            Column(
                                modifier = Modifier.align(Alignment.Center),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = if (!hasAccess) Icons.Default.Lock else Icons.Default.PlayCircleFilled,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(46.dp)
                                )
                                if (!hasAccess && course.paid) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Surface(
                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.92f),
                                        shape = RoundedCornerShape(50)
                                    ) {
                                        Text(
                                            text = if (strings.isArabic) {
                                                "مغلق — ادفع للاشتراك وشاهد كل الفيديوهات"
                                            } else {
                                                "Locked — Pay first to watch all videos"
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                        )
                                    }
                                }
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .align(Alignment.BottomStart)
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Surface(
                                    color = Color.Black.copy(alpha = 0.72f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = if (strings.isArabic) {
                                            "${lessons.size} فيديو / درس"
                                        } else {
                                            "${lessons.size} Videos / Lessons"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                Surface(
                                    color = Color.Black.copy(alpha = 0.72f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = if (strings.isArabic) "المدة: $totalDurationLabel" else "Duration: $totalDurationLabel",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                StatusPill(
                                    text = if (!course.paid) strings.freeBadge else strings.paidBadge,
                                    containerColor = if (!course.paid) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f)
                                    else MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = if (!course.paid) MaterialTheme.colorScheme.tertiary
                                    else MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                if (course.paid && !isEnrolled && hasAnnualSubscription) {
                                    StatusPill(
                                        text = if (strings.isArabic) "مفتوح بالاشتراك السنوي" else "Annual Access",
                                        containerColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f),
                                        contentColor = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                                if (course.supportsBilingual) {
                                    StatusPill(
                                        text = "AR / EN",
                                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                        contentColor = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }

                            if (course.paid) {
                                Text(
                                    text = "${course.effectivePriceEgp.toInt()} ${strings.egpCurrency}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (strings.isArabic) course.descriptionAr else course.descriptionEn,
                            style = MaterialTheme.typography.bodyMedium
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = { progressRatio },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (strings.isArabic) {
                                "$completedCount / ${lessons.size} ${strings.lessonsCountLabel} • المدة الإجمالية $totalDurationLabel"
                            } else {
                                "$completedCount / ${lessons.size} ${strings.lessonsCountLabel} • Total $totalDurationLabel"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        if (!hasAccess) {
                            if (!course.paid) {
                                Button(
                                    onClick = onEnrollFree,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("enroll_free_button")
                                ) {
                                    Text(strings.enrollFree, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                if (isPendingPayment || latestCoursePayment?.status == "PENDING") {
                                    Surface(
                                        onClick = onPendingPaymentClick,
                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                        shape = MaterialTheme.shapes.medium,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("pending_payment_banner")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(14.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.HourglassTop, contentDescription = null)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = if (strings.isArabic) {
                                                        "حالة الدفع: قيد المراجعة (Pending)"
                                                    } else {
                                                        "Payment Status: Pending Verification"
                                                    },
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = if (strings.isArabic) {
                                                        "سيتم تسجيلك وفتح جميع الدروس تلقائيًا فور تحقق الإدارة من الدفع."
                                                    } else {
                                                        "Course lessons unlock automatically once Admin verifies your payment."
                                                    },
                                                    style = MaterialTheme.typography.bodySmall
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    if (latestCoursePayment?.status == "REJECTED") {
                                        Surface(
                                            color = MaterialTheme.colorScheme.errorContainer,
                                            contentColor = MaterialTheme.colorScheme.onErrorContainer,
                                            shape = MaterialTheme.shapes.medium,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(bottom = 10.dp)
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Text(
                                                    text = if (strings.isArabic) "تم رفض طلب الدفع السابق (Rejected)" else "Previous Payment Rejected",
                                                    fontWeight = FontWeight.Bold
                                                )
                                                latestCoursePayment.adminNote?.takeIf { it.isNotBlank() }?.let { note ->
                                                    Text(note, style = MaterialTheme.typography.bodySmall)
                                                }
                                            }
                                        }
                                    }
                                    Button(
                                        onClick = { onBuyViaWePay(firstLockedLessonId) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(50.dp)
                                            .testTag("unlock_wepay_button")
                                    ) {
                                        Icon(Icons.Default.Payments, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            "${strings.buyViaWePay} (${course.effectivePriceEgp.toInt()} ${strings.egpCurrency})",
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        } else {
                            if (!isEnrolled && !course.paid) {
                                Button(
                                    onClick = onEnrollFree,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("enroll_free_button")
                                ) {
                                    Text(strings.enrollFree, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                            if (!allLessonsCompleted && !isAdmin) {
                                Surface(
                                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
                                    shape = MaterialTheme.shapes.medium,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 8.dp)
                                ) {
                                    Text(
                                        text = if (strings.isArabic) {
                                            "أكمل جميع الدروس ($completedCount/${lessons.size}) لفتح الامتحان النهائي وإصدار الشهادة."
                                        } else {
                                            "Complete all lessons ($completedCount/${lessons.size}) to unlock the final exam and certificate."
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = onTakeExam,
                                    enabled = allLessonsCompleted || isAdmin,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("take_exam_button")
                                ) {
                                    Icon(Icons.Default.Quiz, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(strings.takeExam, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                if (existingCertificate != null) {
                                    OutlinedButton(
                                        onClick = { onViewCertificate(existingCertificate) },
                                        modifier = Modifier
                                            .height(48.dp)
                                            .testTag("view_cert_from_course_button")
                                    ) {
                                        Icon(Icons.Default.WorkspacePremium, contentDescription = null)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            groupedModules.forEach { (modulePair, moduleLessons) ->
                val moduleLabel = if (strings.isArabic) modulePair.second else modulePair.first
                item {
                    Text(
                        text = moduleLabel,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
                items(moduleLessons, key = { it.id }) { lesson ->
                    val isDone = lesson.id in completedLessonIds
                    val isFreePreview = !hasAccess && lesson.freePreview
                    val canPlayLesson = hasAccess || lesson.freePreview
                    val isReady = lesson.videoStatus == "READY" &&
                        (!lesson.youtubeIdAr.isNullOrBlank() || !lesson.youtubeIdEn.isNullOrBlank())
                    val thumbUrl = lesson.previewThumbnailUrl(preferredVideoLang)

                    Card(
                        onClick = {
                            if (canPlayLesson) onOpenLesson(lesson)
                            else if (course.paid) onBuyViaWePay(lesson.id)
                        },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.88f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("lesson_item_${lesson.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Outside 16:9 video preview thumbnail with duration badge & lock/play icon
                            Box(
                                modifier = Modifier
                                    .width(112.dp)
                                    .height(66.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.surface)
                            ) {
                                if (!thumbUrl.isNullOrBlank()) {
                                    AsyncImage(
                                        model = thumbUrl,
                                        contentDescription = if (strings.isArabic) lesson.titleAr else lesson.titleEn,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = if (!canPlayLesson) 0.52f else 0.25f))
                                )
                                Icon(
                                    imageVector = when {
                                        !canPlayLesson -> Icons.Default.Lock
                                        isDone -> Icons.Default.CheckCircle
                                        isReady -> Icons.Default.PlayCircle
                                        else -> Icons.Default.VideoLibrary
                                    },
                                    contentDescription = null,
                                    tint = when {
                                        isDone -> MaterialTheme.colorScheme.tertiary
                                        else -> Color.White
                                    },
                                    modifier = Modifier
                                        .size(28.dp)
                                        .align(Alignment.Center)
                                )
                                Surface(
                                    color = Color.Black.copy(alpha = 0.78f),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .padding(4.dp)
                                ) {
                                    Text(
                                        text = lesson.durationLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${lesson.orderIndex}. ${if (strings.isArabic) lesson.titleAr else lesson.titleEn}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = lesson.durationLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    StatusPill(
                                        text = when {
                                            isFreePreview -> strings.freePreviewBadge
                                            !canPlayLesson -> if (strings.isArabic) "مدفوع • يتطلب الدفع" else "Pay to Watch"
                                            isReady -> strings.readyBadge
                                            else -> strings.needsContentBadge
                                        },
                                        containerColor = when {
                                            isFreePreview -> MaterialTheme.colorScheme.tertiary.copy(alpha = 0.22f)
                                            !canPlayLesson -> MaterialTheme.colorScheme.primaryContainer
                                            isReady -> MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f)
                                            else -> MaterialTheme.colorScheme.secondaryContainer
                                        },
                                        contentColor = when {
                                            isFreePreview -> MaterialTheme.colorScheme.tertiary
                                            !canPlayLesson -> MaterialTheme.colorScheme.onPrimaryContainer
                                            isReady -> MaterialTheme.colorScheme.tertiary
                                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
