package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

private val NexoraDarkColorScheme = darkColorScheme(
    primary = NexoraMauve,
    onPrimary = NexoraTextWhite,
    primaryContainer = NexoraMauveContainer,
    onPrimaryContainer = NexoraLavender,
    secondary = NexoraLavender,
    onSecondary = NexoraBlackPure,
    secondaryContainer = NexoraCardElevated,
    onSecondaryContainer = NexoraTextWhite,
    tertiary = NexoraSuccess,
    onTertiary = NexoraBlackPure,
    background = NexoraNavyBg,
    onBackground = NexoraTextWhite,
    surface = NexoraNavySurface,
    onSurface = NexoraTextWhite,
    surfaceVariant = NexoraCardDark,
    onSurfaceVariant = NexoraSilver,
    outline = NexoraBorderSilver,
    outlineVariant = NexoraCardElevated,
    error = NexoraError,
    onError = NexoraTextWhite,
    errorContainer = NexoraErrorContainer,
    onErrorContainer = NexoraError
)

private val NexoraLightColorScheme = lightColorScheme(
    primary = NexoraLightMauve,
    onPrimary = NexoraLightSurface,
    primaryContainer = NexoraLightCard,
    onPrimaryContainer = NexoraLightMauve,
    secondary = NexoraMauve,
    onSecondary = NexoraLightSurface,
    secondaryContainer = NexoraLightCard,
    onSecondaryContainer = NexoraLightInk,
    tertiary = NexoraSuccess,
    onTertiary = NexoraLightSurface,
    background = NexoraLightBg,
    onBackground = NexoraLightInk,
    surface = NexoraLightSurface,
    onSurface = NexoraLightInk,
    surfaceVariant = NexoraLightCard,
    onSurfaceVariant = NexoraLightMuted,
    outline = NexoraLightBorder,
    outlineVariant = NexoraLightCard,
    error = NexoraError,
    onError = NexoraLightSurface
)

private val NexoraShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun NexoraTheme(
    darkTheme: Boolean = true,
    isArabic: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) NexoraDarkColorScheme else NexoraLightColorScheme
    val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
    val typography = buildNexoraTypography(isArabic = isArabic)

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = typography,
            shapes = NexoraShapes,
            content = content
        )
    }
}
