package com.example.ui.screens

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.core.AppStrings
import com.example.core.SecurityUtils
import com.example.model.*
import com.example.ui.components.StatusPill
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WePayCheckoutScreen(
    strings: AppStrings,
    course: Course,
    wePayNumber: String,
    studentEmail: String = "",
    targetLessonTitle: String? = null,
    existingCoursePayment: PaymentRequest? = null,
    appliedPromo: PromoCode?,
    busy: Boolean,
    initialFullName: String = "",
    initialProofBase64: String? = null,
    encodeReceipt: suspend (android.net.Uri) -> String?,
    onApplyPromo: (String) -> Unit,
    onSubmitPayment: (String, String, String, String, String?) -> Unit,
    onNumberCopied: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    val transferNumber = wePayNumber.ifBlank { "01557701433" }
    val paymentMethods = remember(strings.isArabic) {
        listOf(
            "WE Pay" to if (strings.isArabic) "محفظة وي باي (WE Pay)" else "WE Pay Wallet",
            "InstaPay" to if (strings.isArabic) "انستا باي (InstaPay)" else "InstaPay",
            "Vodafone Cash" to if (strings.isArabic) "فودافون كاش" else "Vodafone Cash",
            "Orange Cash" to if (strings.isArabic) "أورنج كاش" else "Orange Cash",
            "Etisalat Cash" to if (strings.isArabic) "اتصالات كاش" else "Etisalat Cash"
        )
    }

    var selectedMethod by remember { mutableStateOf("WE Pay") }
    var copiedBanner by remember { mutableStateOf(false) }
    var promoInput by remember { mutableStateOf("") }
    val sanitizedInitialName = remember(initialFullName) {
        if (initialFullName.contains('@')) "" else initialFullName
    }
    var studentTripleName by remember(sanitizedInitialName) { mutableStateOf(sanitizedInitialName) }
    var senderPhone by remember { mutableStateOf("") }
    var transactionRef by remember { mutableStateOf("") }
    var proofBase64 by remember(initialProofBase64) { mutableStateOf(initialProofBase64) }
    var receiptError by remember { mutableStateOf(false) }

    val baseAmount = course.effectivePriceEgp
    val finalAmount = if (appliedPromo != null) {
        (baseAmount * (100.0 - appliedPromo.discountPercent) / 100.0).coerceAtLeast(0.0)
    } else baseAmount

    // Zero-permission Android Photo Picker (Play Policy compliant)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val encoded = encodeReceipt(uri)
                proofBase64 = encoded
                receiptError = encoded.isNullOrBlank()
            }
        }
    }

    Scaffold(
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                title = { Text(strings.wePayTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("wepay_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .testTag("wepay_checkout_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (existingCoursePayment?.status != "APPROVED") {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("checkout_paid_course_notice")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            Icons.Default.Payments,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = if (strings.isArabic) {
                                "هذا الكورس مدفوع. لمشاهدة الفيديوهات والدروس، يرجى تحويل رسوم الكورس أولاً."
                            } else {
                                "This course is paid. To watch the videos and lessons, please transfer the course fee first."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            if (!targetLessonTitle.isNullOrBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("checkout_target_lesson_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Text(
                            text = if (strings.isArabic) {
                                "الدرس المطلوب مقفول: «$targetLessonTitle» — أتمم الدفع ليتم فتح الكورس وإعادتك للدرس تلقائيًا."
                            } else {
                                "Locked lesson: \"$targetLessonTitle\" — complete verified payment to unlock and jump straight back."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            if (existingCoursePayment != null) {
                Surface(
                    color = when (existingCoursePayment.status) {
                        "APPROVED" -> MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f)
                        "REJECTED" -> MaterialTheme.colorScheme.errorContainer
                        else -> MaterialTheme.colorScheme.primaryContainer
                    },
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("checkout_payment_status_card")
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (strings.isArabic) "حالة الدفع:" else "Payment Status:",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                            StatusPill(
                                text = existingCoursePayment.displayStatus(strings.isArabic),
                                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f),
                                contentColor = when (existingCoursePayment.status) {
                                    "APPROVED" -> MaterialTheme.colorScheme.tertiary
                                    "REJECTED" -> MaterialTheme.colorScheme.error
                                    else -> MaterialTheme.colorScheme.primary
                                }
                            )
                        }
                        Text(
                            text = "${existingCoursePayment.amountEgp.toInt()} ${strings.egpCurrency} • Ref: ${existingCoursePayment.transactionRef}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        existingCoursePayment.adminNote?.takeIf { it.isNotBlank() }?.let { note ->
                            Text(text = note, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = if (strings.isArabic) course.titleAr else course.titleEn,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (studentEmail.isNotBlank()) {
                        Text(
                            text = if (strings.isArabic) "حساب الطالب: $studentEmail" else "Student Account: $studentEmail",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.testTag("checkout_student_email")
                        )
                    }
                    Text(
                        text = strings.wePayInstructions,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Text(
                        text = if (strings.isArabic) "طريقة الدفع:" else "Payment Method:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )

                    androidx.compose.foundation.lazy.LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(paymentMethods.size) { idx ->
                            val (methodId, methodLabel) = paymentMethods[idx]
                            FilterChip(
                                selected = selectedMethod == methodId,
                                onClick = { selectedMethod = methodId },
                                leadingIcon = if (selectedMethod == methodId) {
                                    { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                } else null,
                                label = { Text(methodLabel) },
                                modifier = Modifier.testTag("payment_method_${methodId.replace(" ", "_")}")
                            )
                        }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                val chosenLabel = paymentMethods.firstOrNull { it.first == selectedMethod }?.second ?: selectedMethod
                                Text(
                                    text = if (strings.isArabic) "رقم محفظة WE Pay ($chosenLabel):" else "WE Pay Wallet Number ($chosenLabel):",
                                    style = MaterialTheme.typography.labelSmall
                                )
                                Text(
                                    text = transferNumber,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            FilledTonalButton(
                                onClick = {
                                    clipboard.setText(AnnotatedString(transferNumber))
                                    copiedBanner = true
                                    onNumberCopied()
                                },
                                modifier = Modifier.testTag("copy_wepay_button")
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = strings.copyNumber, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.copyNumber)
                            }
                        }
                    }
                    if (copiedBanner) {
                        Text(
                            text = strings.numberCopied,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.tertiary
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (strings.isArabic) "سعر الكورس المطلوب:" else "Course Price:",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = "${finalAmount.toInt()} ${strings.egpCurrency}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = promoInput,
                    onValueChange = { promoInput = it.uppercase() },
                    label = { Text(strings.promoCodeLabel) },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("promo_code_input")
                )
                FilledTonalButton(
                    onClick = { onApplyPromo(promoInput) },
                    enabled = !busy && promoInput.trim().isNotEmpty(),
                    modifier = Modifier
                        .height(54.dp)
                        .testTag("apply_promo_button")
                ) {
                    Text(strings.applyPromo)
                }
            }

            OutlinedTextField(
                value = studentTripleName,
                onValueChange = { studentTripleName = it },
                label = { Text(strings.studentTripleNameLabel) },
                supportingText = {
                    Text(
                        text = if (strings.isArabic) {
                            "الاسم الثلاثي كاملًا (الاسم الأول + اسم الأب + اسم العائلة) للتسجيل وإصدار الشهادة"
                        } else {
                            "Full 3-part name (First + Father + Family) for enrollment & certificate"
                        }
                    )
                },
                isError = studentTripleName.isNotBlank() && !SecurityUtils.isTripleName(studentTripleName),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("student_triple_name_input")
            )

            OutlinedTextField(
                value = senderPhone,
                onValueChange = { senderPhone = it },
                label = { Text(strings.senderPhoneLabel) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("sender_phone_input")
            )

            OutlinedTextField(
                value = transactionRef,
                onValueChange = { transactionRef = it },
                label = { Text(strings.transactionRefLabel) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("transaction_ref_input")
            )

            val proofBitmap = remember(proofBase64) {
                proofBase64?.let { b64 ->
                    runCatching {
                        val bytes = Base64.decode(b64, Base64.DEFAULT)
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
                    }.getOrNull()
                }
            }

            OutlinedButton(
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                colors = if (proofBase64 != null) {
                    ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.tertiary)
                } else {
                    ButtonDefaults.outlinedButtonColors()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("attach_receipt_button")
            ) {
                Icon(
                    imageVector = if (proofBase64 != null) Icons.Default.CheckCircle else Icons.Default.AddPhotoAlternate,
                    contentDescription = null
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (proofBase64 != null) strings.receiptAttached else strings.attachReceipt)
            }

            if (receiptError) {
                Text(
                    text = if (strings.isArabic) {
                        "تعذر قراءة الصورة المختارة، يرجى اختيار لقطة شاشة واضحة لوصل التحويل."
                    } else {
                        "Could not read the selected image, please pick a clear transfer receipt screenshot."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            if (proofBitmap != null) {
                Image(
                    bitmap = proofBitmap,
                    contentDescription = strings.receiptAttached,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(MaterialTheme.shapes.medium)
                        .testTag("receipt_preview_image")
                )
            }

            val hasTripleName = SecurityUtils.isTripleName(studentTripleName)
            val hasValidPhone = senderPhone.trim().length >= 6
            val hasValidRef = transactionRef.trim().length >= 2
            val hasOpenOrApprovedPayment = existingCoursePayment?.status in listOf("PENDING", "APPROVED")
            val canSubmit = !busy && !hasOpenOrApprovedPayment && hasTripleName && hasValidPhone && hasValidRef

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = if (strings.isArabic) {
                            "خطوات التأكيد وتفعيل الكورس:"
                        } else {
                            "Verification & Automatic Enrollment:"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = (if (hasTripleName) "✓ " else "• ") +
                            if (strings.isArabic) "الاسم الثلاثي كاملًا (يظهر في الشهادة)" else "Full 3-part student name (printed on certificate)",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (hasTripleName) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = (if (hasValidPhone) "✓ " else "• ") +
                            if (strings.isArabic) "رقم المحفظة / الهاتف المحوّل منه (6 أرقام فأكثر)" else "Sender wallet/phone (6+ digits)",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (hasValidPhone) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = (if (hasValidRef) "✓ " else "• ") +
                            if (strings.isArabic) "رقم العملية أو مرجع التحويل إلى $transferNumber" else "Transaction reference ID to $transferNumber",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (hasValidRef) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = if (strings.isArabic) {
                            "• يبقى الطلب «قيد المراجعة (Pending)» حتى يتم التحقق من الدفع وتفعيل الكورس تلقائيًا."
                        } else {
                            "• Payment remains Pending until verified by Admin, then enrolls & unlocks automatically."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Button(
                onClick = {
                    onSubmitPayment(
                        selectedMethod,
                        studentTripleName.trim(),
                        senderPhone,
                        transactionRef,
                        proofBase64
                    )
                },
                enabled = canSubmit,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("submit_payment_button")
            ) {
                if (busy) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Text(
                        text = if (hasOpenOrApprovedPayment) {
                            existingCoursePayment?.displayStatus(strings.isArabic) ?: strings.paymentPendingReview
                        } else {
                            strings.submitPayment
                        },
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(
    strings: AppStrings,
    notifications: List<StudentNotification>,
    onMarkRead: (String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    Scaffold(
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                title = { Text(strings.notificationsTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("notifications_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("notifications_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (notifications.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (strings.isArabic) "لا توجد إشعارات حاليًا" else "No notifications yet",
                            modifier = Modifier.padding(20.dp)
                        )
                    }
                }
            } else {
                items(notifications, key = { it.id }) { notif ->
                    Card(
                        onClick = { if (!notif.read) onMarkRead(notif.id) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (notif.read) {
                                MaterialTheme.colorScheme.surfaceVariant
                            } else {
                                MaterialTheme.colorScheme.primaryContainer
                            }
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = if (strings.isArabic) notif.titleAr else notif.titleEn,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (strings.isArabic) notif.bodyAr else notif.bodyEn,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SupportScreen(
    strings: AppStrings,
    tickets: List<SupportTicket>,
    busy: Boolean,
    onSubmitTicket: (String, String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    var subject by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    Scaffold(
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                title = { Text(strings.supportTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("support_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("support_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = MaterialTheme.shapes.large,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = subject,
                            onValueChange = { subject = it },
                            label = { Text(strings.subjectLabel) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("support_subject_input")
                        )
                        OutlinedTextField(
                            value = message,
                            onValueChange = { message = it },
                            label = { Text(strings.messageLabel) },
                            minLines = 3,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("support_message_input")
                        )
                        Button(
                            onClick = {
                                onSubmitTicket(subject, message)
                                subject = ""
                                message = ""
                            },
                            enabled = !busy && subject.trim().isNotEmpty() && message.trim().isNotEmpty(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("support_send_button")
                        ) {
                            Text(strings.sendMessage, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            items(tickets, key = { it.id }) { t ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(t.subject, fontWeight = FontWeight.Bold)
                            StatusPill(
                                text = t.status,
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Text(t.message, style = MaterialTheme.typography.bodySmall)
                        t.adminReply?.takeIf { it.isNotBlank() }?.let { reply ->
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                            Text(
                                text = "${if (strings.isArabic) "رد الإدارة:" else "Admin Reply:"} $reply",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }
        }
    }
}
