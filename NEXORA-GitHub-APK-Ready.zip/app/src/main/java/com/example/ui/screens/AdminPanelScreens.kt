package com.example.ui.screens

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.AppStrings
import com.example.core.SecurityUtils
import com.example.data.AiAdminUpdatePlan
import com.example.data.AiCourseDraft
import com.example.data.VideoVerificationResult
import com.example.model.*
import com.example.ui.components.StatusPill
import com.example.viewmodel.AdminStudentDetail

@Composable
fun AdminPanelScreen(
    strings: AppStrings,
    courses: List<Course>,
    payments: List<PaymentRequest>,
    users: List<UserProfile>,
    tickets: List<SupportTicket>,
    promos: List<PromoCode>,
    platformConfig: PlatformConfig,
    selectedCourseLessons: List<Lesson>,
    videoVerifyResult: VideoVerificationResult?,
    verifyingVideo: Boolean,
    aiDraft: AiCourseDraft?,
    aiGenerating: Boolean,
    aiUpdatePlan: AiAdminUpdatePlan?,
    aiUpdatePlanning: Boolean,
    busy: Boolean,
    selectedAdminStudentDetail: AdminStudentDetail? = null,
    onSelectCourseForLessons: (String) -> Unit,
    onReviewPayment: (PaymentRequest, Boolean, String) -> Unit,
    onSaveCourse: (Course) -> Unit,
    onDeleteCourse: (String) -> Unit,
    onVerifyYoutube: (String) -> Unit,
    onClearVideoVerify: () -> Unit,
    onSaveLesson: (Lesson) -> Unit,
    onGenerateAiCourse: (String, String) -> Unit,
    onPublishAiCourse: (Boolean, Double) -> Unit,
    onClearAiDraft: () -> Unit,
    onGenerateAiUpdatePlan: (String) -> Unit,
    onApplyAiUpdatePlan: () -> Unit,
    onClearAiUpdatePlan: () -> Unit,
    onToggleStudentStatus: (String, Boolean) -> Unit,
    onSetAnnualSubscription: (String, Boolean) -> Unit = { _, _ -> },
    onCorrectStudentName: (String, String, String, String, Boolean) -> Unit = { _, _, _, _, _ -> },
    onFetchStudentDetail: (String) -> Unit = {},
    onClearStudentDetail: () -> Unit = {},
    onToggleCertificateRevoked: (String, Boolean) -> Unit = { _, _ -> },
    onSavePromo: (String, Long, String) -> Unit,
    onTogglePromoActive: (String, Boolean) -> Unit,
    onGeneratePromoBatch: (Long, Int) -> Unit,
    onSendPromoToStudent: (String, PromoCode, String) -> Unit,
    onReplyTicket: (String, String) -> Unit,
    onUpdateConfig: (String, String, String, String, String, String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        if (strings.isArabic) "المدفوعات" else "Payments",
        if (strings.isArabic) "الكورسات والـ AI" else "Courses & AI",
        if (strings.isArabic) "الطلاب" else "Students",
        if (strings.isArabic) "الأكواد والإعدادات" else "Promos & Config"
    )

    var sendPromoDialogInitialPromo by remember { mutableStateOf<PromoCode?>(null) }
    var sendPromoDialogInitialStudent by remember { mutableStateOf<UserProfile?>(null) }
    var showSendPromoDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_panel_screen")
    ) {
        Surface(
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (strings.isArabic) {
                            "لوحة تحكم الإدارة الحصرية • هبة نصر"
                        } else {
                            "Exclusive Admin Console • Heba Nasr"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                StatusPill(
                    text = if (strings.isArabic) "مزامنة فورية" else "Live Sync",
                    containerColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.22f),
                    contentColor = MaterialTheme.colorScheme.tertiary
                )
            }
        }

        TabRow(selectedTabIndex = selectedTab) {
            tabs.forEachIndexed { idx, label ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = { selectedTab = idx },
                    text = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    modifier = Modifier.testTag("admin_tab_$idx")
                )
            }
        }

        when (selectedTab) {
            0 -> AdminPaymentsTab(strings, payments, busy, onReviewPayment)
            1 -> AdminCoursesAndAiTab(
                strings = strings,
                courses = courses,
                selectedCourseLessons = selectedCourseLessons,
                videoVerifyResult = videoVerifyResult,
                verifyingVideo = verifyingVideo,
                aiDraft = aiDraft,
                aiGenerating = aiGenerating,
                aiUpdatePlan = aiUpdatePlan,
                aiUpdatePlanning = aiUpdatePlanning,
                busy = busy,
                onSelectCourseForLessons = onSelectCourseForLessons,
                onSaveCourse = onSaveCourse,
                onDeleteCourse = onDeleteCourse,
                onVerifyYoutube = onVerifyYoutube,
                onClearVideoVerify = onClearVideoVerify,
                onSaveLesson = onSaveLesson,
                onGenerateAiCourse = onGenerateAiCourse,
                onPublishAiCourse = onPublishAiCourse,
                onClearAiDraft = onClearAiDraft,
                onGenerateAiUpdatePlan = onGenerateAiUpdatePlan,
                onApplyAiUpdatePlan = onApplyAiUpdatePlan,
                onClearAiUpdatePlan = onClearAiUpdatePlan
            )
            2 -> AdminStudentsTab(
                strings = strings,
                users = users,
                busy = busy,
                selectedAdminStudentDetail = selectedAdminStudentDetail,
                onToggleStudentStatus = onToggleStudentStatus,
                onSetAnnualSubscription = onSetAnnualSubscription,
                onCorrectStudentName = onCorrectStudentName,
                onFetchStudentDetail = onFetchStudentDetail,
                onClearStudentDetail = onClearStudentDetail,
                onToggleCertificateRevoked = onToggleCertificateRevoked,
                onOpenSendPromoForStudent = { student ->
                    sendPromoDialogInitialStudent = student
                    sendPromoDialogInitialPromo = promos.firstOrNull { it.active } ?: promos.firstOrNull()
                    showSendPromoDialog = true
                }
            )
            else -> AdminSettingsTab(
                strings = strings,
                promos = promos,
                tickets = tickets,
                platformConfig = platformConfig,
                busy = busy,
                onSavePromo = onSavePromo,
                onTogglePromoActive = onTogglePromoActive,
                onGeneratePromoBatch = onGeneratePromoBatch,
                onOpenSendPromo = { promo ->
                    sendPromoDialogInitialPromo = promo
                    sendPromoDialogInitialStudent = users.firstOrNull {
                        !it.email.equals("heba55nasr@gmail.com", ignoreCase = true)
                    } ?: users.firstOrNull()
                    showSendPromoDialog = true
                },
                onReplyTicket = onReplyTicket,
                onUpdateConfig = onUpdateConfig
            )
        }
    }

    if (showSendPromoDialog) {
        SendPromoToStudentDialog(
            strings = strings,
            promos = promos,
            users = users,
            initialPromo = sendPromoDialogInitialPromo,
            initialStudent = sendPromoDialogInitialStudent,
            busy = busy,
            onDismiss = { showSendPromoDialog = false },
            onSend = { userId, promo, note ->
                onSendPromoToStudent(userId, promo, note)
                showSendPromoDialog = false
            }
        )
    }
}

@Composable
private fun SendPromoToStudentDialog(
    strings: AppStrings,
    promos: List<PromoCode>,
    users: List<UserProfile>,
    initialPromo: PromoCode?,
    initialStudent: UserProfile?,
    busy: Boolean,
    onDismiss: () -> Unit,
    onSend: (String, PromoCode, String) -> Unit
) {
    val activePromos = remember(promos) { promos.filter { it.active }.ifEmpty { promos } }
    var selectedPromo by remember(initialPromo, activePromos) {
        mutableStateOf(initialPromo ?: activePromos.firstOrNull())
    }
    var selectedStudent by remember(initialStudent, users) {
        mutableStateOf(initialStudent ?: users.firstOrNull())
    }
    var studentQuery by remember { mutableStateOf("") }
    var promoQuery by remember { mutableStateOf("") }
    var customNote by remember { mutableStateOf("") }

    val filteredPromos = remember(activePromos, promoQuery) {
        val q = promoQuery.trim().uppercase()
        if (q.isEmpty()) activePromos else activePromos.filter {
            it.code.contains(q) || it.description.uppercase().contains(q)
        }
    }
    val filteredUsers = remember(users, studentQuery) {
        val q = studentQuery.trim().lowercase()
        if (q.isEmpty()) users else users.filter {
            it.fullName.lowercase().contains(q) || it.email.lowercase().contains(q)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (strings.isArabic) "إرسال كود خصم لطالب" else "Send Promo Code to Student",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 430.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = if (strings.isArabic) "1. اختر كود الخصم (${activePromos.size} متاح)" else "1. Choose Promo Code (${activePromos.size})",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                OutlinedTextField(
                    value = promoQuery,
                    onValueChange = { promoQuery = it.uppercase() },
                    label = { Text(if (strings.isArabic) "تصفية الأكواد" else "Filter promo codes") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filteredPromos, key = { it.code }) { promo ->
                        val isSel = selectedPromo?.code == promo.code
                        FilterChip(
                            selected = isSel,
                            onClick = { selectedPromo = promo },
                            label = { Text("${promo.code} (-${promo.discountPercent}%)") }
                        )
                    }
                }

                HorizontalDivider()

                Text(
                    text = if (strings.isArabic) "2. اختر الطالب المستلم" else "2. Select Student",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                OutlinedTextField(
                    value = studentQuery,
                    onValueChange = { studentQuery = it },
                    label = { Text(if (strings.isArabic) "ابحث باسم أو بريد الطالب" else "Search student name or email") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (filteredUsers.isEmpty()) {
                    Text(
                        text = if (strings.isArabic) "لا يوجد طلاب مسجلون مطابقون حاليًا." else "No matching registered students.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    filteredUsers.take(12).forEach { student ->
                        val sid = student.userId.ifBlank { student.id }
                        val isSel = (selectedStudent?.userId?.ifBlank { selectedStudent?.id }) == sid
                        Surface(
                            color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (isSel) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedStudent = student }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(student.fullName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    Text(student.email, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                if (isSel) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = customNote,
                    onValueChange = { customNote = it },
                    label = { Text(if (strings.isArabic) "رسالة اختيارية للطالب" else "Optional message to student") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            val promo = selectedPromo
            val student = selectedStudent
            val targetUid = student?.userId?.ifBlank { student.id }.orEmpty()
            Button(
                onClick = {
                    if (promo != null && targetUid.isNotEmpty()) {
                        onSend(targetUid, promo, customNote)
                    }
                },
                enabled = !busy && promo != null && targetUid.isNotEmpty(),
                modifier = Modifier.testTag("confirm_send_promo_button")
            ) {
                Text(if (strings.isArabic) "إرسال الكود الآن" else "Send Code")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (strings.isArabic) "إغلاق" else "Cancel")
            }
        }
    )
}

@Composable
private fun AdminPaymentsTab(
    strings: AppStrings,
    payments: List<PaymentRequest>,
    busy: Boolean,
    onReviewPayment: (PaymentRequest, Boolean, String) -> Unit
) {
    var notesByPayment by remember { mutableStateOf<Map<String, String>>(emptyMap()) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        if (payments.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (strings.isArabic) "لا توجد طلبات دفع حاليًا" else "No payment requests yet",
                        modifier = Modifier.padding(18.dp)
                    )
                }
            }
        }
        items(payments, key = { it.id }) { p ->
            val currentNote = notesByPayment[p.id].orEmpty()
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(p.studentName, fontWeight = FontWeight.Bold)
                        StatusPill(
                            text = p.displayStatus(strings.isArabic),
                            containerColor = when (p.status) {
                                "APPROVED" -> MaterialTheme.colorScheme.tertiary.copy(alpha = 0.25f)
                                "REJECTED" -> MaterialTheme.colorScheme.errorContainer
                                else -> MaterialTheme.colorScheme.primaryContainer
                            },
                            contentColor = when (p.status) {
                                "APPROVED" -> MaterialTheme.colorScheme.tertiary
                                "REJECTED" -> MaterialTheme.colorScheme.error
                                else -> MaterialTheme.colorScheme.onPrimaryContainer
                            }
                        )
                    }
                    Text("${p.courseTitle} • ${p.amountEgp.toInt()} EGP • ${p.paymentMethod}${p.promoCode?.let { " (Promo: $it)" } ?: ""}")
                    Text(
                        text = "${p.studentEmail} | Sender: ${p.senderPhone} | Ref: ${p.transactionRef}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    p.targetLessonId?.takeIf { it.isNotBlank() }?.let { lessonId ->
                        Text(
                            text = if (strings.isArabic) "الدرس المطلوب: $lessonId" else "Target lesson: $lessonId",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }

                    val proofBmp = remember(p.proofImageBase64) {
                        p.proofImageBase64?.let { b64 ->
                            runCatching {
                                val bytes = Base64.decode(b64, Base64.DEFAULT)
                                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
                            }.getOrNull()
                        }
                    }
                    StatusPill(
                        text = if (proofBmp != null) {
                            if (strings.isArabic) "صورة وصل التحويل مرفقة ✓" else "Transfer Receipt Attached ✓"
                        } else {
                            if (strings.isArabic) "بدون صورة وصل (تحقق من الرقم المرجعي)" else "No Receipt Image (Verify Ref ID)"
                        },
                        containerColor = if (proofBmp != null) {
                            MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f)
                        } else {
                            MaterialTheme.colorScheme.secondaryContainer
                        },
                        contentColor = if (proofBmp != null) {
                            MaterialTheme.colorScheme.tertiary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                    if (proofBmp != null) {
                        Image(
                            bitmap = proofBmp,
                            contentDescription = "Transfer Receipt Proof",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                        )
                    }

                    if (p.status == "PENDING") {
                        OutlinedTextField(
                            value = currentNote,
                            onValueChange = { updated ->
                                notesByPayment = notesByPayment + (p.id to updated)
                            },
                            label = { Text(if (strings.isArabic) "ملاحظة الإدارة" else "Admin Note") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { onReviewPayment(p, true, currentNote) },
                                enabled = !busy,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("approve_payment_${p.id}")
                            ) {
                                Text(if (strings.isArabic) "قبول وتفعيل" else "Approve")
                            }
                            OutlinedButton(
                                onClick = { onReviewPayment(p, false, currentNote) },
                                enabled = !busy,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("reject_payment_${p.id}")
                            ) {
                                Text(if (strings.isArabic) "رفض" else "Reject")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminCoursesAndAiTab(
    strings: AppStrings,
    courses: List<Course>,
    selectedCourseLessons: List<Lesson>,
    videoVerifyResult: VideoVerificationResult?,
    verifyingVideo: Boolean,
    aiDraft: AiCourseDraft?,
    aiGenerating: Boolean,
    aiUpdatePlan: AiAdminUpdatePlan?,
    aiUpdatePlanning: Boolean,
    busy: Boolean,
    onSelectCourseForLessons: (String) -> Unit,
    onSaveCourse: (Course) -> Unit,
    onDeleteCourse: (String) -> Unit,
    onVerifyYoutube: (String) -> Unit,
    onClearVideoVerify: () -> Unit,
    onSaveLesson: (Lesson) -> Unit,
    onGenerateAiCourse: (String, String) -> Unit,
    onPublishAiCourse: (Boolean, Double) -> Unit,
    onClearAiDraft: () -> Unit,
    onGenerateAiUpdatePlan: (String) -> Unit,
    onApplyAiUpdatePlan: () -> Unit,
    onClearAiUpdatePlan: () -> Unit
) {
    var editingCourse by remember { mutableStateOf<Course?>(null) }
    var managingCourseLessonsId by remember { mutableStateOf<String?>(null) }
    var editingLesson by remember { mutableStateOf<Lesson?>(null) }

    var aiUpdateInstruction by remember { mutableStateOf("") }

    var aiTopic by remember { mutableStateOf("") }
    var aiLevel by remember { mutableStateOf("Beginner to Intermediate") }
    var aiPaid by remember { mutableStateOf(true) }
    var aiPrice by remember { mutableStateOf("150") }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_courses_ai_list")
    ) {
        // 1. AI Smart Update & Live Sync Assistant
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.72f)),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Bolt, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (strings.isArabic) {
                                "المساعد الذكي للتعديل والمزامنة الفورية (AI Live Sync)"
                            } else {
                                "AI Smart Platform Updater & Live Sync"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = if (strings.isArabic) {
                            "اكتبي أي تعديل على الكورسات أو الأسعار أو إضافة درس أو إعلان، وسيجهز الذكاء الاصطناعي الخطة وتصل تلقائيًا لهواتف جميع الطلاب فور الاعتماد."
                        } else {
                            "Describe any course edit, discount, lesson addition, or banner update. Once applied, it syncs automatically to all users' phones."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val quickPrompts = if (strings.isArabic) {
                            listOf(
                                "خصم 20% على كورس الأمن السيبراني وإشعار الطلاب",
                                "أضف درس تطبيقي جديد في كورس البرمجة",
                                "تحديث بنر العروض بعرض نهاية الأسبوع"
                            )
                        } else {
                            listOf(
                                "Apply 20% discount to Cybersecurity and notify students",
                                "Add a practical AI bonus lesson to Programming",
                                "Update platform offer banner for this week"
                            )
                        }
                        items(quickPrompts) { sample ->
                            AssistChip(
                                onClick = { aiUpdateInstruction = sample },
                                label = { Text(sample, maxLines = 1) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = aiUpdateInstruction,
                        onValueChange = { aiUpdateInstruction = it },
                        label = {
                            Text(
                                if (strings.isArabic) "أمر التعديل أو الإضافة بالذكاء الاصطناعي"
                                else "AI update / addition instruction"
                            )
                        },
                        minLines = 2,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ai_update_instruction_input")
                    )
                    Button(
                        onClick = { onGenerateAiUpdatePlan(aiUpdateInstruction) },
                        enabled = !aiUpdatePlanning && aiUpdateInstruction.trim().isNotEmpty(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ai_plan_update_button")
                    ) {
                        if (aiUpdatePlanning) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (strings.isArabic) "جاري تحليل وتجهيز التعديلات..." else "Planning live update...")
                        } else {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (strings.isArabic) "تجهيز التعديل بالذكاء الاصطناعي" else "Plan Update with AI")
                        }
                    }

                    if (aiUpdatePlan != null) {
                        HorizontalDivider()
                        Text(
                            text = if (strings.isArabic) aiUpdatePlan.summaryAr else aiUpdatePlan.summaryEn,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        if (aiUpdatePlan.coursePatches.isNotEmpty()) {
                            aiUpdatePlan.coursePatches.forEach { p ->
                                Text(
                                    text = "• ${p.courseId}: " + listOfNotNull(
                                        p.priceEgp?.let { "${it.toInt()} EGP" },
                                        p.discountPercent?.let { "-$it%" },
                                        p.titleAr,
                                        p.published?.let { if (it) "Published" else "Hidden" }
                                    ).joinToString(" | ").ifBlank { "Description updated" },
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                        aiUpdatePlan.newLesson?.let { nl ->
                            Text(
                                text = "+ Lesson (${nl.targetCourseId}): ${if (strings.isArabic) nl.titleAr else nl.titleEn} [${nl.verificationNote}]",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        if (!aiUpdatePlan.updateOfferBannerAr.isNullOrBlank() || !aiUpdatePlan.updateAnnouncementAr.isNullOrBlank()) {
                            Text(
                                text = if (strings.isArabic) "سيتم تحديث إعلانات الصفحة الرئيسية تلقائيًا." else "Home banners will update live.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                        if (!aiUpdatePlan.broadcastBodyAr.isNullOrBlank()) {
                            Text(
                                text = "Broadcast: ${if (strings.isArabic) aiUpdatePlan.broadcastBodyAr else aiUpdatePlan.broadcastBodyEn}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    onApplyAiUpdatePlan()
                                    aiUpdateInstruction = ""
                                },
                                enabled = !busy,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("ai_apply_plan_button")
                            ) {
                                Text(if (strings.isArabic) "تطبيق ومزامنة للهواتف" else "Apply & Sync Live")
                            }
                            OutlinedButton(
                                onClick = onClearAiUpdatePlan,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (strings.isArabic) "إلغاء" else "Discard")
                            }
                        }
                    }
                }
            }
        }

        // 2. AI Course Builder Card (Firebase AI Logic + YouTube Verifier)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (strings.isArabic) "منشئ الكورسات الذكي (AI Course Builder)" else "AI Course Builder",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    OutlinedTextField(
                        value = aiTopic,
                        onValueChange = { aiTopic = it },
                        label = { Text(if (strings.isArabic) "موضوع الكورس الجديد (مثال: UI/UX Design)" else "New Course Topic") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ai_topic_input")
                    )
                    OutlinedTextField(
                        value = aiLevel,
                        onValueChange = { aiLevel = it },
                        label = { Text(if (strings.isArabic) "المستوى" else "Target Level") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = { onGenerateAiCourse(aiTopic, aiLevel) },
                        enabled = !aiGenerating && aiTopic.trim().isNotEmpty(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ai_generate_course_button")
                    ) {
                        if (aiGenerating) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (strings.isArabic) "جاري البناء والتحقق من الروابط..." else "Building & verifying videos...")
                        } else {
                            Text(if (strings.isArabic) "توليد منهج + امتحان بالذكاء الاصطناعي" else "Generate Course Draft with AI")
                        }
                    }

                    if (aiDraft != null) {
                        HorizontalDivider()
                        Text(
                            text = "${aiDraft.titleEn} / ${aiDraft.titleAr}",
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${aiDraft.lessons.size} lessons • ${aiDraft.lessons.count { it.verifiedVideoId != null }} verified videos • ${aiDraft.questions.size} exam questions",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Checkbox(checked = aiPaid, onCheckedChange = { aiPaid = it })
                            Text(strings.paidBadge)
                            if (aiPaid) {
                                OutlinedTextField(
                                    value = aiPrice,
                                    onValueChange = { aiPrice = it },
                                    label = { Text("EGP") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.width(120.dp)
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onPublishAiCourse(aiPaid, aiPrice.toDoubleOrNull() ?: 150.0) },
                                enabled = !busy,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("ai_publish_course_button")
                            ) {
                                Text(if (strings.isArabic) "نشر الكورس فورًا" else "Publish Live")
                            }
                            OutlinedButton(
                                onClick = onClearAiDraft,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (strings.isArabic) "إلغاء" else "Discard")
                            }
                        }
                    }
                }
            }
        }

        // 3. Course Manager List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (strings.isArabic) "إدارة الكورسات والأسعار" else "Course & Pricing Manager",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                FilledTonalButton(
                    onClick = {
                        editingCourse = Course(
                            id = "",
                            titleAr = "",
                            titleEn = "",
                            category = "Technology",
                            paid = true,
                            priceEgp = 150.0
                        )
                    },
                    modifier = Modifier.testTag("admin_add_course_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (strings.isArabic) "كورس جديد" else "New Course")
                }
            }
        }

        items(courses, key = { it.id }) { course ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(if (strings.isArabic) course.titleAr else course.titleEn, fontWeight = FontWeight.Bold)
                            Text(
                                text = if (course.paid) "${course.priceEgp.toInt()} EGP (-${course.discountPercent}%)" else strings.freeBadge,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                        IconButton(onClick = { editingCourse = course }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Course")
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                managingCourseLessonsId = if (managingCourseLessonsId == course.id) null else course.id
                                onSelectCourseForLessons(course.id)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (strings.isArabic) "الدروس والروابط" else "Lessons & Videos")
                        }
                        OutlinedButton(
                            onClick = { onDeleteCourse(course.id) },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete")
                        }
                    }

                    if (managingCourseLessonsId == course.id) {
                        HorizontalDivider()
                        selectedCourseLessons.forEach { lesson ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${lesson.orderIndex}. ${lesson.titleEn}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        text = "${lesson.videoStatus}${if (lesson.freePreview) " • FREE PREVIEW" else ""} • AR:${lesson.youtubeIdAr ?: "-"} / EN:${lesson.youtubeIdEn ?: "-"}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                TextButton(
                                    onClick = {
                                        onClearVideoVerify()
                                        editingLesson = lesson
                                    }
                                ) {
                                    Text(if (strings.isArabic) "تعديل/فيديو" else "Edit/Video")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Course Edit Dialog
    editingCourse?.let { target ->
        var titleAr by remember(target.id) { mutableStateOf(target.titleAr) }
        var titleEn by remember(target.id) { mutableStateOf(target.titleEn) }
        var priceText by remember(target.id) { mutableStateOf(target.priceEgp.toInt().toString()) }
        var discountText by remember(target.id) { mutableStateOf(target.discountPercent.toString()) }
        var isPaid by remember(target.id) { mutableStateOf(target.paid) }
        var isPublished by remember(target.id) { mutableStateOf(target.published) }

        AlertDialog(
            onDismissRequest = { editingCourse = null },
            title = { Text(if (target.id.isBlank()) "Create Course" else "Edit Course") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = titleAr, onValueChange = { titleAr = it }, label = { Text("Arabic Title") })
                    OutlinedTextField(value = titleEn, onValueChange = { titleEn = it }, label = { Text("English Title") })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isPaid, onCheckedChange = { isPaid = it })
                        Text("Paid Course")
                        Spacer(modifier = Modifier.width(12.dp))
                        Checkbox(checked = isPublished, onCheckedChange = { isPublished = it })
                        Text("Published")
                    }
                    if (isPaid) {
                        OutlinedTextField(
                            value = priceText,
                            onValueChange = { priceText = it },
                            label = { Text("Price (EGP)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        OutlinedTextField(
                            value = discountText,
                            onValueChange = { discountText = it },
                            label = { Text("Discount %") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveCourse(
                            target.copy(
                                titleAr = titleAr,
                                titleEn = titleEn,
                                paid = isPaid,
                                priceEgp = priceText.toDoubleOrNull() ?: target.priceEgp,
                                discountPercent = (discountText.toLongOrNull() ?: 0L).coerceIn(0, 95),
                                published = isPublished
                            )
                        )
                        editingCourse = null
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { editingCourse = null }) { Text("Cancel") }
            }
        )
    }

    // Lesson & Live YouTube Link Verifier Dialog
    editingLesson?.let { target ->
        var titleAr by remember(target.id) { mutableStateOf(target.titleAr) }
        var titleEn by remember(target.id) { mutableStateOf(target.titleEn) }
        var ytArInput by remember(target.id) { mutableStateOf(target.youtubeIdAr.orEmpty()) }
        var ytEnInput by remember(target.id) { mutableStateOf(target.youtubeIdEn.orEmpty()) }
        var freePreview by remember(target.id) { mutableStateOf(target.freePreview) }

        AlertDialog(
            onDismissRequest = { editingLesson = null },
            title = { Text("Lesson ${target.orderIndex} & Video Verifier") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = titleAr, onValueChange = { titleAr = it }, label = { Text("Arabic Title") })
                    OutlinedTextField(value = titleEn, onValueChange = { titleEn = it }, label = { Text("English Title") })
                    OutlinedTextField(value = ytArInput, onValueChange = { ytArInput = it }, label = { Text("YouTube URL/ID (AR)") })
                    OutlinedTextField(value = ytEnInput, onValueChange = { ytEnInput = it }, label = { Text("YouTube URL/ID (EN)") })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = freePreview,
                            onCheckedChange = { freePreview = it },
                            modifier = Modifier.testTag("free_preview_checkbox")
                        )
                        Text(if (strings.isArabic) "إتاحة كمعاينة مجانية (Free Preview)" else "Free Preview Lesson")
                    }
                    Button(
                        onClick = { onVerifyYoutube(ytArInput.ifBlank { ytEnInput }) },
                        enabled = !verifyingVideo && (ytArInput.isNotBlank() || ytEnInput.isNotBlank())
                    ) {
                        Text(if (verifyingVideo) "Checking oEmbed..." else "Verify YouTube Link")
                    }
                    videoVerifyResult?.let { res ->
                        Text(
                            text = if (res.valid) {
                                "Verified: ${res.title} (${res.videoId})"
                            } else {
                                "Invalid: ${res.error}"
                            },
                            color = if (res.valid) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val verifiedAr = SecurityUtils.extractYoutubeVideoId(ytArInput)
                        val verifiedEn = SecurityUtils.extractYoutubeVideoId(ytEnInput)
                        onSaveLesson(
                            target.copy(
                                titleAr = titleAr,
                                titleEn = titleEn,
                                youtubeIdAr = verifiedAr,
                                youtubeIdEn = verifiedEn,
                                freePreview = freePreview
                            )
                        )
                        editingLesson = null
                    }
                ) { Text("Save Lesson") }
            },
            dismissButton = {
                TextButton(onClick = { editingLesson = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun AdminStudentsTab(
    strings: AppStrings,
    users: List<UserProfile>,
    busy: Boolean,
    selectedAdminStudentDetail: AdminStudentDetail?,
    onToggleStudentStatus: (String, Boolean) -> Unit,
    onSetAnnualSubscription: (String, Boolean) -> Unit,
    onCorrectStudentName: (String, String, String, String, Boolean) -> Unit,
    onFetchStudentDetail: (String) -> Unit,
    onClearStudentDetail: () -> Unit,
    onToggleCertificateRevoked: (String, Boolean) -> Unit,
    onOpenSendPromoForStudent: (UserProfile) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var managingStudent by remember { mutableStateOf<UserProfile?>(null) }

    val filtered = remember(users, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) users else users.filter {
            it.fullName.lowercase().contains(q) || it.email.lowercase().contains(q)
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text(if (strings.isArabic) "بحث بالاسم أو البريد" else "Search students") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        items(filtered, key = { it.userId.ifBlank { it.id } }) { u ->
            val uid = u.userId.ifBlank { u.id }
            val suspended = u.accountStatus == "SUSPENDED"
            val hasAnnual = u.hasActiveAnnualSubscription()
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(u.fullName, fontWeight = FontWeight.Bold)
                            Text(u.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            StatusPill(
                                text = u.accountStatus,
                                containerColor = if (suspended) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.tertiary.copy(alpha = 0.22f),
                                contentColor = if (suspended) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary
                            )
                            if (hasAnnual) {
                                StatusPill(
                                    text = if (strings.isArabic) "اشتراك سنوي" else "ANNUAL PASS",
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            onClick = { onOpenSendPromoForStudent(u) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("send_promo_student_$uid")
                        ) {
                            Icon(Icons.Default.LocalOffer, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (strings.isArabic) "إرسال كود" else "Promo")
                        }
                        FilledTonalButton(
                            onClick = {
                                managingStudent = u
                                onFetchStudentDetail(uid)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("admin_student_detail_$uid")
                        ) {
                            Icon(Icons.Default.ManageAccounts, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (strings.isArabic) "إدارة الطالب" else "Manage")
                        }
                        OutlinedButton(
                            onClick = { onToggleStudentStatus(uid, !suspended) }
                        ) {
                            Text(
                                text = if (suspended) {
                                    if (strings.isArabic) "تفعيل" else "Activate"
                                } else {
                                    if (strings.isArabic) "إيقاف" else "Suspend"
                                },
                                color = if (suspended) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }

    managingStudent?.let { student ->
        val uid = student.userId.ifBlank { student.id }
        val latestUser = users.find { (it.userId.ifBlank { it.id }) == uid } ?: student
        val detail = selectedAdminStudentDetail?.takeIf { it.userId == uid }
        val split = remember(latestUser.firstName, latestUser.fatherName, latestUser.familyName, latestUser.fullName) {
            if (latestUser.firstName.isNotBlank() && latestUser.fatherName.isNotBlank() && latestUser.familyName.isNotBlank()) {
                Triple(latestUser.firstName, latestUser.fatherName, latestUser.familyName)
            } else {
                SecurityUtils.splitTripleName(latestUser.fullName)
            }
        }
        var firstName by remember(uid, split) { mutableStateOf(split.first) }
        var fatherName by remember(uid, split) { mutableStateOf(split.second) }
        var familyName by remember(uid, split) { mutableStateOf(split.third) }
        var updateCerts by remember { mutableStateOf(true) }
        val nameValid = SecurityUtils.isValidNamePart(firstName) &&
            SecurityUtils.isValidNamePart(fatherName) &&
            SecurityUtils.isValidNamePart(familyName)

        AlertDialog(
            onDismissRequest = {
                managingStudent = null
                onClearStudentDetail()
            },
            title = {
                Text(
                    text = if (strings.isArabic) "إدارة حساب: ${latestUser.fullName}" else "Manage: ${latestUser.fullName}",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 460.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(latestUser.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (strings.isArabic) "الاشتراك السنوي (جميع الكورسات)" else "Annual Subscription (All 5 Paid Courses)",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (latestUser.hasActiveAnnualSubscription()) "ANNUAL" else "NONE",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            Switch(
                                checked = latestUser.hasActiveAnnualSubscription(),
                                onCheckedChange = { checked -> onSetAnnualSubscription(uid, checked) },
                                enabled = !busy
                            )
                        }
                    }

                    HorizontalDivider()
                    Text(
                        text = if (strings.isArabic) "تعديل الاسم الثلاثي للطالب" else "Correct Student 3-Part Name",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    OutlinedTextField(
                        value = firstName,
                        onValueChange = { firstName = it },
                        label = { Text(strings.firstNameLabel) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = fatherName,
                        onValueChange = { fatherName = it },
                        label = { Text(strings.fatherNameLabel) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = familyName,
                        onValueChange = { familyName = it },
                        label = { Text(strings.familyNameLabel) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = updateCerts, onCheckedChange = { updateCerts = it })
                        Text(
                            text = if (strings.isArabic) "تحديث الاسم في الشهادات السابقة أيضًا" else "Also update existing certificates",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Button(
                        onClick = {
                            onCorrectStudentName(uid, firstName.trim(), fatherName.trim(), familyName.trim(), updateCerts)
                        },
                        enabled = !busy && nameValid,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (strings.isArabic) "حفظ الاسم الثلاثي" else "Save Corrected Name")
                    }

                    HorizontalDivider()
                    if (detail == null) {
                        Text(if (strings.isArabic) "جاري تحميل السجل..." else "Loading enrollments & certificates...")
                    } else {
                        Text(
                            text = if (strings.isArabic) {
                                "الاشتراكات: ${detail.enrollments.size} • الدروس المكتملة: ${detail.progress.count { it.completed }} • الشهادات: ${detail.certificates.size}"
                            } else {
                                "Enrollments: ${detail.enrollments.size} • Lessons Done: ${detail.progress.count { it.completed }} • Certs: ${detail.certificates.size}"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        detail.certificates.forEach { cert ->
                            Surface(
                                color = MaterialTheme.colorScheme.surface,
                                shape = MaterialTheme.shapes.small,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(cert.certificateCode, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                        Text("${cert.courseTitleEn} • ${cert.studentName}", style = MaterialTheme.typography.labelSmall)
                                    }
                                    TextButton(
                                        onClick = { onToggleCertificateRevoked(cert.certificateCode, !cert.revoked) }
                                    ) {
                                        Text(
                                            text = if (cert.revoked) {
                                                if (strings.isArabic) "استعادة" else "Restore"
                                            } else {
                                                if (strings.isArabic) "إلغاء" else "Revoke"
                                            },
                                            color = if (cert.revoked) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        managingStudent = null
                        onClearStudentDetail()
                    }
                ) {
                    Text(if (strings.isArabic) "إغلاق" else "Close")
                }
            }
        )
    }
}

@Composable
private fun AdminSettingsTab(
    strings: AppStrings,
    promos: List<PromoCode>,
    tickets: List<SupportTicket>,
    platformConfig: PlatformConfig,
    busy: Boolean,
    onSavePromo: (String, Long, String) -> Unit,
    onTogglePromoActive: (String, Boolean) -> Unit,
    onGeneratePromoBatch: (Long, Int) -> Unit,
    onOpenSendPromo: (PromoCode) -> Unit,
    onReplyTicket: (String, String) -> Unit,
    onUpdateConfig: (String, String, String, String, String, String) -> Unit
) {
    var wePayNum by remember(platformConfig.wePayNumber) { mutableStateOf(platformConfig.wePayNumber) }
    var annAr by remember(platformConfig.announcementAr) { mutableStateOf(platformConfig.announcementAr) }
    var annEn by remember(platformConfig.announcementEn) { mutableStateOf(platformConfig.announcementEn) }
    var offerAr by remember(platformConfig.activeOfferBannerAr) { mutableStateOf(platformConfig.activeOfferBannerAr) }
    var offerEn by remember(platformConfig.activeOfferBannerEn) { mutableStateOf(platformConfig.activeOfferBannerEn) }
    var verifyDomain by remember(platformConfig.verificationBaseUrl) { mutableStateOf(platformConfig.effectiveVerificationBaseUrl()) }

    var newPromoCode by remember { mutableStateOf("") }
    var newPromoPct by remember { mutableStateOf("20") }
    var newPromoDesc by remember { mutableStateOf("") }
    val ticketReplyMap = remember { mutableStateMapOf<String, String>() }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_settings_list")
    ) {
        // Admin-only Promo Codes Vault & Direct Student Distribution
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (strings.isArabic) "خزينة أكواد الخصم (للإدارة فقط)" else "Admin Promo Codes Vault",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        StatusPill(
                            text = "${promos.size}",
                            containerColor = MaterialTheme.colorScheme.secondaryContainer,
                            contentColor = MaterialTheme.colorScheme.secondary
                        )
                    }
                    Text(
                        text = if (strings.isArabic) {
                            "أكواد الخصم متاحة هنا فقط؛ اختاري أي كود وأرسليه مباشرةً لحساب الطالب الذي تحددينه."
                        } else {
                            "Promo codes are visible only to Admin. Pick any code and send it directly to a chosen student."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = newPromoCode,
                            onValueChange = { newPromoCode = it.uppercase() },
                            label = { Text(if (strings.isArabic) "الكود" else "Code") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = newPromoPct,
                            onValueChange = { newPromoPct = it },
                            label = { Text("%") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.width(86.dp)
                        )
                    }
                    OutlinedTextField(
                        value = newPromoDesc,
                        onValueChange = { newPromoDesc = it },
                        label = { Text(if (strings.isArabic) "وصف الكود (اختياري)" else "Description (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                onSavePromo(
                                    newPromoCode,
                                    newPromoPct.toLongOrNull() ?: 20L,
                                    newPromoDesc.ifBlank { "Nexora Promo" }
                                )
                                newPromoCode = ""
                                newPromoDesc = ""
                            },
                            enabled = !busy && newPromoCode.trim().length >= 2,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (strings.isArabic) "حفظ كود" else "Save Code")
                        }
                        FilledTonalButton(
                            onClick = {
                                onGeneratePromoBatch(newPromoPct.toLongOrNull() ?: 20L, 5)
                            },
                            enabled = !busy,
                            modifier = Modifier.testTag("generate_promo_batch_button")
                        ) {
                            Text(if (strings.isArabic) "+ 5 أكواد" else "+ 5 Codes")
                        }
                    }

                    HorizontalDivider()

                    promos.sortedByDescending { it.discountPercent }.forEach { pr ->
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${pr.code} • ${pr.discountPercent}%",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    if (pr.description.isNotBlank()) {
                                        Text(
                                            text = pr.description,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Switch(
                                    checked = pr.active,
                                    onCheckedChange = { onTogglePromoActive(pr.code, it) }
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                IconButton(
                                    onClick = { onOpenSendPromo(pr) },
                                    modifier = Modifier.testTag("send_promo_code_${pr.code}")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Send,
                                        contentDescription = if (strings.isArabic) "إرسال لطالب" else "Send to student",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Platform & WE Pay Config
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (strings.isArabic) "إعدادات المنصة و WE Pay" else "Platform & WE Pay Config",
                        fontWeight = FontWeight.Bold
                    )
                    OutlinedTextField(value = wePayNum, onValueChange = { wePayNum = it }, label = { Text("WE Pay Number") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = annAr, onValueChange = { annAr = it }, label = { Text("Announcement (AR)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = annEn, onValueChange = { annEn = it }, label = { Text("Announcement (EN)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = offerAr, onValueChange = { offerAr = it }, label = { Text("Offer Banner (AR)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = offerEn, onValueChange = { offerEn = it }, label = { Text("Offer Banner (EN)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(
                        value = verifyDomain,
                        onValueChange = { verifyDomain = it },
                        label = { Text(if (strings.isArabic) "رابط موقع التحقق (QR)" else "Verification Website Base URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = { onUpdateConfig(wePayNum, annAr, annEn, offerAr, offerEn, verifyDomain) },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (strings.isArabic) "حفظ الإعدادات ومزامنتها" else "Save & Sync Platform Settings")
                    }
                }
            }
        }

        items(tickets, key = { it.id }) { t ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${t.studentName}: ${t.subject}", fontWeight = FontWeight.Bold)
                    Text(t.message, style = MaterialTheme.typography.bodySmall)
                    val draftReply = ticketReplyMap[t.id] ?: t.adminReply.orEmpty()
                    OutlinedTextField(
                        value = draftReply,
                        onValueChange = { ticketReplyMap[t.id] = it },
                        label = { Text("Reply") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = { onReplyTicket(t.id, draftReply) },
                        enabled = !busy && draftReply.trim().isNotEmpty()
                    ) {
                        Text(if (strings.isArabic) "إرسال الرد" else "Send Reply")
                    }
                }
            }
        }
    }
}
