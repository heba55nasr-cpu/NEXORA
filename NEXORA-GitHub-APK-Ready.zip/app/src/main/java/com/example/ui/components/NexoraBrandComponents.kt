package com.example.ui.components

import android.annotation.SuppressLint
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.R
import com.example.core.AppStrings
import com.example.model.Course
import com.example.model.CourseSeedCourses
import com.example.model.Lesson
import com.example.ui.theme.NexoraPurpleRich
import com.example.ui.theme.nexoraBackgroundBrush
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun NexoraAtmosphericBackdrop(
    darkTheme: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(nexoraBackgroundBrush(darkTheme))
    ) {
        if (darkTheme) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                NexoraPurpleRich.copy(alpha = 0.48f),
                                Color.Transparent
                            ),
                            radius = 1100f
                        )
                    )
            )
        }
        content()
    }
}

private data class SplashParticle(
    val startX: Float,
    val startY: Float,
    val radius: Float,
    val alphaWeight: Float
)

@Composable
fun AnimatedSplashScreen(
    shortMode: Boolean = false,
    onFinished: () -> Unit
) {
    val totalDurationMs = if (shortMode) 1100L else 2600L
    val progress = remember { Animatable(0f) }
    val ringRotation by rememberInfiniteTransition(label = "rings").animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ringAngle"
    )

    LaunchedEffect(shortMode) {
        progress.snapTo(0f)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = totalDurationMs.toInt(), easing = FastOutSlowInEasing)
        )
        delay(220L)
        onFinished()
    }

    val p = progress.value
    val particlesAlpha = when {
        p < 0.2f -> p / 0.2f
        p < 0.55f -> 1f
        else -> (1f - (p - 0.55f) / 0.45f).coerceIn(0f, 1f)
    }
    val convergence = (p / 0.45f).coerceIn(0f, 1f)
    val logoAlpha = ((p - 0.18f) / 0.28f).coerceIn(0f, 1f)
    val logoScale = 0.72f + 0.28f * ((p - 0.18f) / 0.32f).coerceIn(0f, 1f)
    val ringAlpha = ((p - 0.34f) / 0.25f).coerceIn(0f, 1f)
    val shimmerX = ((p - 0.45f) / 0.30f).coerceIn(0f, 1f)
    val titleAlpha = ((p - 0.52f) / 0.24f).coerceIn(0f, 1f)
    val taglineAlpha = ((p - 0.68f) / 0.24f).coerceIn(0f, 1f)

    val particles = remember {
        List(28) { idx ->
            val angle = (idx * 137.5) * (Math.PI / 180.0)
            val dist = 0.18f + (idx % 7) * 0.055f
            SplashParticle(
                startX = (0.5 + cos(angle) * dist).toFloat(),
                startY = (0.45 + sin(angle) * dist).toFloat(),
                radius = 3.5f + (idx % 4) * 2f,
                alphaWeight = 0.45f + (idx % 5) * 0.11f
            )
        }
    }

    val bg = MaterialTheme.colorScheme.background
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val onBg = MaterialTheme.colorScheme.onBackground

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(primary.copy(alpha = 0.16f), bg),
                    radius = 950f
                )
            )
            .testTag("animated_splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        // Particle convergence + elliptical orbital rings + glass reflection canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height * 0.44f

            // Step 2 & 3: Purple light dots converging toward center to form N
            if (particlesAlpha > 0.01f) {
                particles.forEach { pt ->
                    val px = androidx.compose.ui.util.lerp(pt.startX * size.width, cx, convergence)
                    val py = androidx.compose.ui.util.lerp(pt.startY * size.height, cy, convergence)
                    drawCircle(
                        color = secondary.copy(alpha = particlesAlpha * pt.alphaWeight),
                        radius = pt.radius * (1f - 0.35f * convergence),
                        center = Offset(px, py)
                    )
                }
            }

            // Step 4: Smoothly rotating tilted elliptical orbital rings around N
            if (ringAlpha > 0.01f) {
                val ringW = 240.dp.toPx()
                val ringH = 96.dp.toPx()
                rotate(degrees = -22f + ringRotation * 0.18f, pivot = Offset(cx, cy)) {
                    drawOval(
                        color = primary.copy(alpha = 0.52f * ringAlpha),
                        topLeft = Offset(cx - ringW / 2f, cy - ringH / 2f),
                        size = Size(ringW, ringH),
                        style = Stroke(width = 2.2.dp.toPx())
                    )
                }
                rotate(degrees = 24f - ringRotation * 0.14f, pivot = Offset(cx, cy)) {
                    drawOval(
                        color = secondary.copy(alpha = 0.42f * ringAlpha),
                        topLeft = Offset(cx - ringW * 0.56f, cy - ringH * 0.44f),
                        size = Size(ringW * 1.12f, ringH * 0.88f),
                        style = Stroke(width = 1.6.dp.toPx())
                    )
                }
            }

            // Step 5: Specular glass reflection sweep
            if (shimmerX in 0.01f..0.99f) {
                val sweepStart = cx - 140.dp.toPx() + shimmerX * 280.dp.toPx()
                drawLine(
                    brush = Brush.linearGradient(
                        listOf(Color.Transparent, onBg.copy(alpha = 0.32f), Color.Transparent)
                    ),
                    start = Offset(sweepStart - 35.dp.toPx(), cy - 90.dp.toPx()),
                    end = Offset(sweepStart + 35.dp.toPx(), cy + 90.dp.toPx()),
                    strokeWidth = 22.dp.toPx()
                )
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 32.dp)
        ) {
            // Official 3D glass N logo with orbital rings
            Box(
                modifier = Modifier
                    .size(164.dp)
                    .scale(logoScale)
                    .alpha(logoAlpha)
                    .clip(CircleShape)
                    .border(1.dp, primary.copy(alpha = 0.45f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_nexora_logo_dark),
                    contentDescription = "NEXORA by HEBA NASR Official Logo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = "NEXORA",
                style = MaterialTheme.typography.displayLarge.copy(
                    letterSpacing = 6.sp,
                    fontWeight = FontWeight.Bold
                ),
                color = onBg,
                modifier = Modifier.alpha(titleAlpha)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "BY HEBA NASR",
                style = MaterialTheme.typography.titleSmall.copy(
                    letterSpacing = 3.sp,
                    fontWeight = FontWeight.SemiBold
                ),
                color = secondary,
                modifier = Modifier.alpha(titleAlpha)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Learn Today. Lead Tomorrow.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.alpha(taglineAlpha)
            )
        }
    }
}

@Composable
fun NexoraLogoBadge(
    darkTheme: Boolean,
    size: Dp = 44.dp,
    modifier: Modifier = Modifier
) {
    val logoRes = if (darkTheme) R.drawable.img_nexora_logo_dark else R.drawable.img_nexora_logo_light
    Image(
        painter = painterResource(id = logoRes),
        contentDescription = "NEXORA Logo",
        contentScale = ContentScale.Crop,
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), CircleShape)
    )
}

@Composable
fun StatusPill(
    text: String,
    containerColor: Color,
    contentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = containerColor,
        contentColor = contentColor,
        shape = RoundedCornerShape(50),
        modifier = modifier
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun CourseCard(
    course: Course,
    strings: AppStrings,
    isEnrolled: Boolean,
    isPendingPayment: Boolean,
    hasAnnualSubscription: Boolean = false,
    completedLessons: Int,
    onClick: () -> Unit,
    onLockedVideoClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val hasEffectiveAccess = !course.paid || isEnrolled || hasAnnualSubscription
    val title = if (strings.isArabic) course.titleAr else course.titleEn
    val subtitle = if (strings.isArabic) course.descriptionAr else course.descriptionEn
    val progressFraction = if (course.lessonCount > 0) {
        (completedLessons.toFloat() / course.lessonCount.toFloat()).coerceIn(0f, 1f)
    } else 0f

    ElevatedCard(
        onClick = onClick,
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("course_card_${course.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!course.paid) {
                        StatusPill(
                            text = strings.freeBadge,
                            containerColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.20f),
                            contentColor = MaterialTheme.colorScheme.tertiary
                        )
                    } else {
                        StatusPill(
                            text = strings.paidBadge,
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    if (isEnrolled || (course.paid && hasAnnualSubscription)) {
                        StatusPill(
                            text = if (!isEnrolled && hasAnnualSubscription) {
                                if (strings.isArabic) "اشتراك سنوي" else "ANNUAL"
                            } else strings.enrolledBadge,
                            containerColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.25f),
                            contentColor = MaterialTheme.colorScheme.tertiary
                        )
                    } else if (isPendingPayment) {
                        StatusPill(
                            text = strings.pendingBadge,
                            containerColor = MaterialTheme.colorScheme.secondaryContainer,
                            contentColor = MaterialTheme.colorScheme.secondary
                        )
                    }
                }

                if (course.paid) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (course.discountPercent > 0) {
                            Text(
                                text = "${course.priceEgp.toInt()}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    textDecoration = TextDecoration.LineThrough
                                ),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "${course.effectivePriceEgp.toInt()} ${strings.egpCurrency}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(48.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = courseIconFor(course.thumbnailKey),
                            contentDescription = title,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${course.lessonCount} ${strings.lessonsCountLabel} • ${course.category}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            val seedLessons = remember(course.id) { CourseSeedCourses.buildLessonsForCourse(course.id) }
            val previewThumbUrl = remember(course.id, strings.isArabic, seedLessons) {
                val lang = if (strings.isArabic) "ar" else "en"
                seedLessons.firstOrNull()?.previewThumbnailUrl(lang)
            }
            val estimatedDuration = remember(course.id, strings.isArabic, seedLessons) {
                if (seedLessons.isNotEmpty()) {
                    Lesson.estimateTotalDurationLabel(seedLessons, strings.isArabic)
                } else {
                    if (strings.isArabic) "${course.lessonCount * 15} د" else "${course.lessonCount * 15}m"
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Outside Video Preview Card (thumbnail, video count, duration, and lock badge for unpaid paid courses)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(132.dp)
                    .clip(MaterialTheme.shapes.medium)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                MaterialTheme.colorScheme.primaryContainer,
                                MaterialTheme.colorScheme.surface
                            )
                        )
                    )
                    .clickable {
                        if (course.paid && !hasEffectiveAccess && onLockedVideoClick != null) {
                            onLockedVideoClick()
                        } else {
                            onClick()
                        }
                    }
                    .testTag("course_card_preview_${course.id}")
            ) {
                if (!previewThumbUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = previewThumbUrl,
                        contentDescription = title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color.Black.copy(alpha = 0.18f),
                                    Color.Black.copy(alpha = 0.72f)
                                )
                            )
                        )
                )
                Icon(
                    imageVector = if (course.paid && !hasEffectiveAccess) Icons.Default.Lock else Icons.Default.PlayCircleFilled,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.92f),
                    modifier = Modifier
                        .size(40.dp)
                        .align(Alignment.Center)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomStart)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.68f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (strings.isArabic) {
                                "${course.lessonCount} فيديو • $estimatedDuration"
                            } else {
                                "${course.lessonCount} videos • $estimatedDuration"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    if (course.paid && !hasEffectiveAccess) {
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.9f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (strings.isArabic) "ادفع للمشاهدة" else "Pay to Watch",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            if (hasEffectiveAccess || completedLessons > 0) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = strings.progressLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${(progressFraction * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { progressFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                )
            }
        }
    }
}

fun courseIconFor(key: String) = when (key) {
    "programming" -> Icons.Default.Code
    "digital_art" -> Icons.Default.Palette
    "video_editing" -> Icons.Default.Movie
    "voice_over" -> Icons.Default.Mic
    "cybersecurity" -> Icons.Default.Security
    "english", "chinese", "korean" -> Icons.Default.Translate
    else -> Icons.Default.School
}

private enum class InAppPlayerMode {
    EMBED,
    WEB_IN_APP
}

private class NexoraPlayerJsBridge(
    private val onErrorCallback: (Int) -> Unit
) {
    @JavascriptInterface
    fun onEmbedError(code: Int) {
        onErrorCallback(code)
    }
}

private fun buildInAppEmbedHtml(videoId: String): String = """
    <!DOCTYPE html>
    <html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <meta name="referrer" content="strict-origin-when-cross-origin">
      <style>
        * { box-sizing: border-box; }
        body, html { margin: 0; padding: 0; background: #040208; height: 100%; width: 100%; overflow: hidden; }
        #player { position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: 0; }
      </style>
    </head>
    <body>
      <div id="player"></div>
      <script>
        var tag = document.createElement('script');
        tag.src = 'https://www.youtube.com/iframe_api';
        var firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

        var player;
        function onYouTubeIframeAPIReady() {
          player = new YT.Player('player', {
            videoId: '$videoId',
            host: 'https://www.youtube.com',
            playerVars: {
              playsinline: 1,
              rel: 0,
              modestbranding: 1,
              fs: 1,
              iv_load_policy: 3,
              enablejsapi: 1,
              origin: 'https://nexora-academy.web.app'
            },
            events: {
              onReady: function(e) {
                try {
                  var frame = e.target.getIframe();
                  if (frame) {
                    frame.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen');
                    frame.setAttribute('allowfullscreen', '');
                    frame.setAttribute('referrerpolicy', 'strict-origin-when-cross-origin');
                  }
                } catch (err) {}
              },
              onError: function(e) {
                if (window.NexoraBridge && window.NexoraBridge.onEmbedError) {
                  window.NexoraBridge.onEmbedError(e.data || 150);
                }
              }
            }
          });
        }
        setTimeout(function() {
          if (typeof YT === 'undefined' || !YT.Player) {
            if (window.NexoraBridge && window.NexoraBridge.onEmbedError) {
              window.NexoraBridge.onEmbedError(153);
            }
          }
        }, 6500);
      </script>
    </body>
    </html>
""".trimIndent()

private fun isAllowedInAppVideoHost(host: String): Boolean {
    val clean = host.lowercase()
    return clean == "youtube.com" ||
        clean.endsWith(".youtube.com") ||
        clean == "youtube-nocookie.com" ||
        clean.endsWith(".youtube-nocookie.com") ||
        clean == "youtu.be" ||
        clean == "googlevideo.com" ||
        clean.endsWith(".googlevideo.com") ||
        clean == "nexora-academy.web.app"
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeEmbedPlayer(
    videoId: String?,
    lessonTitle: String,
    strings: AppStrings,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        if (videoId.isNullOrBlank()) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .testTag("lesson_needs_content_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.VideoLibrary,
                        contentDescription = strings.needsContentBadge,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = strings.needsContentBadge,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (strings.isArabic) {
                            "هذا الدرس مُهيّأ في المنهج وسيتم إرفاق رابط فيديو موثّق عبر لوحة الأدمن."
                        } else {
                            "This lesson outline is ready and awaiting a verified video link from Admin."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            var playerMode by remember(videoId) { mutableStateOf(InAppPlayerMode.EMBED) }
            var reloadNonce by remember(videoId) { mutableIntStateOf(0) }
            var fullscreenView by remember { mutableStateOf<View?>(null) }
            var fullscreenCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

            val html = remember(videoId) { buildInAppEmbedHtml(videoId) }
            val loadKey = "${videoId}_${playerMode.name}_$reloadNonce"

            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        runCatching {
                            CookieManager.getInstance().setAcceptCookie(true)
                            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        }
                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            loadsImagesAutomatically = true
                            mediaPlaybackRequiresUserGesture = false
                            javaScriptCanOpenWindowsAutomatically = false
                            setSupportMultipleWindows(false)
                            useWideViewPort = true
                            loadWithOverviewMode = true
                            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            cacheMode = WebSettings.LOAD_DEFAULT
                            userAgentString = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
                        }
                        addJavascriptInterface(
                            NexoraPlayerJsBridge {
                                post {
                                    if (playerMode == InAppPlayerMode.EMBED) {
                                        playerMode = InAppPlayerMode.WEB_IN_APP
                                    }
                                }
                            },
                            "NexoraBridge"
                        )
                        webChromeClient = object : WebChromeClient() {
                            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                                fullscreenView = view
                                fullscreenCallback = callback
                            }

                            override fun onHideCustomView() {
                                fullscreenCallback?.onCustomViewHidden()
                                fullscreenCallback = null
                                fullscreenView = null
                            }

                            override fun onCreateWindow(
                                view: WebView?,
                                isDialog: Boolean,
                                isUserGesture: Boolean,
                                resultMsg: android.os.Message?
                            ): Boolean = false
                        }
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): Boolean {
                                val uri = request?.url ?: return true
                                val scheme = uri.scheme.orEmpty().lowercase()
                                val host = uri.host.orEmpty()
                                // Never bounce out to external YouTube app, browser, Play Store, or intent:// handlers
                                if (scheme != "http" && scheme != "https") {
                                    return true
                                }
                                if (host.isNotEmpty() && !isAllowedInAppVideoHost(host)) {
                                    return true
                                }
                                return false
                            }

                            override fun onReceivedError(
                                view: WebView?,
                                request: WebResourceRequest?,
                                error: WebResourceError?
                            ) {
                                if (request?.isForMainFrame == true && playerMode == InAppPlayerMode.EMBED) {
                                    post { playerMode = InAppPlayerMode.WEB_IN_APP }
                                }
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                if (url.orEmpty().contains("m.youtube.com")) {
                                    // Hide external app install banners so playback stays inside NEXORA
                                    view?.evaluateJavascript(
                                        """
                                        (function() {
                                          var style = document.createElement('style');
                                          style.innerHTML = 'ytm-app-banner-renderer, .open-app-button, ytm-upsell-dialog-renderer { display: none !important; }';
                                          document.head && document.head.appendChild(style);
                                        })();
                                        """.trimIndent(),
                                        null
                                    )
                                }
                            }
                        }
                        tag = loadKey
                        loadDataWithBaseURL(
                            "https://nexora-academy.web.app",
                            html,
                            "text/html",
                            "utf-8",
                            "https://nexora-academy.web.app/"
                        )
                    }
                },
                update = { webView ->
                    if (webView.tag != loadKey) {
                        webView.tag = loadKey
                        if (playerMode == InAppPlayerMode.EMBED) {
                            webView.loadDataWithBaseURL(
                                "https://nexora-academy.web.app",
                                html,
                                "text/html",
                                "utf-8",
                                "https://nexora-academy.web.app/"
                            )
                        } else {
                            webView.loadUrl("https://m.youtube.com/watch?v=$videoId")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(MaterialTheme.shapes.large)
                    .testTag("youtube_embed_webview")
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusPill(
                    text = strings.inAppPlayerBadge,
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f),
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(
                        onClick = {
                            playerMode = if (playerMode == InAppPlayerMode.EMBED) {
                                InAppPlayerMode.WEB_IN_APP
                            } else {
                                InAppPlayerMode.EMBED
                            }
                        },
                        modifier = Modifier.testTag("switch_in_app_player_mode_button")
                    ) {
                        Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(strings.switchInAppMode, style = MaterialTheme.typography.labelSmall)
                    }
                    IconButton(
                        onClick = { reloadNonce++ },
                        modifier = Modifier.testTag("reload_in_app_player_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = strings.reloadInAppPlayer, modifier = Modifier.size(18.dp))
                    }
                }
            }

            val fsView = fullscreenView
            if (fsView != null) {
                Dialog(
                    onDismissRequest = {
                        fullscreenCallback?.onCustomViewHidden()
                        fullscreenCallback = null
                        fullscreenView = null
                    },
                    properties = DialogProperties(
                        usePlatformDefaultWidth = false,
                        decorFitsSystemWindows = false
                    )
                ) {
                    androidx.activity.compose.BackHandler {
                        fullscreenCallback?.onCustomViewHidden()
                        fullscreenCallback = null
                        fullscreenView = null
                    }
                    AndroidView(
                        factory = { ctx ->
                            FrameLayout(ctx).apply {
                                (fsView.parent as? ViewGroup)?.removeView(fsView)
                                addView(
                                    fsView,
                                    ViewGroup.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.MATCH_PARENT
                                    )
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black)
                    )
                }
            }
        }
    }
}

@Composable
fun QrCodeMatrixCanvas(
    matrix: Array<BooleanArray>,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
        ) {
            val n = matrix.size.coerceAtLeast(1)
            val cell = minOf(size.width, size.height) / n.toFloat()
            val dark = Color.Black
            for (r in matrix.indices) {
                for (c in matrix[r].indices) {
                    if (matrix[r][c]) {
                        drawRect(
                            color = dark,
                            topLeft = Offset(c * cell, r * cell),
                            size = Size(cell + 0.5f, cell + 0.5f)
                        )
                    }
                }
            }
        }
    }
}
