package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val firstName: String = "",
    val fatherName: String = "",
    val familyName: String = "",
    val fullName: String = "",
    val email: String = "",
    val photoUrl: String? = null,
    val preferredLang: String = "ar",
    val accountStatus: String = "ACTIVE",
    val role: String = "STUDENT",
    val subscriptionPlan: String = "NONE", // NONE | ANNUAL
    val subscriptionExpiresAt: Timestamp? = null,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun hasActiveAnnualSubscription(nowSeconds: Long = System.currentTimeMillis() / 1000L): Boolean {
        if (subscriptionPlan != "ANNUAL") return false
        val exp = subscriptionExpiresAt ?: return true
        return exp.seconds >= nowSeconds
    }

    fun toCreateMap(): Map<String, Any> = mapOf(
        "userId" to userId,
        "firstName" to firstName.takeIf { it.isNotBlank() },
        "fatherName" to fatherName.takeIf { it.isNotBlank() },
        "familyName" to familyName.takeIf { it.isNotBlank() },
        "fullName" to fullName,
        "email" to email,
        "photoUrl" to photoUrl,
        "preferredLang" to preferredLang,
        "accountStatus" to accountStatus,
        "role" to role,
        "subscriptionPlan" to subscriptionPlan,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    ).filterValues { it != null } as Map<String, Any>
}

@Keep
@IgnoreExtraProperties
data class Course(
    @DocumentId val id: String = "",
    val titleAr: String = "",
    val titleEn: String = "",
    val descriptionAr: String = "",
    val descriptionEn: String = "",
    val category: String = "",
    val paid: Boolean = true,
    val priceEgp: Double = 0.0,
    val discountPercent: Long = 0L,
    val thumbnailKey: String = "programming",
    val defaultLang: String = "ar",
    val supportsBilingual: Boolean = false,
    val passingScore: Long = 75L,
    val published: Boolean = true,
    val lessonCount: Long = 20L,
    val sortOrder: Long = 1L,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    val effectivePriceEgp: Double
        get() = if (!paid) 0.0 else (priceEgp * (100.0 - discountPercent.coerceIn(0, 100)) / 100.0)

    fun toCreateMap(): Map<String, Any> = mapOf(
        "titleAr" to titleAr,
        "titleEn" to titleEn,
        "descriptionAr" to descriptionAr,
        "descriptionEn" to descriptionEn,
        "category" to category,
        "paid" to paid,
        "priceEgp" to priceEgp,
        "discountPercent" to discountPercent,
        "thumbnailKey" to thumbnailKey,
        "defaultLang" to defaultLang,
        "supportsBilingual" to supportsBilingual,
        "passingScore" to passingScore,
        "published" to published,
        "lessonCount" to lessonCount,
        "sortOrder" to sortOrder,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class Lesson(
    @DocumentId val id: String = "",
    val courseId: String = "",
    val orderIndex: Long = 1L,
    val moduleTitleAr: String = "",
    val moduleTitleEn: String = "",
    val titleAr: String = "",
    val titleEn: String = "",
    val descriptionAr: String = "",
    val descriptionEn: String = "",
    val objectivesAr: String = "",
    val objectivesEn: String = "",
    val durationLabel: String = "",
    val youtubeIdAr: String? = null,
    val youtubeIdEn: String? = null,
    val defaultLang: String = "ar",
    val freePreview: Boolean = false,
    val videoStatus: String = "NEEDS_CONTENT", // READY | NEEDS_CONTENT | INVALID
    val published: Boolean = true,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun resolveYoutubeId(selectedLang: String): String? {
        return when (selectedLang) {
            "en" -> youtubeIdEn?.takeIf { it.isNotBlank() } ?: youtubeIdAr?.takeIf { it.isNotBlank() }
            else -> youtubeIdAr?.takeIf { it.isNotBlank() } ?: youtubeIdEn?.takeIf { it.isNotBlank() }
        }
    }

    fun previewThumbnailUrl(preferredLang: String = defaultLang): String? {
        val id = resolveYoutubeId(preferredLang) ?: return null
        return "https://img.youtube.com/vi/$id/hqdefault.jpg"
    }

    fun toCreateMap(): Map<String, Any> = mapOf(
        "courseId" to courseId,
        "orderIndex" to orderIndex,
        "moduleTitleAr" to moduleTitleAr,
        "moduleTitleEn" to moduleTitleEn,
        "titleAr" to titleAr,
        "titleEn" to titleEn,
        "descriptionAr" to descriptionAr,
        "descriptionEn" to descriptionEn,
        "objectivesAr" to objectivesAr,
        "objectivesEn" to objectivesEn,
        "durationLabel" to durationLabel,
        "youtubeIdAr" to youtubeIdAr?.takeIf { it.isNotBlank() },
        "youtubeIdEn" to youtubeIdEn?.takeIf { it.isNotBlank() },
        "defaultLang" to defaultLang,
        "freePreview" to freePreview,
        "videoStatus" to videoStatus,
        "published" to published,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    ).filterValues { it != null } as Map<String, Any>

    fun toVideoPayloadMap(): Map<String, Any> = mapOf(
        "courseId" to courseId,
        "lessonId" to id,
        "youtubeIdAr" to youtubeIdAr?.takeIf { it.isNotBlank() },
        "youtubeIdEn" to youtubeIdEn?.takeIf { it.isNotBlank() },
        "freePreview" to freePreview,
        "videoStatus" to videoStatus,
        "published" to published,
        "updatedAt" to FieldValue.serverTimestamp()
    ).filterValues { it != null } as Map<String, Any>

    companion object {
        fun estimateTotalDurationLabel(lessons: List<Lesson>, isArabic: Boolean): String {
            val totalMinutes = lessons.sumOf { lesson ->
                val digits = Regex("(\\d+)").find(lesson.durationLabel)?.groupValues?.getOrNull(1)?.toIntOrNull()
                digits ?: 15
            }.coerceAtLeast(lessons.size * 12)
            val hours = totalMinutes / 60
            val mins = totalMinutes % 60
            return if (isArabic) {
                when {
                    hours > 0 && mins > 0 -> "$hours س $mins د"
                    hours > 0 -> "$hours ساعات"
                    else -> "$mins دقيقة"
                }
            } else {
                when {
                    hours > 0 && mins > 0 -> "${hours}h ${mins}m"
                    hours > 0 -> "${hours}h"
                    else -> "${mins}m"
                }
            }
        }
    }
}

@Keep
@IgnoreExtraProperties
data class ExamQuestion(
    @DocumentId val id: String = "",
    val courseId: String = "",
    val orderIndex: Long = 1L,
    val questionAr: String = "",
    val questionEn: String = "",
    val optionsAr: List<String> = emptyList(),
    val optionsEn: List<String> = emptyList(),
    val answerHash: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "courseId" to courseId,
        "orderIndex" to orderIndex,
        "questionAr" to questionAr,
        "questionEn" to questionEn,
        "optionsAr" to optionsAr,
        "optionsEn" to optionsEn,
        "answerHash" to answerHash,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class LessonVideoPayload(
    @DocumentId val id: String = "",
    val courseId: String = "",
    val lessonId: String = "",
    val youtubeIdAr: String? = null,
    val youtubeIdEn: String? = null,
    val freePreview: Boolean = false,
    val videoStatus: String = "READY",
    val published: Boolean = true,
    val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PaymentRequest(
    @DocumentId val id: String = "",
    val userId: String = "",
    val studentName: String = "",
    val studentEmail: String = "",
    val courseId: String = "",
    val courseTitle: String = "",
    val amountEgp: Double = 0.0,
    val originalPriceEgp: Double = 0.0,
    val promoCode: String? = null,
    val targetLessonId: String? = null,
    val paymentMethod: String = "WE Pay",
    val transferNumber: String = "01557701433",
    val senderPhone: String = "",
    val transactionRef: String = "",
    val proofImageBase64: String? = null,
    val status: String = "PENDING", // PENDING | APPROVED | REJECTED
    val adminNote: String? = null,
    val reviewedBy: String? = null,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun displayStatus(isArabic: Boolean): String = when (status) {
        "APPROVED" -> if (isArabic) "تم التحقق (Verified)" else "Verified"
        "REJECTED" -> if (isArabic) "مرفوض (Rejected)" else "Rejected"
        else -> if (isArabic) "قيد المراجعة (Pending)" else "Pending"
    }

    fun toCreateMap(): Map<String, Any> = mapOf(
        "userId" to userId,
        "studentName" to studentName,
        "studentEmail" to studentEmail,
        "courseId" to courseId,
        "courseTitle" to courseTitle,
        "amountEgp" to amountEgp,
        "originalPriceEgp" to originalPriceEgp,
        "promoCode" to promoCode?.takeIf { it.isNotBlank() },
        "targetLessonId" to targetLessonId?.takeIf { it.isNotBlank() },
        "paymentMethod" to paymentMethod,
        "transferNumber" to transferNumber,
        "senderPhone" to senderPhone,
        "transactionRef" to transactionRef,
        "proofImageBase64" to proofImageBase64?.takeIf { it.isNotBlank() },
        "status" to status,
        "adminNote" to adminNote?.takeIf { it.isNotBlank() },
        "reviewedBy" to reviewedBy?.takeIf { it.isNotBlank() },
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    ).filterValues { it != null } as Map<String, Any>
}

@Keep
@IgnoreExtraProperties
data class Enrollment(
    @DocumentId val id: String = "",
    val userId: String = "",
    val courseId: String = "",
    val accessType: String = "FREE",
    val paymentId: String? = null,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class LessonProgress(
    @DocumentId val id: String = "",
    val userId: String = "",
    val courseId: String = "",
    val lessonId: String = "",
    val completed: Boolean = false,
    val watchedSeconds: Long = 0L,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ExamAttempt(
    @DocumentId val id: String = "",
    val userId: String = "",
    val courseId: String = "",
    val courseTitle: String = "",
    val scorePercent: Long = 0L,
    val correctCount: Long = 0L,
    val totalQuestions: Long = 0L,
    val passed: Boolean = false,
    val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Certificate(
    @DocumentId val id: String = "",
    val userId: String = "",
    val courseId: String = "",
    val studentName: String = "",
    val courseTitleAr: String = "",
    val courseTitleEn: String = "",
    val certificateCode: String = "",
    val scorePercent: Long = 75L,
    val issuedDateLabel: String = "",
    val issuerName: String = "NEXORA by HEBA NASR",
    val revoked: Boolean = false,
    val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class StudentNotification(
    @DocumentId val id: String = "",
    val userId: String = "",
    val titleAr: String = "",
    val titleEn: String = "",
    val bodyAr: String = "",
    val bodyEn: String = "",
    val type: String = "PLATFORM_UPDATE",
    val read: Boolean = false,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PromoCode(
    @DocumentId val id: String = "",
    val code: String = "",
    val discountPercent: Long = 10L,
    val active: Boolean = true,
    val description: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class SupportTicket(
    @DocumentId val id: String = "",
    val userId: String = "",
    val studentName: String = "",
    val studentEmail: String = "",
    val subject: String = "",
    val message: String = "",
    val status: String = "OPEN",
    val adminReply: String? = null,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PlatformConfig(
    @DocumentId val id: String = "main",
    val wePayNumber: String = "01557701433",
    val announcementAr: String = "أهلًا بكم في منصة NEXORA by HEBA NASR — تعلم اليوم لتقود الغد.",
    val announcementEn: String = "Welcome to NEXORA by HEBA NASR — Learn Today. Lead Tomorrow.",
    val activeOfferBannerAr: String = "خصومات خاصة على مسارات البرمجة والأمن السيبراني",
    val activeOfferBannerEn: String = "Special offers on Programming & Cybersecurity tracks",
    val supportEmail: String = "heba55nasr@gmail.com",
    val accentPreset: String = "MAUVE_MATTE",
    val verificationBaseUrl: String = DEFAULT_VERIFICATION_BASE_URL,
    val updatedAt: Timestamp? = null
) {
    fun effectiveVerificationBaseUrl(): String {
        val clean = verificationBaseUrl.trim().trimEnd('/')
        return if (clean.startsWith("http://") || clean.startsWith("https://")) {
            clean
        } else {
            DEFAULT_VERIFICATION_BASE_URL
        }
    }

    fun buildCertificateVerifyUrl(certificateCode: String): String {
        val code = certificateCode.trim()
        return "${effectiveVerificationBaseUrl()}/verify/$code"
    }

    fun verificationHostLabel(): String {
        return effectiveVerificationBaseUrl()
            .removePrefix("https://")
            .removePrefix("http://")
            .substringBefore('/')
    }

    companion object {
        const val DEFAULT_VERIFICATION_BASE_URL = "https://gen-lang-client-0707606931.web.app"
    }
}
