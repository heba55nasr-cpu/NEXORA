package com.example.model

import com.example.core.SecurityUtils

data class SeedQuestionSpec(
    val order: Int,
    val questionAr: String,
    val questionEn: String,
    val optionsAr: List<String>,
    val optionsEn: List<String>,
    val correctIndex: Int
)

object CourseSeedExams {

    fun buildQuestionsForCourse(courseId: String): Pair<List<ExamQuestion>, List<Pair<String, Int>>> {
        val specs = when (courseId) {
            "programming" -> programmingQuestions
            "digital_art" -> digitalArtQuestions
            "video_editing" -> videoEditingQuestions
            "voice_over" -> voiceOverQuestions
            "cybersecurity" -> cybersecurityQuestions
            "english" -> englishQuestions
            "chinese" -> chineseQuestions
            "korean" -> koreanQuestions
            else -> emptyList()
        }
        val questions = ArrayList<ExamQuestion>(specs.size)
        val keys = ArrayList<Pair<String, Int>>(specs.size)
        for (spec in specs) {
            val qId = "${courseId}_q${spec.order.toString().padStart(2, '0')}"
            questions.add(
                ExamQuestion(
                    id = qId,
                    courseId = courseId,
                    orderIndex = spec.order.toLong(),
                    questionAr = spec.questionAr,
                    questionEn = spec.questionEn,
                    optionsAr = spec.optionsAr,
                    optionsEn = spec.optionsEn,
                    answerHash = SecurityUtils.hashExamAnswer(courseId, qId, spec.correctIndex)
                )
            )
            keys.add(qId to spec.correctIndex)
        }
        return questions to keys
    }

    private fun q(
        order: Int,
        qAr: String,
        qEn: String,
        oAr: List<String>,
        oEn: List<String>,
        correct: Int
    ) = SeedQuestionSpec(order, qAr, qEn, oAr, oEn, correct)

    private val programmingQuestions = listOf(
        q(1, "ما وظيفة المتغير (Variable) في البرمجة؟", "What is the primary purpose of a variable in programming?",
            listOf("تخزين قيمة في الذاكرة للرجوع إليها", "تغيير لون الشاشة فقط", "حذف الملفات تلقائيًا", "إيقاف تشغيل المعالج"),
            listOf("Store a value in memory for later use", "Only change screen colors", "Delete files automatically", "Shut down the CPU"), 0),
        q(2, "أي نوع بيانات يُستخدم لتمثيل قيمة منطقية (صح أو خطأ)؟", "Which data type represents true or false logic?",
            listOf("String", "Boolean", "Float", "List"),
            listOf("String", "Boolean", "Float", "List"), 1),
        q(3, "ما البنية المستخدمة لتكرار تنفيذ كود عددًا محددًا من المرات؟", "Which structure repeats a block of code over a sequence?",
            listOf("if / else", "for loop", "import", "return"),
            listOf("if / else", "for loop", "import", "return"), 1),
        q(4, "في بايثون، أي كلمة مفتاحية تُستخدم لتعريف دالة (Function)؟", "In Python, which keyword defines a function?",
            listOf("func", "def", "class", "lambda"),
            listOf("func", "def", "class", "lambda"), 1),
        q(5, "ما الفائدة الأساسية من استخدام الدوال (Functions)؟", "What is the main benefit of using functions?",
            listOf("إعادة استخدام الكود وتنظيمه", "زيادة حجم الملف عمدًا", "منع استخدام المتغيرات", "إلغاء الحاجة للبيانات"),
            listOf("Code reuse and modularity", "Artificially enlarging files", "Blocking variable usage", "Removing data types"), 0),
        q(6, "أي هيكل بيانات يخزن العناصر بصيغة مفتاح وقيمة (Key-Value)؟", "Which structure stores data as key-value pairs?",
            listOf("Dictionary / Map", "Integer", "Boolean", "Tuple"),
            listOf("Dictionary / Map", "Integer", "Boolean", "Tuple"), 0),
        q(7, "ما الهدف من جملة try / except في البرمجة؟", "Why do we use try / except blocks?",
            listOf("معالجة الأخطاء دون انهيار البرنامج", "تسريع كرت الشاشة", "إنشاء قواعد البيانات", "تشفير الصور"),
            listOf("Handle runtime errors gracefully", "Overclock the GPU", "Create databases", "Encrypt images"), 0),
        q(8, "في البرمجة كائنية التوجه (OOP)، ما المقصود بالـ Class؟", "In OOP, what is a Class?",
            listOf("قالب أو مخطط لإنشاء الكائنات", "خطأ برمجي", "نوع من حلقات التكرار", "ملف صوتي"),
            listOf("A blueprint for creating objects", "A syntax error", "A type of loop", "An audio file"), 0),
        q(9, "أي أداة تُستخدم لإدارة نسخ الكود والتعاون البرمجي؟", "Which tool is standard for version control?",
            listOf("Git", "Photoshop", "Audacity", "Premiere"),
            listOf("Git", "Photoshop", "Audacity", "Premiere"), 0),
        q(10, "ما الصيغة الأكثر شيوعًا لتبادل البيانات مع واجهات APIs؟", "Which format is most commonly used for REST API payloads?",
            listOf("JSON", "MP3", "BMP", "WAV"),
            listOf("JSON", "MP3", "BMP", "WAV"), 0)
    )

    private val digitalArtQuestions = listOf(
        q(1, "ما الفائدة الرئيسية من استخدام الطبقات (Layers)؟", "What is the primary advantage of using Layers?",
            listOf("تعديل كل عنصر بشكل مستقل دون إتلاف التصميم", "تقليل دقة الصورة", "دمج الألوان في لون واحد", "إلغاء الإضاءة"),
            listOf("Edit elements independently without ruining others", "Lower resolution", "Merge colors into one", "Disable lighting"), 0),
        q(2, "أي صيغة تحفظ التصميم مع شفافية خلفية (Transparency)؟", "Which format supports transparent backgrounds?",
            listOf("JPG", "PNG", "TXT", "MP4"),
            listOf("JPG", "PNG", "TXT", "MP4"), 1),
        q(3, "ما الفرق الجوهري بين رسوم Vector و Raster؟", "What distinguishes Vector graphics from Raster graphics?",
            listOf("Vector يعتمد على معادلات رياضية ولا يفقد الجودة بالتكبير", "Raster لا يحتوي على ألوان", "Vector للمقاطع الصوتية فقط", "لا يوجد فرق"),
            listOf("Vector uses math paths and scales infinitely", "Raster has no colors", "Vector is audio only", "No difference"), 0),
        q(4, "ما الأداة الأساسية لرسم المنحنيات الدقيقة في Illustrator؟", "Which tool draws precision Bezier curves in Illustrator?",
            listOf("Pen Tool", "Eraser", "Blur Tool", "Crop Tool"),
            listOf("Pen Tool", "Eraser", "Blur Tool", "Crop Tool"), 0),
        q(5, "ما المقصود بالتعديل غير المدمر (Non-Destructive Editing)؟", "What does Non-Destructive Editing mean?",
            listOf("إمكانية التراجع وتعديل التأثيرات في أي وقت عبر Masks", "حذف الصورة الأصلية", "العمل على طبقة واحدة فقط", "تصدير الملف بدون حفظ"),
            listOf("Keeping original pixels intact using masks and adjustments", "Deleting source files", "Working on one flat layer", "Exporting without saving"), 0),
        q(6, "أي نظام ألوان يُستخدم عادةً للطباعة الورقية؟", "Which color mode is standard for physical printing?",
            listOf("RGB", "CMYK", "HSB", "HEX"),
            listOf("RGB", "CMYK", "HSB", "HEX"), 1),
        q(7, "أي نظام ألوان يُستخدم للشاشات والمنصات الرقمية؟", "Which color mode is used for digital screens?",
            listOf("CMYK", "RGB", "Pantone Spot", "Grayscale"),
            listOf("CMYK", "RGB", "Pantone Spot", "Grayscale"), 1),
        q(8, "ما دور التباين (Contrast) في التصميم؟", "What role does Contrast play in visual design?",
            listOf("توجيه عين المشاهد وإبراز العناصر المهمة", "إخفاء النصوص", "زيادة حجم الملف فقط", "تعطيل الألوان"),
            listOf("Guides viewer attention and creates hierarchy", "Hides text", "Only increases file size", "Disables colors"), 0),
        q(9, "ما المقصود بدقة 300 DPI؟", "What is 300 DPI commonly recommended for?",
            listOf("الطباعة عالية الجودة", "ملفات الصوت", "الفيديوهات فقط", "أيقونات 16 بكسل"),
            listOf("High-quality print output", "Audio files", "Video only", "16px icons"), 0),
        q(10, "ما الغرض من قناع الطبقة (Layer Mask)؟", "What is a Layer Mask used for?",
            listOf("إخفاء وإظهار أجزاء من الطبقة باللونين الأبيض والأسود", "إضافة نصوص تلقائيًا", "تغيير اسم الملف", "ضغط الفيديو"),
            listOf("Hide or reveal parts of a layer non-destructively", "Auto-add text", "Rename files", "Compress video"), 0)
    )

    private val videoEditingQuestions = listOf(
        q(1, "ما اسم المساحة التي يتم فيها ترتيب مقاطع الفيديو والصوت زمنيًا؟", "Where are video and audio clips arranged chronologically?",
            listOf("Timeline", "Color Wheel", "Brush Panel", "Font Manager"),
            listOf("Timeline", "Color Wheel", "Brush Panel", "Font Manager"), 0),
        q(2, "ما المقصود بـ Keyframe في المونتاج؟", "What is a Keyframe in video editing?",
            listOf("نقطة زمنية لتحديد تغيّر قيمة مثل الحركة أو الحجم", "نوع كاميرا", "صيغة صوت", "كابل شاشة"),
            listOf("A timestamp marker defining parameter changes over time", "A camera type", "An audio codec", "A monitor cable"), 0),
        q(3, "ما الفرق بين Color Correction و Color Grading؟", "How does Color Correction differ from Color Grading?",
            listOf("Correction يصحح الإضاءة واللون الطبيعي وGrading يضيف الطابع السينمائي", "كلاهما يحذف الصوت", "Grading للتصوير فقط", "لا فرق بينهما"),
            listOf("Correction balances natural exposure/white balance; Grading adds creative mood", "Both mute audio", "Grading is camera-only", "No difference"), 0),
        q(4, "ما الغرض من استخدام ملفات Proxy أثناء المونتاج؟", "Why use Proxy files during editing?",
            listOf("تسريع العرض السلس للقطات عالية الدقة 4K", "حذف الصوت", "تغيير نسبة العرض", "إضافة ترجمة"),
            listOf("Enable smooth playback of heavy 4K footage", "Remove audio", "Change aspect ratio", "Add subtitles"), 0),
        q(5, "أي تقنية تُستخدم لعزل الخلفية الخضراء؟", "Which technique removes a green screen background?",
            listOf("Chroma Key", "Speed Ramp", "Audio Ducking", "Gain Staging"),
            listOf("Chroma Key", "Speed Ramp", "Audio Ducking", "Gain Staging"), 0),
        q(6, "ما النسبة القياسية لفيديوهات Reels و Shorts العمودية؟", "What is the standard aspect ratio for vertical Reels & Shorts?",
            listOf("9:16", "16:9", "4:3", "21:9"),
            listOf("9:16", "16:9", "4:3", "21:9"), 0),
        q(7, "أي صيغة ترميز هي الأكثر انتشارًا لتصدير الفيديو للويب؟", "Which video codec is standard for web/YouTube export?",
            listOf("H.264 (MP4)", "WAV", "PNG", "SVG"),
            listOf("H.264 (MP4)", "WAV", "PNG", "SVG"), 0),
        q(8, "ما المقصود بمفهوم J-Cut في المونتاج؟", "What is a J-Cut?",
            listOf("بدء صوت اللقطة التالية قبل ظهور صورتها", "قطع الفيديو لنصفين", "عكس الفيديو", "تسريع الصوت"),
            listOf("Next clip's audio starts before its video appears", "Splitting screen", "Reversing video", "Speeding audio"), 0),
        q(9, "لماذا نضيف المؤثرات الصوتية SFX؟", "Why add Sound Effects (SFX) to a cut?",
            listOf("لتعزيز الواقعية وشد انتباه المشاهد", "لتقليل دقة الفيديو", "لإلغاء الموسيقى", "لتغيير خط النص"),
            listOf("Enhance realism, impact, and viewer immersion", "Lower resolution", "Mute music", "Change fonts"), 0),
        q(10, "ما معدل الإطارات الشائع للسينما والحركة الناعمة؟", "Which frame rate is classic for cinematic motion?",
            listOf("24 fps", "5 fps", "2 fps", "1000 fps"),
            listOf("24 fps", "5 fps", "2 fps", "1000 fps"), 0)
    )

    private val voiceOverQuestions = listOf(
        q(1, "ما النوع الصحيح من التنفس للمعلق الصوتي المحترف؟", "Which breathing technique supports steady vocal delivery?",
            listOf("التنفس الحجابي العميق", "التنفس السطحي السريع من الكتفين", "حبس النفس تمامًا", "التنفس من الفم فقط"),
            listOf("Diaphragmatic breathing", "Shallow shoulder breathing", "Holding breath", "Rapid gasping"), 0),
        q(2, "ما وظيفة فلتر البوب (Pop Filter) أمام الميكروفون؟", "What does a Pop Filter prevent?",
            listOf("انفجارات الهواء مع حروف مثل P و B", "تغيير لون الشاشة", "زيادة صدى الغرفة", "إغلاق الميكروفون"),
            listOf("Harsh air plosives on P and B sounds", "Screen flicker", "Room echo increase", "Muting mic"), 0),
        q(3, "ما المسافة الموصى بها غالبًا بين الفم والميكروفون؟", "What is the typical ideal mic distance for voice-over?",
            listOf("حوالي 10 إلى 15 سم (قبضة يد)", "متران كاملان", "ملامسة الميكروفون بالشفاه", "5 أمتار"),
            listOf("About 4 to 6 inches (one fist away)", "Two meters away", "Touching lips to capsule", "Five meters"), 0),
        q(4, "ماذا يحدث عند تجاوز مستوى الصوت 0 dBFS أثناء التسجيل؟", "What happens when recording peaks exceed 0 dBFS?",
            listOf("تشوّه رقمي Clipping يفسد جودة الصوت", "يتحسن وضوح الحروف", "يقل حجم الملف", "يختفي الصدى"),
            listOf("Digital clipping distortion occurs", "Clarity improves", "File shrinks", "Echo vanishes"), 0),
        q(5, "ما وظيفة أداة الضاغط (Compressor) في معالجة الصوت؟", "What does an audio Compressor do?",
            listOf("تقليص الفارق بين أعلى وأخفض درجات الصوت لتوازنه", "إضافة صدى عالٍ", "تحويل الصوت لصورة", "تسريع القراءة"),
            listOf("Balances dynamic range between loud and quiet parts", "Adds heavy reverb", "Converts audio to image", "Speeds up speech"), 0),
        q(6, "ما وظيفة Noise Reduction في برنامج Audacity؟", "What is Noise Reduction used for in Audacity?",
            listOf("إزالة الضوضاء الخلفية الثابتة من التسجيل", "رفع حدة الصدى", "تغيير سرعة الفيديو", "إضافة موسيقى"),
            listOf("Removing consistent background hum or hiss", "Adding echo", "Changing video FPS", "Adding music"), 0),
        q(7, "أي صيغة ملفات تحفظ الصوت بجودة خام غير مضغوطة؟", "Which audio format stores uncompressed studio quality?",
            listOf("WAV", "JPG", "GIF", "PDF"),
            listOf("WAV", "JPG", "GIF", "PDF"), 0),
        q(8, "ما أكبر عدو لجودة التسجيل الصوتي المنزلي؟", "What is the biggest enemy of home voice-over quality?",
            listOf("الصدى وانعكاسات الجدران الصلبة", "وجود سماعات رأس", "استخدام حامل ميكروفون", "قراءة النص مسبقًا"),
            listOf("Room echo and hard-wall reflections", "Headphones", "Mic stand", "Pre-reading script"), 0),
        q(9, "ما الغرض من عينة الصوت (Demo Reel)؟", "What is the purpose of a Voice-Over Demo Reel?",
            listOf("عرض قدرات وتنوع أداء المعلق الصوتي للعملاء", "إخفاء صوت المعلق", "اختبار سرعة الإنترنت", "تنزيل البرامج"),
            listOf("Showcase vocal range and delivery styles to clients", "Hide voice", "Test internet speed", "Install apps"), 0),
        q(10, "ما الذي يميز الأداء الصوتي الوثائقي؟", "What characterizes Documentary narration?",
            listOf("الاتزان، العمق، والوضوح في سرد المعلومات", "الصراخ السريع المستمر", "الهمس غير المسموع", "تكرار الكلمات"),
            listOf("Measured pacing, warmth, and authoritative clarity", "Constant shouting", "Inaudible whispering", "Skipping words"), 0)
    )

    private val cybersecurityQuestions = listOf(
        q(1, "ما المكونات الثلاثة لمثلث الأمان CIA Triad؟", "What does the CIA Triad stand for?",
            listOf("السرية، السلامة، والتوافر", "الشبكة، الكود، والتصميم", "السرعة، الحجم، والسعر", "الصوت، الصورة، والنص"),
            listOf("Confidentiality, Integrity, Availability", "Code, Internet, Apps", "Speed, Size, Cost", "Audio, Video, Text"), 0),
        q(2, "ما الغرض من المصادقة متعددة العوامل (MFA)؟", "Why enable Multi-Factor Authentication (MFA)?",
            listOf("إضافة طبقة تحقق ثانية بجانب كلمة المرور", "تسريع إغلاق الهاتف", "مشاركة كلمات المرور علنًا", "تعطيل التشفير"),
            listOf("Adds an extra verification layer beyond a password", "Shuts down phone", "Shares passwords", "Disables encryption"), 0),
        q(3, "ما المقصود بهجوم التصيد الاحتيالي (Phishing)؟", "What is a Phishing attack?",
            listOf("خداع الضحية عبر رسائل أو روابط مزيفة لسرقة بياناته", "تحديث نظام التشغيل", "تنظيف القرص الصلب", "نسخ احتياطي للصور"),
            listOf("Deceiving victims via fake messages/links to steal credentials", "Updating OS", "Disk cleanup", "Backing up photos"), 0),
        q(4, "أي أداة شهيرة تُستخدم لتحليل حزم البيانات الشبكية؟", "Which tool is widely used for packet capture and analysis?",
            listOf("Wireshark", "Illustrator", "Audacity", "Word"),
            listOf("Wireshark", "Illustrator", "Audacity", "Word"), 0),
        q(5, "ما الفرق بين HTTPS و HTTP؟", "What does HTTPS add over HTTP?",
            listOf("تشفير الاتصال عبر TLS لحماية البيانات", "حذف الصور", "إيقاف الخادم", "إزالة النصوص"),
            listOf("TLS encryption protecting data in transit", "Deletes images", "Stops server", "Removes text"), 0),
        q(6, "ما وظيفة أداة Nmap في اختبار الاختراق؟", "What is Nmap primarily used for?",
            listOf("فحص الشبكة واكتشاف المنافذ والخدمات المفتوحة", "تصميم الشعارات", "مونتاج الفيديو", "ترجمة النصوص"),
            listOf("Network discovery and port/service scanning", "Logo design", "Video editing", "Text translation"), 0),
        q(7, "ما المقصود بثغرة حقن SQL (SQL Injection)؟", "What is SQL Injection?",
            listOf("إدخال أوامر قاعدة بيانات خبيثة عبر حقول إدخال غير محمية", "ضغط الصور", "تغيير لغة التطبيق", "تحديث الخطوط"),
            listOf("Injecting malicious database queries via unsanitized inputs", "Compressing images", "Switching app language", "Updating fonts"), 0),
        q(8, "كيف نحمي كلمات المرور عند تخزينها في قواعد البيانات؟", "How should passwords be stored in a database?",
            listOf("باستخدام تجزئة آمنة مع Salt مثل bcrypt/Argon2", "كنص عادي Plaintext", "داخل تعليق HTML", "بدون حماية"),
            listOf("Strong salted cryptographic hashing (e.g. Argon2/bcrypt)", "Plaintext", "In HTML comments", "Unprotected"), 0),
        q(9, "ما مبدأ أقل صلاحية (Least Privilege)؟", "What is the Principle of Least Privilege?",
            listOf("منح المستخدم الحد الأدنى فقط من الصلاحيات اللازمة لعمله", "منح الجميع صلاحيات الأدمن", "إلغاء تسجيل الدخول", "فتح كل المنافذ"),
            listOf("Granting users only the minimum access needed for their role", "Making everyone admin", "Disabling login", "Opening all ports"), 0),
        q(10, "ما المرحلة الأولى قبل تنفيذ أي اختبار اختراق قانوني؟", "What is essential before conducting any penetration test?",
            listOf("الحصول على تفويض وإذن كتابي رسمي", "نشر الثغرات للعامة فورًا", "إيقاف الشبكة دون علم المالك", "حذف السجلات"),
            listOf("Written authorization and defined scope from the owner", "Publishing bugs immediately", "Taking down servers unannounced", "Deleting logs"), 0)
    )

    private val englishQuestions = listOf(
        q(1, "اختر الجملة الصحيحة في المضارع البسيط:", "Choose the grammatically correct Present Simple sentence:",
            listOf("She goes to school every day.", "She go to school every day.", "She going to school every day.", "She gone to school."),
            listOf("She goes to school every day.", "She go to school every day.", "She going to school every day.", "She gone to school."), 0),
        q(2, "ما الفعل الماضي من الفعل (go)؟", "What is the past simple form of 'go'?",
            listOf("goed", "went", "gone", "going"),
            listOf("goed", "went", "gone", "going"), 1),
        q(3, "أي أداة نستخدمها قبل الاسم المفرد المبدوء بصوت متحرك (مثل apple)؟", "Which article precedes a singular word starting with a vowel sound?",
            listOf("a", "an", "many", "those"),
            listOf("a", "an", "many", "those"), 1),
        q(4, "ما المقصود بمهارة التظليل (Shadowing) في تعلم الإنجليزية؟", "What is 'Shadowing' in English speaking practice?",
            listOf("تكرار الكلام مباشرة خلف المتحدث الأصلي لتحسين النطق والإيقاع", "إطفاء الشاشة", "كتابة القواعد فقط", "تجاهل الاستماع"),
            listOf("Repeating immediately after a native speaker to build rhythm", "Turning off screen", "Only copying grammar", "Skipping audio"), 0),
        q(5, "اختر حرف الجر الصحيح: I wake up ___ 7 AM.", "Choose the correct preposition: I wake up ___ 7 AM.",
            listOf("at", "on", "in", "by"),
            listOf("at", "on", "in", "by"), 0),
        q(6, "ما معنى الفعل المركب 'give up'؟", "What does the phrasal verb 'give up' mean?",
            listOf("يستسلم / يتوقف عن المحاولة", "يبدأ رحلة", "يرتدي ملابس", "يكتب رسالة"),
            listOf("Stop trying / quit", "Start a trip", "Put on clothes", "Write a letter"), 0),
        q(7, "أي جملة تعبر عن حدث مستمر الآن؟", "Which sentence describes an action happening right now?",
            listOf("They are studying English now.", "They studied yesterday.", "They study every week.", "They will study tomorrow."),
            listOf("They are studying English now.", "They studied yesterday.", "They study every week.", "They will study tomorrow."), 0),
        q(8, "اختر صيغة المقارنة الصحيحة لكلمة (fast):", "Choose the comparative form of 'fast':",
            listOf("faster", "more fast", "fastest", "fasting"),
            listOf("faster", "more fast", "fastest", "fasting"), 0),
        q(9, "ما الكلمة المناسبة للطلب بأدب؟", "Which modal verb makes a polite request?",
            listOf("Could you help me, please?", "Must you help!", "Did you helped?", "Are you help?"),
            listOf("Could you help me, please?", "Must you help!", "Did you helped?", "Are you help?"), 0),
        q(10, "ما التحية المناسبة لبدء بريد إلكتروني رسمي؟", "Which opening fits a formal English email?",
            listOf("Dear Ms. Heba,", "Yo what's up!", "Hey buddy,", "Sup!"),
            listOf("Dear Ms. Heba,", "Yo what's up!", "Hey buddy,", "Sup!"), 0)
    )

    private val chineseQuestions = listOf(
        q(1, "كم عدد النغمات الأساسية في لغة الماندرين الصينية؟", "How many primary tones exist in Mandarin Chinese?",
            listOf("4 نغمات رئيسية (بالإضافة للنغمة المحايدة)", "نغمة واحدة فقط", "12 نغمة", "لا توجد نغمات"),
            listOf("4 main tones (plus neutral tone)", "1 tone", "12 tones", "No tones"), 0),
        q(2, "ما وظيفة نظام البينيين (Pinyin)؟", "What is Pinyin used for?",
            listOf("كتابة نطق الرموز الصينية بالحروف اللاتينية", "تلوين الصور", "حساب الأرقام", "الكتابة بالكورية"),
            listOf("Romanized phonetic system for Mandarin pronunciation", "Coloring", "Counting", "Korean script"), 0),
        q(3, "ما معنى التحية الشهيرة 你好 (Nǐ hǎo)؟", "What does 你好 (Nǐ hǎo) mean?",
            listOf("مرحبًا", "إلى اللقاء", "شكرًا", "آسف"),
            listOf("Hello", "Goodbye", "Thank you", "Sorry"), 0),
        q(4, "ما معنى كلمة 谢谢 (Xièxie)؟", "What does 谢谢 (Xièxie) mean?",
            listOf("شكرًا لك", "صباح الخير", "نعم", "لا"),
            listOf("Thank you", "Good morning", "Yes", "No"), 0),
        q(5, "أي رمز يمثل الرقم 1 في الصينية؟", "Which character represents the number 1?",
            listOf("一 (yī)", "二 (èr)", "三 (sān)", "十 (shí)"),
            listOf("一 (yī)", "二 (èr)", "三 (sān)", "十 (shí)"), 0),
        q(6, "ما وظيفة الأداة 吗 (ma) في نهاية الجملة؟", "What does 吗 (ma) do at the end of a sentence?",
            listOf("تحويل الجملة إلى سؤال بنعم/لا", "نفي الجملة", "الجمع", "التعبير عن الماضي"),
            listOf("Turns a statement into a yes/no question", "Negates", "Pluralizes", "Marks past tense"), 0),
        q(7, "ما معنى الضمير 我 (wǒ)؟", "What does the pronoun 我 (wǒ) mean?",
            listOf("أنا (I / Me)", "أنت", "هم", "نحن"),
            listOf("I / Me", "You", "They", "We"), 0),
        q(8, "كيف نقول 'إلى اللقاء' بالصينية؟", "How do you say 'Goodbye' in Mandarin?",
            listOf("再见 (Zàijiàn)", "你好 (Nǐ hǎo)", "请 (Qǐng)", "水 (Shuǐ)"),
            listOf("再见 (Zàijiàn)", "你好 (Nǐ hǎo)", "请 (Qǐng)", "水 (Shuǐ)"), 0),
        q(9, "ما الترتيب الأساسي للجملة الصينية البسيطة؟", "What is the basic word order in Mandarin?",
            listOf("فاعل + فعل + مفعول (SVO)", "فعل + فاعل + مفعول", "مفعول + فعل + فاعل", "عشوائي"),
            listOf("Subject + Verb + Object (SVO)", "VSO", "OVS", "Random"), 0),
        q(10, "ما اسم المستوى الأول في اختبار الكفاءة الصيني؟", "What is the beginner level of the official Chinese proficiency exam?",
            listOf("HSK 1", "JLPT N5", "TOPIK 1", "IELTS"),
            listOf("HSK 1", "JLPT N5", "TOPIK 1", "IELTS"), 0)
    )

    private val koreanQuestions = listOf(
        q(1, "ما اسم الأبجدية الكورية الرسمية؟", "What is the Korean alphabet called?",
            listOf("هانغول (Hangul / 한글)", "كانجي", "بينيين", "سيريليك"),
            listOf("Hangul (한글)", "Kanji", "Pinyin", "Cyrillic"), 0),
        q(2, "كم عدد الحروف الأساسية في مقطع Hangul واحد على الأقل؟", "What must every Korean Hangul syllable block contain at minimum?",
            listOf("حرف ساكن ابتدائي + حرف متحرك", "حرفان متحركان فقط", "ثلاثة أرقام", "حرف ساكن فقط"),
            listOf("An initial consonant + a vowel", "Two vowels only", "Three digits", "Only a consonant"), 0),
        q(3, "ما المقصود بمصطلح Batchim (받침)؟", "What is Batchim (받침)?",
            listOf("الحرف الساكن الأخير في أسفل المقطع الصوتي الكوري", "التحية الصباحية", "أداة استفهام", "اسم مدينة"),
            listOf("The final consonant at the bottom of a syllable block", "Morning greeting", "Question word", "City name"), 0),
        q(4, "ما معنى التحية المهذبة 안녕하세요 (Annyeonghaseyo)؟", "What does 안녕하세요 mean?",
            listOf("مرحبًا (بأسلوب مهذب)", "وداعًا", "عفوًا", "لذيذ"),
            listOf("Hello (polite)", "Goodbye", "Excuse me", "Delicious"), 0),
        q(5, "ما معنى 감사합니다 (Gamsahamnida)؟", "What does 감사합니다 mean?",
            listOf("شكرًا جزيلًا", "نعم", "أنا طالب", "أين المحطة؟"),
            listOf("Thank you very much", "Yes", "I am a student", "Where is the station?"), 0),
        q(6, "ما ترتيب الجملة الأساسي في اللغة الكورية؟", "What is the standard word order in Korean sentences?",
            listOf("فاعل + مفعول + فعل (SOV)", "فاعل + فعل + مفعول", "فعل + مفعول + فاعل", "بدون ترتيب"),
            listOf("Subject + Object + Verb (SOV)", "SVO", "VOS", "Unordered"), 0),
        q(7, "أي أداة تُستخدم لتحديد الموضوع (Topic Particle)؟", "Which pair represents the Korean Topic Particle?",
            listOf("은 / 는", "에 / 에서", "와 / 과", "도 / 만"),
            listOf("은 / 는", "에 / 에서", "와 / 과", "도 / 만"), 0),
        q(8, "ما الفرق بين نظامي الأرقام في الكورية؟", "Which two number systems are used in Korean?",
            listOf("الأرقام الكورية الأصلية والأرقام الصينية-الكورية", "العربية واللاتينية", "الكورية فقط", "الأوروبية"),
            listOf("Native Korean numbers & Sino-Korean numbers", "Arabic & Latin", "Only Native", "European"), 0),
        q(9, "ما النهاية الشائعة في المضارع المهذب الرسمي غير الرسمي (Polite Informal)؟", "Which ending marks standard polite present tense?",
            listOf("-아요 / -어요", "-았어요 / -었어요", "-겠어요", "-지 마세요"),
            listOf("-아요 / -어요", "-았어요 / -었어요", "-겠어요", "-지 마세요"), 0),
        q(10, "ما معنى كلمة 네 (Ne) في الكورية؟", "What does 네 (Ne) mean?",
            listOf("نعم", "لا", "شكرًا", "غدًا"),
            listOf("Yes", "No", "Thanks", "Tomorrow"), 0)
    )
}
