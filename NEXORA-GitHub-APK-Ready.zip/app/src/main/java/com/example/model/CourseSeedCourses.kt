package com.example.model

data class LessonSeedSpec(
    val order: Int,
    val moduleAr: String,
    val moduleEn: String,
    val titleAr: String,
    val titleEn: String,
    val descAr: String,
    val descEn: String,
    val objAr: String,
    val objEn: String,
    val duration: String,
    val youtubeIdAr: String? = null,
    val youtubeIdEn: String? = null
)

object CourseSeedCourses {

    val courses: List<Course> = listOf(
        Course(
            id = "programming",
            titleAr = "البرمجة الشاملة",
            titleEn = "Programming Mastery",
            descriptionAr = "مسار متكامل لتعلم البرمجة من الصفر حتى بناء المشاريع العملية بلغة بايثون وجافاسكريبت، مع مصادر عربية افتراضية للمبتدئين وبدائل إنجليزية.",
            descriptionEn = "A complete beginner-to-advanced programming track covering Python, logic, OOP, data structures, and JavaScript with Arabic default and English track options.",
            category = "Technology",
            paid = true,
            priceEgp = 150.0,
            discountPercent = 0L,
            thumbnailKey = "programming",
            defaultLang = "ar",
            supportsBilingual = true,
            passingScore = 75L,
            published = true,
            lessonCount = 20L,
            sortOrder = 1L
        ),
        Course(
            id = "digital_art",
            titleAr = "الجرافيك ديزاين والتصميم الرقمي",
            titleEn = "Graphic Design & Digital Art",
            descriptionAr = "تعلم أساسيات التصميم الرقمي، الألوان، الفوتوشوب، والإليستريتور وبناء الهوية البصرية من المبتدئ إلى الاحتراف.",
            descriptionEn = "Master digital illustration, color theory, Photoshop compositing, and Illustrator vector design from foundations to portfolio.",
            category = "Creative",
            paid = true,
            priceEgp = 150.0,
            discountPercent = 0L,
            thumbnailKey = "digital_art",
            defaultLang = "ar",
            supportsBilingual = true,
            passingScore = 75L,
            published = true,
            lessonCount = 20L,
            sortOrder = 2L
        ),
        Course(
            id = "video_editing",
            titleAr = "المونتاج وتحرير الفيديو",
            titleEn = "Video Editing & Post-Production",
            descriptionAr = "إتقان صناعة الفيديو والمونتاج الاحترافي، تصحيح الألوان، هندسة الصوت، والانتقالات السينمائية خطوة بخطوة.",
            descriptionEn = "Learn professional video editing workflows, timeline storytelling, audio mixing, color grading, and export optimization.",
            category = "Media",
            paid = true,
            priceEgp = 150.0,
            discountPercent = 0L,
            thumbnailKey = "video_editing",
            defaultLang = "ar",
            supportsBilingual = true,
            passingScore = 75L,
            published = true,
            lessonCount = 20L,
            sortOrder = 3L
        ),
        Course(
            id = "voice_over",
            titleAr = "التعليق الصوتي وهندسة الصوت",
            titleEn = "Voice Over & Audio Mastery",
            descriptionAr = "تطوير مخارج الحروف، الأداء الصوتي، تجهيز الاستوديو المنزلي، وتنقية الصوت ومعالجته باحترافية.",
            descriptionEn = "Master vocal delivery, mic technique, home studio acoustics, and Audacity audio cleanup for commercial and documentary voice-over.",
            category = "Audio",
            paid = true,
            priceEgp = 150.0,
            discountPercent = 0L,
            thumbnailKey = "voice_over",
            defaultLang = "ar",
            supportsBilingual = true,
            passingScore = 75L,
            published = true,
            lessonCount = 20L,
            sortOrder = 4L
        ),
        Course(
            id = "cybersecurity",
            titleAr = "الأمن السيبراني",
            titleEn = "Cybersecurity Foundations",
            descriptionAr = "فهم أساسيات أمن المعلومات، الشبكات، اختبار الاختراق الأخلاقي، وحماية الأنظمة والبيانات من الهجمات.",
            descriptionEn = "Comprehensive introduction to network defense, Linux security, ethical hacking, threat analysis, and system hardening.",
            category = "Security",
            paid = true,
            priceEgp = 150.0,
            discountPercent = 0L,
            thumbnailKey = "cybersecurity",
            defaultLang = "en",
            supportsBilingual = false,
            passingScore = 75L,
            published = true,
            lessonCount = 20L,
            sortOrder = 5L
        ),
        Course(
            id = "english",
            titleAr = "اللغة الإنجليزية",
            titleEn = "English Language Track",
            descriptionAr = "كورس مجاني متكامل لتعلم اللغة الإنجليزية من الصفر: الصوتيات، القراءة، القواعد، الاستماع، والمحادثة اليومية.",
            descriptionEn = "Permanently free English mastery track covering phonetics, grammar, reading fluency, listening, and real-world speaking.",
            category = "Languages",
            paid = false,
            priceEgp = 0.0,
            discountPercent = 0L,
            thumbnailKey = "english",
            defaultLang = "ar",
            supportsBilingual = true,
            passingScore = 75L,
            published = true,
            lessonCount = 20L,
            sortOrder = 6L
        ),
        Course(
            id = "chinese",
            titleAr = "اللغة الصينية",
            titleEn = "Chinese Mandarin (HSK 1)",
            descriptionAr = "كورس مجاني لتعلم أساسيات الماندرين الصيني: نظام النغمات، البينيين، المفردات الأساسية، ومستوى HSK 1.",
            descriptionEn = "Permanently free Mandarin Chinese course introducing tones, Pinyin, essential radicals, and HSK 1 conversation.",
            category = "Languages",
            paid = false,
            priceEgp = 0.0,
            discountPercent = 0L,
            thumbnailKey = "chinese",
            defaultLang = "en",
            supportsBilingual = false,
            passingScore = 75L,
            published = true,
            lessonCount = 20L,
            sortOrder = 7L
        ),
        Course(
            id = "korean",
            titleAr = "اللغة الكورية",
            titleEn = "Korean Language & Hangul",
            descriptionAr = "كورس مجاني لتعلم الأبجدية الكورية (الهانغول)، قواعد النطق، تركيب الجمل، والمحادثات اليومية للمبتدئين.",
            descriptionEn = "Permanently free Korean track starting with Hangul reading & writing, Batchim rules, and core conversational grammar.",
            category = "Languages",
            paid = false,
            priceEgp = 0.0,
            discountPercent = 0L,
            thumbnailKey = "korean",
            defaultLang = "en",
            supportsBilingual = false,
            passingScore = 75L,
            published = true,
            lessonCount = 20L,
            sortOrder = 8L
        )
    )

    private fun map20(vararg ids: String): Map<Int, String> =
        ids.mapIndexed { idx, id -> (idx + 1) to id }.toMap()

    fun buildLessonsForCourse(courseId: String): List<Lesson> {
        val course = courses.firstOrNull { it.id == courseId } ?: return emptyList()
        val specs = when (courseId) {
            "programming" -> generic20Lessons(
                courseId = courseId,
                topics = programmingTopics,
                verifiedAr = map20(
                    "mvZHDpCHphk", "02a5T6ktx8M", "h3VCQjyaLws", "t-bCLbmgesI", "Do34NKMq80c",
                    "MWbucf-IgSI", "ij6qQQlGKtE", "5SG375hkMEs", "Lm6irXWjWIo", "mcqmcT8-v0o",
                    "B0CeWlyQj5Q", "KgheSqVZVGc", "yAW-MVCcL9Y", "BGt4Wx_V1Hg", "qdPuVAjFIYY",
                    "Yv_QhRp95lk", "-93P0Tlz7AY", "Drjvm8p013o", "zgKSMDWMuS0", "PqgrHlzpPBs"
                ),
                verifiedEn = map20(
                    "7S_tz1z_5bA", "WzMjd3AOX8U", "K5KVEU3aaeQ", "Ej_02ICOIgs", "_uQrJ0TkZlc",
                    "f79MRyMsjrQ", "iLRZi0Gu8Go", "8JJ101D3knE", "pTB0EiLXUC8", "mAFoROnOfHs",
                    "W6NZfCO5SIk", "eWRfhZUzrAc", "HGOBQPFzWKo", "iw0znRuaYL8", "0sOvCWFmrtA",
                    "SiBw7os-_zI", "vzGllw18DkA", "rfscVS0vtbw", "nLRL_NcnK-4", "PkZNo7MFNFg"
                )
            )
            "digital_art" -> generic20Lessons(
                courseId = courseId,
                topics = digitalArtTopics,
                verifiedAr = map20(
                    "agpFGqIA1zc", "YPicVGhPV1o", "ouDICXmug-M", "rpoMde9wb_c", "1NfzmrUyEhQ",
                    "1BcaG23V3pM", "Fe_oEDD8Kus", "9Y9cFOrzfFQ", "BzTEyF4cOMo", "tiM0ZCsEnCA",
                    "mFTfrILDSaY", "JBQLRVuPQYc", "ywhtSvl8AmU", "StGAQEt078E", "CzYZUqEqMiE",
                    "MRelU1US614", "xi1ierdIux4", "yD66BBLtcM8", "cLOwJW999sY", "95z8qp4lxVY"
                ),
                verifiedEn = map20(
                    "LU7cL7KySSE", "KhP3RnAa82w", "1Qo0KJi0fsg", "trI0jafycTA", "LKD22wa-tp4",
                    "9OUbTON6Y_E", "dy6Ix_X4HIU", "ckAidMjZGIc", "5L8BBVNBheM", "Ovl820PVv_E",
                    "1gJemb9iF3w", "wF1WuheCdaU", "4sJ1D1mL3uY", "5fknVcsIQPs", "CCGYlSq8sqc",
                    "cWuvTSDU0pw", "OzemCeywKOM", "zL-Z8LqaOvo", "kmwAVVYytlc", "r9gaPGQ1EG0"
                )
            )
            "video_editing" -> generic20Lessons(
                courseId = courseId,
                topics = videoEditingTopics,
                verifiedAr = map20(
                    "1TNIu81i_NE", "65FWCTKj8Kg", "w-vl8fFi4Qo", "2cnbsbsaLrE", "8iGvUZKeLeU",
                    "9Hf-OQ-MZ4A", "PjD_wf7nCWU", "9KE3v3xkKB0", "UEqCrZSd924", "LEqgRPA0U3Y",
                    "Z85m2FXsbdc", "Nle8Bzezqio", "ge6TU1PKAPw", "VUEZfHPtom0", "GLSgp37mWjc",
                    "N3jSI4nBP7w", "52Agv1plsyM", "yLhV84NndWM", "F14qi-FVuqk", "ag8pRJb7N3Q"
                ),
                verifiedEn = map20(
                    "SrJOE2pEp7A", "-Ynu9chzrkE", "hmtQbL7AA0I", "CTQsT9rG2l8", "MCDVcQIA3UM",
                    "LcGsaIV8QBY", "rp6cTMARWkA", "-MrHvGoq9lY", "ff2FAnj0E5U", "5t7r3204_9U",
                    "vd2fi_JbKTc", "aCTJ7MjpAOw", "oUlpbue-Gw0", "nfXDr104z8c", "vv6mtkEwGAU",
                    "pagfhHitRfQ", "CkQ_-8KIv6w", "4quIBV6Sm0A", "jZahGDVKuOg", "sh5MEb5cX1M"
                )
            )
            "voice_over" -> generic20Lessons(
                courseId = courseId,
                topics = voiceOverTopics,
                verifiedAr = map20(
                    "uUYEa1XhIXA", "eTwN39ARaOc", "IGonbGB3PDQ", "X77j1ppdwXc", "SFrYGuqIzOQ",
                    "2J9PeWknDnA", "e2ch0ynvSsU", "5vG2Hd3m9CQ", "tFAkffwcfEw", "4cEtoMoB58k",
                    "Trns3cPdDKE", "cnm9h8tqmAc", "d7ItZE5WQKk", "rTF_8DNbskA", "naQs1bv97UQ",
                    "Y-2PyIDagkw", "hHzcEZvgz2o", "s47TjBA9qQg", "ooSI5Q0e8_M", "Gu1dHl_UHDA"
                ),
                verifiedEn = map20(
                    "zanH_cswN_s", "Q8piTf-AiZ0", "_FIziEz5RTE", "74YPoty_HlM", "WsmMMKRZp5g",
                    "E6qZmWlkklQ", "9hJR9mVo9D8", "oKk2HiqTSDo", "usHht-e9QEo", "sYqATC-aWBA",
                    "7tyabiTMvb8", "EHcyxeBNSzA", "vlzOb4OLj94", "CXdiHyMUWYI", "yzJ2VyYkmaA",
                    "4R27qPl1mnE", "bvU5Ed6tHDg", "F76H5PtZB7w", "7ki3b4C_LJg", "T0boiBk6-hY"
                )
            )
            "cybersecurity" -> generic20Lessons(
                courseId = courseId,
                topics = cybersecurityTopics,
                verifiedEn = map20(
                    "4t4kBkMsDbQ", "a_4MjV_-7Sw", "3s9RF6E3eyI", "qTaOZrDnMzQ", "F2PXe_o7KqM",
                    "ug8W0sFiVJo", "xynY7UOEhE8", "j6aLYaQ_0-A", "27zYf9EPhWw", "ps-1aX6TZcY",
                    "zWoHJ3oGRGY", "YwjJpEUZwik", "JHAMj2vN2oU", "p3vaaD9pn9I", "eKVFWoMyMH0",
                    "MdPbxXDtkVs", "NBE0PLUHWWY", "vAx_lJX_i3U", "fInOaxX7pDA", "f02MVO8VjYg"
                )
            )
            "english" -> generic20Lessons(
                courseId = courseId,
                topics = englishTopics,
                verifiedAr = map20(
                    "77IK9T45kiU", "AZZCsweJaiw", "804e5iDYzSc", "DTZAQ9B1yIU", "jXgOjgokSgI",
                    "8sB-clmlZTg", "69aLCcVsrnw", "_44mTsUG-b0", "82a1udwePtk", "v7S1q845FMk",
                    "LtrWXSeaDz8", "FoxJ1JzYnbs", "QstM8dPBta8", "i2jNSIyyJTI", "ul6G2Djsego",
                    "xF9BTIhwXQA", "sFSXWQpDeMc", "d4a3T4dDpSw", "mbzeiuIQKPo", "26qCP6YLfiA"
                )
            )
            "chinese" -> generic20Lessons(
                courseId = courseId,
                topics = chineseTopics,
                verifiedEn = map20(
                    "qgL7NrduGJc", "9XbQJPF817I", "n_Cj3aOSI1w", "FlaJ12tmtu4", "R2mmwOfbydM",
                    "MQAqmovRQxg", "McZW0iDsZns", "kzYmiZueNjs", "ff1HM7BegjA", "q2hrlAGewvY",
                    "NHS3fB2zXUs", "v1UT9fM_uik", "gmkxd91MGjo", "z7FiGFhhV34", "mfBwNIjMbss",
                    "ioBSLcibMJg", "OewzOCvDYjg", "nHDQm4NXq7Q", "FO3z4bFdsSE", "Vx_o25zVRBo"
                )
            )
            "korean" -> generic20Lessons(
                courseId = courseId,
                topics = koreanTopics,
                verifiedEn = map20(
                    "Z9ZxsgMAZmI", "Lw_dhoqlyLU", "sx0yyQqkpqo", "U49SJ-evntU", "V2-VvI3nyjE",
                    "VHu_OimMUB0", "0u8ZlmTQ5Tk", "opw_tSJzJ7A", "4ALVtqegCuI", "uNDf0V06m0w",
                    "TUSNTV7VkcI", "7Sakz7p-ERY", "TbSGXBuln18", "IgnnLQ6iLnU", "gy3OM03JdLU",
                    "c4WF-oE_aQc", "pku3hXtgmeo", "NE2e6qP_iSc", "cFGEI8WkM_A", "1UvbO-P_Z6E"
                )
            )
            else -> emptyList()
        }

        return specs.map { spec ->
            val hasVideo = !spec.youtubeIdAr.isNullOrBlank() || !spec.youtubeIdEn.isNullOrBlank()
            Lesson(
                id = "${courseId}_l${spec.order.toString().padStart(2, '0')}",
                courseId = courseId,
                orderIndex = spec.order.toLong(),
                moduleTitleAr = spec.moduleAr,
                moduleTitleEn = spec.moduleEn,
                titleAr = spec.titleAr,
                titleEn = spec.titleEn,
                descriptionAr = spec.descAr,
                descriptionEn = spec.descEn,
                objectivesAr = spec.objAr,
                objectivesEn = spec.objEn,
                durationLabel = spec.duration,
                youtubeIdAr = spec.youtubeIdAr,
                youtubeIdEn = spec.youtubeIdEn,
                defaultLang = course.defaultLang,
                videoStatus = if (hasVideo) "READY" else "NEEDS_CONTENT",
                published = true
            )
        }
    }

    private fun generic20Lessons(
        courseId: String,
        topics: List<Pair<String, String>>,
        verifiedAr: Map<Int, String> = emptyMap(),
        verifiedEn: Map<Int, String> = emptyMap()
    ): List<LessonSeedSpec> {
        return topics.mapIndexed { idx, (arTitle, enTitle) ->
            val order = idx + 1
            val modIdx = (idx / 5) + 1
            val (modAr, modEn) = when (modIdx) {
                1 -> "الوحدة 1: التأسيس والانطلاق" to "Module 1: Core Foundations"
                2 -> "الوحدة 2: المهارات الأساسية" to "Module 2: Essential Techniques"
                3 -> "الوحدة 3: التطبيق العملي" to "Module 3: Applied Practice"
                else -> "الوحدة 4: الاحتراف والمشروع النهائي" to "Module 4: Mastery & Capstone"
            }
            LessonSeedSpec(
                order = order,
                moduleAr = modAr,
                moduleEn = modEn,
                titleAr = "$order. $arTitle",
                titleEn = "$order. $enTitle",
                descAr = "درس منظم ضمن مسار التعلم المتدرج يركز على: $arTitle مع تطبيقات خطوة بخطوة.",
                descEn = "Structured lesson in the progressive track focusing on: $enTitle with practical guidance.",
                objAr = "• فهم المبادئ الأساسية لـ $arTitle\n• تطبيق الخطوات العملية بثقة",
                objEn = "• Understand key concepts of $enTitle\n• Apply practical exercises accurately",
                duration = "${14 + (idx % 4) * 5}m",
                youtubeIdAr = verifiedAr[order],
                youtubeIdEn = verifiedEn[order]
            )
        }
    }

    private val programmingTopics = listOf(
        "مقدمة إلى البرمجة وعقلية المبرمج" to "Introduction to Programming & Logic",
        "تجهيز بيئة العمل وكتابة أول كود" to "Environment Setup & First Program",
        "المتغيرات وأنواع البيانات الأساسية" to "Variables & Primitive Data Types",
        "التعامل مع النصوص والعمليات الحسابية" to "Strings & Arithmetic Operations",
        "الشروط المنطقية If / Else" to "Conditional Statements (If / Elif / Else)",
        "حلقات التكرار While و For" to "Loops & Iteration (For / While)",
        "القوائم والمصفوفات Lists" to "Lists & Array Operations",
        "القواميس والمجموعات Dictionaries & Sets" to "Dictionaries, Tuples & Sets",
        "الدوال وإعادة استخدام الكود Functions" to "Functions, Parameters & Scope",
        "معالجة الأخطاء والاستثناءات" to "Error & Exception Handling",
        "التعامل مع الملفات و JSON" to "File I/O & JSON Processing",
        "البرمجة كائنية التوجه OOP - الكلاسات" to "OOP: Classes & Objects",
        "الوراثة وتعدد الأشكال في OOP" to "OOP: Inheritance & Polymorphism",
        "مفاهيم الخوارزميات وهياكل البيانات" to "Algorithms & Data Structures Intro",
        "مدخل إلى تطوير الويب بـ JavaScript" to "JavaScript Web Foundations",
        "التحكم في DOM والبرمجة غير المتزامنة" to "DOM Manipulation & Async JS",
        "العمل مع واجهات برمجة التطبيقات APIs" to "Working with REST APIs",
        "استخدام Git و GitHub لإدارة المشاريع" to "Version Control with Git & GitHub",
        "اختبار الكود وتصحيح الأخطاء Debugging" to "Unit Testing & Debugging",
        "مشروع التخرج التطبيقي المتكامل" to "Full Capstone Coding Project"
    )

    private val digitalArtTopics = listOf(
        "مبادئ التصميم الرقمي والفن البصري" to "Principles of Digital Art & Composition",
        "واجهة برنامج فوتوشوب وإعداد مساحة العمل" to "Photoshop Workspace & Canvas Setup",
        "فهم الطبقات Layers وأنماط الدمج" to "Mastering Layers & Blend Modes",
        "أدوات التحديد والقص الاحترافية" to "Precision Selection & Masking",
        "نظرية الألوان والتناغم البصري" to "Color Theory & Palette Harmony",
        "الفرش الرقمية وضبط الحساسية" to "Digital Brushes & Stroke Dynamics",
        "الإضاءة والظلال وبناء المجسمات" to "Lighting, Shadows & Form Rendering",
        "تعديل الصور والرتوش الاحترافية" to "Photo Retouching & Color Correction",
        "استخدام الأقنعة غير المدمرة Non-Destructive" to "Non-Destructive Adjustment Layers",
        "مقدمة إلى الرسم المتجهي Vector في إليستريتور" to "Vector Foundations in Illustrator",
        "إتقان أداة القلم Pen Tool والمنحنيات" to "Mastering the Pen & Curvature Tools",
        "بناء الأشكال الهندسية والشعارات" to "Shape Builder & Geometric Logo Design",
        "التدرجات اللونية والعمق البصري" to "Gradients, Mesh & Visual Depth",
        "فن التايبوجرافي واختيار الخطوط" to "Typography & Bilingual Font Pairing",
        "تصميم البوسترات وإعلانات السوشيال ميديا" to "Social Media & Poster Layout Design",
        "تصميم الشخصيات والاسكتش الرقمي" to "Character Sketching & Concept Art",
        "بناء الهوية البصرية المتكاملة" to "Brand Identity System Design",
        "تجهيز الملفات للطباعة والويب" to "Exporting for Print & Digital Screens",
        "بناء معرض الأعمال Portfolio الاحترافي" to "Curating a Professional Art Portfolio",
        "مشروع التخرج: حملة تصميم متكاملة" to "Capstone Visual Identity Project"
    )

    private val videoEditingTopics = listOf(
        "مقدمة إلى فن المونتاج والسرد البصري" to "Art of Video Editing & Storytelling",
        "تنظيم الملفات وإعداد مشروع التحرير" to "Project Setup & Media Organization",
        "فهم الخط الزمني Timeline وأدوات القص" to "Timeline Navigation & Precision Cuts",
        "أنواع القطع والإيقاع السينمائي" to "Cut Types, Pacing & Rhythm",
        "إضافة الانتقالات Transitions باحترافية" to "Clean Transitions & Motion Flow",
        "الحركة والمفاتيح الزمنية Keyframes" to "Keyframing Position, Scale & Opacity",
        "الكتابة والعناوين المتحركة بالعربية والإنجليزية" to "Titles, Subtitles & Lower Thirds",
        "التحكم في السرعة Speed Ramping" to "Speed Ramping & Time Remapping",
        "توازن الصوت وتنقية الضوضاء" to "Audio Mixing, Levels & Noise Cleanup",
        "اختيار الموسيقى والمؤثرات الصوتية SFX" to "Sound Design, Music & SFX Sync",
        "أساسيات تصحيح الألوان Color Correction" to "Color Correction & Exposure Balance",
        "التدرج اللوني السينمائي Color Grading" to "Cinematic Color Grading & LUTs",
        "استخدام الكروما Green Screen وعزل الخلفية" to "Chroma Keying & Background Masking",
        "العمل مع لقطات متعددة الكاميرات" to "Multi-Cam Editing Workflow",
        "تثبيت الاهتزاز وتنعيم الحركة" to "Video Stabilization & Smooth Shots",
        "مونتاج الفيديوهات القصيرة Reels & Shorts" to "Vertical Short-Form Editing",
        "تحسين الأداء والعمل بالبروكسي Proxies" to "Proxy Workflows & Performance",
        "تصدير الفيديو بأعلى جودة لجميع المنصات" to "Export Presets, Bitrate & Codecs",
        "تسريع العمل باختصارات لوحة المفاتيح" to "Keyboard Shortcuts & Pro Efficiency",
        "مشروع التخرج: مونتاج فيلم قصير متكامل" to "Capstone Short Film Edit"
    )

    private val voiceOverTopics = listOf(
        "عالم التعليق الصوتي وأنواعه الاحترافية" to "Intro to Voice Over & Career Paths",
        "فهم خامة الصوت واكتشاف الطبقة المناسبة" to "Discovering Your Vocal Range & Tone",
        "تمارين التنفس الحجابي والتحكم بالهواء" to "Diaphragmatic Breathing & Breath Control",
        "تمارين الإحماء الصوتي ومخارج الحروف" to "Vocal Warmups & Articulation Drills",
        "إيقاع القراءة والوقفات الدرامية" to "Pacing, Pausing & Script Marking",
        "تجهيز الاستوديو المنزلي وعزل الصدى" to "Home Studio Acoustics & Soundproofing",
        "اختيار الميكروفون وواجهة الصوت" to "Microphones, Pop Filters & Interfaces",
        "وضعيات الميكروفون والمسافة المثالية" to "Mic Placement & Proximity Control",
        "إعداد برنامج Audacity للتسجيل الاحترافي" to "Configuring Audacity for Voice Recording",
        "ضبط مستويات التسجيل Gain ومنع التشويه" to "Gain Staging & Avoiding Clipping",
        "تنقية الضوضاء وإزالة أصوات التنفس" to "Noise Reduction & De-Breathing",
        "استخدام الضاغط Compressor والمعادل EQ" to "EQ & Compression for Vocal Clarity",
        "المعايرة الصوتية Normalization و Loudness" to "Normalization & Broadcast LUFS",
        "الأداء التجاري للإعلانات التجارية" to "Commercial & Promo Voice Delivery",
        "الأداء الوثائقي والسرد القصصي" to "Documentary & Storytelling Narration",
        "التعليق الصوتي للموشن جرافيك والرسوم" to "Explainer & Motion Graphics VO",
        "أساسيات الدوبلاج وتقمص الشخصيات" to "Dubbing & Character Voice Acting",
        "أنظمة الرد الآلي IVR والكتب الصوتية" to "IVR Systems & Audiobook Narration",
        "تصدير الملفات وبناء عينة الصوت Demo Reel" to "Exporting WAV/MP3 & Building Demo Reel",
        "مشروع التخرج: تسجيل وميكساج إعلان كامل" to "Capstone Commercial VO Production"
    )

    private val cybersecurityTopics = listOf(
        "مقدمة في الأمن السيبراني ومثلث CIA" to "Intro to Cybersecurity & CIA Triad",
        "مفاهيم التهديدات والثغرات والمخاطر" to "Threats, Vulnerabilities & Risk Analysis",
        "أساسيات الشبكات وبروتوكولات TCP/IP" to "Networking Basics & TCP/IP Model",
        "أمن DNS و HTTP/HTTPS والتشفير" to "DNS, HTTPS & TLS Encryption",
        "أساسيات نظام لينكس للمختصين الأمنيين" to "Linux Essentials & Command Line",
        "إدارة الصلاحيات وتأمين أنظمة التشغيل" to "OS Hardening & Access Control",
        "تحليل الحزم الشبكية باستخدام Wireshark" to "Packet Inspection with Wireshark",
        "البرمجيات الخبيثة وأنواع الهجمات الشائعة" to "Malware Types & Attack Vectors",
        "الهندسة الاجتماعية والتصيد الاحتيالي Phishing" to "Social Engineering & Phishing Defense",
        "أمن كلمات المرور والمصادقة متعددة العوامل" to "Authentication, Hashing & MFA",
        "تشفير البيانات المتماثل وغير المتماثل" to "Symmetric & Asymmetric Cryptography",
        "مبادئ اختبار الاختراق الأخلاقي" to "Ethical Hacking Methodology",
        "جمع المعلومات والاستطلاع OSINT" to "Reconnaissance & OSINT Techniques",
        "فحص المنافذ والشبكات باستخدام Nmap" to "Network Scanning with Nmap",
        "أمن تطبيقات الويب و OWASP Top 10" to "Web App Security & OWASP Top 10",
        "ثغرات حقن SQL و XSS وكيفية الوقاية" to "SQL Injection & XSS Mitigation",
        "الجدران النارية وأنظمة كشف التسلل IDS" to "Firewalls, IDS/IPS & Zero Trust",
        "الاستجابة للحوادث والتحليل الجنائي الرقمي" to "Incident Response & Digital Forensics",
        "أمن السحابة والخصوصية الرقمية" to "Cloud Security & Privacy Best Practices",
        "مشروع التخرج: تقييم أمني شامل لنظام" to "Capstone Security Audit Assessment"
    )

    private val englishTopics = listOf(
        "خطة دراسة الإنجليزية والحروف والأصوات" to "Study Roadmap & English Alphabet Sounds",
        "نطق الحروف المتحركة القصيرة والطويلة" to "Short & Long Vowel Pronunciation",
        "الأصوات المركبة والساكنة في الأمريكية" to "Consonant Clusters & Digraphs",
        "أهمية اللهجة والنطق الصحيح للأذن" to "Accent Clarity & Connected Speech",
        "التحيات والتعريف بالنفس في الحياة اليومية" to "Greetings & Self-Introductions",
        "تكوين الجملة البسيطة والضمائر" to "Sentence Structure & Pronouns",
        "زمن المضارع البسيط والمضارع المستمر" to "Present Simple vs Present Continuous",
        "زمن الماضي البسيط والأفعال الشاذة" to "Past Simple & Irregular Verbs",
        "التعبير عن المستقبل Will و Going to" to "Future Forms: Will & Going To",
        "أدوات التعريف والتنكير وحروف الجر" to "Articles (A/An/The) & Prepositions",
        "مهارة القراءة وفهم الفقرات القصيرة" to "Reading Comprehension Strategies",
        "تطوير الاستماع والفهم من المتحدثين الأصليين" to "Active Listening & Shadowing",
        "المحادثة في المطعم والتسوق والسفر" to "Daily Dialogues: Travel & Shopping",
        "الأفعال المركبة Phrasal Verbs الأساسية" to "Essential Phrasal Verbs",
        "المقارنة والتفضيل والصفات" to "Adjectives, Comparatives & Superlatives",
        "الأفعال الناقصة Modal Verbs" to "Modal Verbs (Can, Should, Must)",
        "بناء حصيلة مفردات العمل والتكنولوجيا" to "Workplace & Tech Vocabulary",
        "الكتابة الصحيحة للرسائل والإيميلات" to "Writing Clear Emails & Paragraphs",
        "التعبيرات الشائعة وتجنب الأخطاء المتكررة" to "Common Idioms & Mistake Fixes",
        "تطبيق شامل: محادثة وقراءة متكاملة" to "Capstone Fluency Review"
    )

    private val chineseTopics = listOf(
        "مقدمة الماندرين ونظام البينيين والنغمات" to "Mandarin Intro, Pinyin & 4 Tones",
        "التدريب العملي على النغمات الأربعة" to "Tone Pairs & Pronunciation Drills",
        "الأصوات الابتدائية والنهائية في الصينية" to "Pinyin Initials & Finals Mastery",
        "التحيات الأساسية والتعريف بالاسم" to "Essential Greetings & Introductions",
        "الأرقام من 1 إلى 100 بالصينية" to "Numbers 1–100 & Counting",
        "الضمائر الشخصية وتركيب الجملة البسيطة" to "Pronouns & Basic SVO Sentences",
        "أدوات الاستفهام والأسئلة بـ Ma" to "Asking Questions with 吗 (Ma)",
        "مقدمة إلى الرموز الصينية والخطوط الأساسية" to "Chinese Strokes & Character Radicals",
        "الحديث عن العائلة والأصدقاء" to "Family Members & Relationships",
        "الأيام والأشهر والتاريخ والوقت" to "Days, Months, Dates & Time",
        "الأفعال اليومية: الأكل والشرب والذهاب" to "Core Daily Verbs (Eat, Drink, Go)",
        "التسوق والأسعار والعملات" to "Shopping, Prices & Bargaining",
        "الطلب في المطعم والمأكولات" to "Ordering Food & Drinks",
        "الألوان والصفات البسيطة" to "Colors & Descriptive Adjectives",
        "المواصلات والاتجاهات في المدينة" to "Transportation & Asking Directions",
        "الطقس والفصول الأربعة" to "Weather & Seasons Expressions",
        "المهن والدراسة والهوايات" to "Professions, Study & Hobbies",
        "أداة النفي Bu و Mei واستخدام Le" to "Negation (不/没) & Particle 了",
        "مراجعة مفردات HSK 1 الـ 150 كلمة" to "HSK 1 Vocabulary & Dialogues Review",
        "محادثة تطبيقية شاملة لمستوى HSK 1" to "Capstone HSK 1 Conversation"
    )

    private val koreanTopics = listOf(
        "مقدمة إلى الأبجدية الكورية الهانغول" to "Introduction to Hangul Alphabet",
        "الحروف الساكنة الأساسية ونطقها" to "Basic Korean Consonants",
        "الحروف المتحركة البسيطة والمركبة" to "Simple & Compound Vowels",
        "تجميع المقاطع الصوتية وقراءة الكلمات" to "Syllable Block Building & Reading",
        "قاعدة الحرف النهائي Batchim" to "Mastering Final Consonants (Batchim)",
        "الحروف الساكنة المشددة والمنفوخة" to "Double & Aspirated Consonants",
        "التحيات الكورية وآداب التحية" to "Korean Greetings & Politeness Levels",
        "التعريف بالنفس والجنسية والمهنة" to "Self-Introductions & Nationality",
        "الأرقام الكورية الأصلية والصينية" to "Native Korean vs Sino-Korean Numbers",
        "الضمائر وأدوات الإشارة هذا وذلك" to "Demonstratives (이/그/저) & Pronouns",
        "أدوات الموضوع والفاعل 은/는 و 이/가" to "Topic & Subject Particles",
        "تصريف الأفعال في المضارع غير الرسمي المهذب" to "Present Tense Conjugation (-아/어요)",
        "الأماكن وأدوات المكان 에 و 에서" to "Location Particles (에 vs 에서)",
        "الماضي والمستقبل في اللغة الكورية" to "Past & Future Tense Basics",
        "الطلب في المطاعم والمقاهي الكورية" to "Ordering Food & Cafe Phrases",
        "التسوق والألوان والأسعار" to "Shopping, Colors & Won Currency",
        "التعبير عن الوقت والجدول اليومي" to "Telling Time & Daily Routine",
        "الهوايات والتعبير عن الإعجاب والقدرة" to "Expressing Likes & Abilities",
        "حوارات السفر والمواصلات في سيول" to "Travel & Subway Dialogues",
        "مراجعة شاملة وقراءة نص كوري متكامل" to "Capstone Hangul & Dialogue Review"
    )
}
