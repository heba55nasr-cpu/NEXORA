package com.example.core

/**
 * Pure-Kotlin ISO/IEC 18004 QR Code Generator (Version 1-6, Byte Mode, ECC Level L).
 * Produces real, scannable QR code matrices with zero third-party dependencies.
 */
object QrCodeGenerator {

    private data class VersionSpec(
        val version: Int,
        val size: Int,
        val totalDataCodewords: Int,
        val eccCodewords: Int,
        val alignmentCenters: IntArray
    )

    // Standard QR Version specs (Single block, ECC Level L) for Versions 1..5
    private val VERSIONS = listOf(
        VersionSpec(1, 21, 19, 7, intArrayOf()),
        VersionSpec(2, 25, 34, 10, intArrayOf(6, 18)),
        VersionSpec(3, 29, 55, 15, intArrayOf(6, 22)),
        VersionSpec(4, 33, 80, 20, intArrayOf(6, 26)),
        VersionSpec(5, 37, 108, 26, intArrayOf(6, 30))
    )

    private val GF_EXP = IntArray(512)
    private val GF_LOG = IntArray(256)

    init {
        var x = 1
        for (i in 0 until 255) {
            GF_EXP[i] = x
            GF_LOG[x] = i
            x = x shl 1
            if (x >= 256) x = x xor 0x11D
        }
        for (i in 255 until 512) {
            GF_EXP[i] = GF_EXP[i - 255]
        }
    }

    private fun gfMul(a: Int, b: Int): Int {
        if (a == 0 || b == 0) return 0
        return GF_EXP[GF_LOG[a] + GF_LOG[b]]
    }

    private fun rsGeneratorPoly(degree: Int): IntArray {
        var poly = intArrayOf(1)
        for (i in 0 until degree) {
            val factor = intArrayOf(1, GF_EXP[i])
            val next = IntArray(poly.size + 1)
            for (j in poly.indices) {
                for (k in factor.indices) {
                    next[j + k] = next[j + k] xor gfMul(poly[j], factor[k])
                }
            }
            poly = next
        }
        return poly
    }

    private fun rsEncode(data: IntArray, eccCount: Int): IntArray {
        val gen = rsGeneratorPoly(eccCount)
        val res = IntArray(data.size + eccCount)
        System.arraycopy(data, 0, res, 0, data.size)
        for (i in data.indices) {
            val coef = res[i]
            if (coef != 0) {
                for (j in 1 until gen.size) {
                    res[i + j] = res[i + j] xor gfMul(gen[j], coef)
                }
            }
        }
        return res.copyOfRange(data.size, res.size)
    }

    fun encode(text: String): Array<BooleanArray> {
        val bytes = text.toByteArray(Charsets.UTF_8)
        val spec = VERSIONS.firstOrNull { (bytes.size + 2) <= it.totalDataCodewords }
            ?: VERSIONS.last()
        val maxBytes = (spec.totalDataCodewords - 2).coerceAtLeast(1)
        val payload = if (bytes.size > maxBytes) bytes.copyOf(maxBytes) else bytes

        val bits = ArrayList<Int>(spec.totalDataCodewords * 8)
        fun appendBits(value: Int, count: Int) {
            for (i in (count - 1) downTo 0) {
                bits.add((value ushr i) and 1)
            }
        }

        // Byte mode indicator (0100) + 8-bit length
        appendBits(0b0100, 4)
        appendBits(payload.size, 8)
        for (b in payload) {
            appendBits(b.toInt() and 0xFF, 8)
        }
        val capacityBits = spec.totalDataCodewords * 8
        val terminator = minOf(4, capacityBits - bits.size)
        repeat(terminator) { bits.add(0) }
        while (bits.size % 8 != 0) bits.add(0)

        val padBytes = intArrayOf(0xEC, 0x11)
        var padIdx = 0
        while (bits.size < capacityBits) {
            appendBits(padBytes[padIdx % 2], 8)
            padIdx++
        }

        val dataCodewords = IntArray(spec.totalDataCodewords) { idx ->
            var v = 0
            for (b in 0 until 8) {
                v = (v shl 1) or bits[idx * 8 + b]
            }
            v
        }
        val ecc = rsEncode(dataCodewords, spec.eccCodewords)
        val allCodewords = dataCodewords + ecc

        val n = spec.size
        val modules = Array(n) { BooleanArray(n) }
        val isFunction = Array(n) { BooleanArray(n) }

        fun setFunction(r: Int, c: Int, dark: Boolean) {
            if (r in 0 until n && c in 0 until n) {
                modules[r][c] = dark
                isFunction[r][c] = true
            }
        }

        fun drawFinder(top: Int, left: Int) {
            for (dr in -1..7) {
                for (dc in -1..7) {
                    val r = top + dr
                    val c = left + dc
                    if (r in 0 until n && c in 0 until n) {
                        val dark = dr in 0..6 && dc in 0..6 && (
                            dr == 0 || dr == 6 || dc == 0 || dc == 6 || (dr in 2..4 && dc in 2..4)
                        )
                        setFunction(r, c, dark)
                    }
                }
            }
        }

        drawFinder(0, 0)
        drawFinder(0, n - 7)
        drawFinder(n - 7, 0)

        // Alignment patterns
        for (rCenter in spec.alignmentCenters) {
            for (cCenter in spec.alignmentCenters) {
                if ((rCenter < 9 && cCenter < 9) ||
                    (rCenter < 9 && cCenter > n - 10) ||
                    (rCenter > n - 10 && cCenter < 9)
                ) continue
                for (dr in -2..2) {
                    for (dc in -2..2) {
                        val dark = maxOf(kotlin.math.abs(dr), kotlin.math.abs(dc)) != 1
                        setFunction(rCenter + dr, cCenter + dc, dark)
                    }
                }
            }
        }

        // Timing patterns
        for (i in 8 until n - 8) {
            val dark = (i % 2) == 0
            if (!isFunction[6][i]) setFunction(6, i, dark)
            if (!isFunction[i][6]) setFunction(i, 6, dark)
        }

        // Dark module & reserve format info
        setFunction(n - 8, 8, true)
        for (i in 0..8) {
            if (i != 6) {
                isFunction[8][i] = true
                isFunction[i][8] = true
            }
        }
        for (i in 0..7) {
            isFunction[8][n - 1 - i] = true
            if (i < 7) isFunction[n - 1 - i][8] = true
        }

        // Place data bits (zig-zag)
        var bitIndex = 0
        val totalBits = allCodewords.size * 8
        var up = true
        var col = n - 1
        while (col > 0) {
            if (col == 6) col--
            val rows = if (up) (n - 1 downTo 0) else (0 until n)
            for (row in rows) {
                for (dc in 0..1) {
                    val c = col - dc
                    if (!isFunction[row][c]) {
                        val bit = if (bitIndex < totalBits) {
                            (allCodewords[bitIndex / 8] ushr (7 - (bitIndex % 8))) and 1
                        } else 0
                        modules[row][c] = bit == 1
                        bitIndex++
                    }
                }
            }
            up = !up
            col -= 2
        }

        // Apply Mask 0 ((r + c) % 2 == 0) + Format Info for ECC Level L (01), Mask 0 (000)
        // Precomputed 15-bit BCH format for L + Mask 0 = 0x77C4 (111011111000100)
        val mask = 0
        for (r in 0 until n) {
            for (c in 0 until n) {
                if (!isFunction[r][c] && ((r + c) % 2 == 0)) {
                    modules[r][c] = !modules[r][c]
                }
            }
        }
        val formatBits = 0x77C4 // Level L (01) + Mask 0 (000) masked with 101010000010010
        for (i in 0..5) setFunction(8, i, ((formatBits ushr (14 - i)) and 1) == 1)
        setFunction(8, 7, ((formatBits ushr (14 - 6)) and 1) == 1)
        setFunction(8, 8, ((formatBits ushr (14 - 7)) and 1) == 1)
        setFunction(7, 8, ((formatBits ushr (14 - 8)) and 1) == 1)
        for (i in 9..14) setFunction(14 - i, 8, ((formatBits ushr (14 - i)) and 1) == 1)

        for (i in 0..6) setFunction(n - 1 - i, 8, ((formatBits ushr (14 - i)) and 1) == 1)
        for (i in 7..14) setFunction(8, n - 15 + i, ((formatBits ushr (14 - i)) and 1) == 1)

        return modules
    }
}
