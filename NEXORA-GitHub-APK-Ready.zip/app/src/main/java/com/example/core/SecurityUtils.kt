package com.example.core

import android.net.Uri
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

object SecurityUtils {
    private const val EXAM_SALT = "nexora_heba_nasr_exam_2026"
    private val YOUTUBE_ID_REGEX = Regex("^[a-zA-Z0-9_-]{11}$")
    private val CERT_CODE_REGEX = Regex("^NX-20[0-9]{2}-[A-Z0-9_-]{4,24}$")
    val EGYPT_TIME_ZONE: TimeZone = TimeZone.getTimeZone("Africa/Cairo")

    fun sha256Hex(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(input.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    fun hashExamAnswer(courseId: String, questionId: String, optionIndex: Int): String {
        return sha256Hex("$courseId:$questionId:$optionIndex:$EXAM_SALT")
    }

    fun isValidYoutubeId(id: String?): Boolean {
        return !id.isNullOrBlank() && YOUTUBE_ID_REGEX.matches(id.trim())
    }

    fun extractYoutubeVideoId(rawInput: String): String? {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return null
        if (YOUTUBE_ID_REGEX.matches(trimmed)) return trimmed

        val patterns = listOf(
            Regex("""(?:youtube\.com/watch\?(?:.*&)?v=)([a-zA-Z0-9_-]{11})"""),
            Regex("""(?:youtu\.be/)([a-zA-Z0-9_-]{11})"""),
            Regex("""(?:youtube\.com/embed/)([a-zA-Z0-9_-]{11})"""),
            Regex("""(?:youtube\.com/shorts/)([a-zA-Z0-9_-]{11})""")
        )
        for (pattern in patterns) {
            val match = pattern.find(trimmed)
            if (match != null) {
                return match.groupValues[1]
            }
        }
        return null
    }

    fun formatEgyptDate(date: Date = Date()): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        sdf.timeZone = EGYPT_TIME_ZONE
        return sdf.format(date)
    }

    fun currentEgyptYear(date: Date = Date()): Int {
        val cal = Calendar.getInstance(EGYPT_TIME_ZONE, Locale.US)
        cal.time = date
        return cal.get(Calendar.YEAR)
    }

    fun formatSequentialCertificateCode(year: Int, sequence: Long): String {
        val safeSeq = sequence.coerceAtLeast(1L)
        return String.format(Locale.US, "NX-%04d-%06d", year, safeSeq)
    }

    fun generateCertificateCode(courseId: String, sequence: Long = 1L, date: Date = Date()): String {
        val year = currentEgyptYear(date)
        return if (sequence > 0L) {
            formatSequentialCertificateCode(year, sequence)
        } else {
            val prefix = courseId.take(3).uppercase(Locale.US).replace(Regex("[^A-Z0-9]"), "X")
            val suffix = UUID.randomUUID().toString().replace("-", "").take(6).uppercase(Locale.US)
            "NX-$year-$prefix-$suffix"
        }
    }

    fun extractCertificateCodeFromUri(uri: Uri?): String? {
        if (uri == null) return null
        val queryCode = uri.getQueryParameter("code")?.trim()?.uppercase(Locale.US)
        if (!queryCode.isNullOrBlank() && CERT_CODE_REGEX.matches(queryCode)) {
            return queryCode
        }
        val segments = uri.pathSegments.orEmpty()
        val last = segments.lastOrNull()?.trim()?.uppercase(Locale.US)
        if (!last.isNullOrBlank() && CERT_CODE_REGEX.matches(last)) {
            return last
        }
        return null
    }

    fun generateDocId(prefix: String): String {
        val clean = prefix.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(24)
        val suffix = UUID.randomUUID().toString().replace("-", "").take(10)
        return "${clean}_$suffix"
    }

    fun isValidNamePart(part: String): Boolean {
        val clean = part.trim()
        return clean.length >= 2 && !clean.contains('@')
    }

    fun composeTripleName(firstName: String, fatherName: String, familyName: String): String {
        return listOf(firstName, fatherName, familyName)
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .joinToString(" ")
    }

    fun splitTripleName(fullName: String): Triple<String, String, String> {
        val parts = fullName.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        return when {
            parts.size >= 3 -> Triple(parts[0], parts[1], parts.drop(2).joinToString(" "))
            parts.size == 2 -> Triple(parts[0], parts[1], "")
            parts.size == 1 -> Triple(parts[0], "", "")
            else -> Triple("", "", "")
        }
    }

    fun isTripleName(name: String): Boolean {
        val clean = name.trim()
        if (clean.contains('@')) return false
        val parts = clean.split(Regex("\\s+")).filter { it.length >= 2 }
        return parts.size >= 3
    }
}
