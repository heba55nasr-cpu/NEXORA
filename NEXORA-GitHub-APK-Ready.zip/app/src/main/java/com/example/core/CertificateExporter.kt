package com.example.core

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.model.Certificate
import com.example.model.PlatformConfig
import java.io.File
import java.io.FileOutputStream
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

object CertificateExporter {

    private val ARABIC_REGEX = Regex("[\\u0600-\\u06FF]")

    fun renderCertificateBitmap(
        context: Context,
        cert: Certificate,
        verificationBaseUrl: String = PlatformConfig.DEFAULT_VERIFICATION_BASE_URL
    ): Bitmap {
        val width = 1600
        val height = 1130
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val playfairTypeface = runCatching {
            ResourcesCompat.getFont(context, R.font.playfair_display)
        }.getOrNull() ?: Typeface.SERIF
        val playfairBold = Typeface.create(playfairTypeface, Typeface.BOLD)
        val playfairItalic = Typeface.create(playfairTypeface, Typeface.ITALIC)
        val playfairBoldItalic = Typeface.create(playfairTypeface, Typeface.BOLD_ITALIC)

        val kaushanTypeface = runCatching {
            ResourcesCompat.getFont(context, R.font.kaushan_script)
        }.getOrNull() ?: Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)

        val dancingTypeface = runCatching {
            ResourcesCompat.getFont(context, R.font.dancing_script)
        }.getOrNull() ?: Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)

        val jakartaTypeface = runCatching {
            ResourcesCompat.getFont(context, R.font.plus_jakarta_sans)
        }.getOrNull() ?: Typeface.SANS_SERIF
        val jakartaBold = Typeface.create(jakartaTypeface, Typeface.BOLD)

        val cairoTypeface = runCatching {
            ResourcesCompat.getFont(context, R.font.cairo)
        }.getOrNull() ?: Typeface.SANS_SERIF
        val cairoBold = Typeface.create(cairoTypeface, Typeface.BOLD)

        // 1. Background alabaster + subtle lavender atmospheric glow + flowing purple waves
        drawBackgroundAndWaves(canvas, width.toFloat(), height.toFloat())

        // 2. Decorative double purple border with inward quarter-circle corner cutouts
        drawReferenceBorderFrame(canvas, width.toFloat(), height.toFloat())

        // 3. Top-left slogan: "Learn • Grow • Achieve" + "Your Skills .. Your Future" + curved purple swoosh
        drawTopLeftSlogan(canvas, playfairBoldItalic, playfairItalic)

        // 4. Top-center: Official NEXORA crystal N logo + "Nexora" directly underneath
        drawOfficialHeaderLogo(context, canvas, width / 2f, jakartaBold)

        // 5. Top-right: Gold rosette seal with graduation cap, laurel wreath & purple V-cut ribbons
        drawGraduationSeal(canvas, 1442f, 154f)

        // 6. Main Certificate Title & Red OF COMPLETION bar
        val blackTitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0D0D0D")
            textSize = 108f
            textAlign = Paint.Align.CENTER
            typeface = playfairBold
        }
        canvas.drawText("Certificate", width / 2f, 412f, blackTitlePaint)

        val redOfCompPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#DF1111")
            textSize = 31f
            textAlign = Paint.Align.CENTER
            typeface = playfairBold
            letterSpacing = 0.28f
        }
        val ofCompText = "OF COMPLETION"
        val ofCompHalfW = redOfCompPaint.measureText(ofCompText) / 2f
        val barY = 452f
        canvas.drawText(ofCompText, width / 2f, 463f, redOfCompPaint)

        val redDashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#DF1111")
            strokeWidth = 2.4f
        }
        canvas.drawLine(width / 2f - ofCompHalfW - 56f, barY, width / 2f - ofCompHalfW - 14f, barY, redDashPaint)
        canvas.drawLine(width / 2f + ofCompHalfW + 14f, barY, width / 2f + ofCompHalfW + 56f, barY, redDashPaint)

        val purpleLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#6D32AD")
            strokeWidth = 2.2f
        }
        canvas.drawLine(240f, 439f, width / 2f - ofCompHalfW - 88f, 439f, purpleLinePaint)
        canvas.drawLine(width / 2f + ofCompHalfW + 88f, 439f, width - 240f, 439f, purpleLinePaint)

        // 7. "This is to certify that"
        val bodySerifPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#141414")
            textSize = 34f
            textAlign = Paint.Align.CENTER
            typeface = playfairTypeface
        }
        canvas.drawText("This is to certify that", width / 2f, 520f, bodySerifPaint)

        // 8. Student's Complete Registered Name (in RED cursive script + red underline)
        val displayStudentName = cert.studentName.trim().ifBlank { "Student Name" }
        val isArabicName = ARABIC_REGEX.containsMatchIn(displayStudentName)
        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F00808")
            textAlign = Paint.Align.CENTER
            typeface = if (isArabicName) cairoBold else kaushanTypeface
            textSize = 86f
        }
        val maxNameWidth = 1040f
        while (namePaint.measureText(displayStudentName) > maxNameWidth && namePaint.textSize > 42f) {
            namePaint.textSize -= 2f
        }
        canvas.drawText(displayStudentName, width / 2f, 616f, namePaint)

        val redUnderlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E61C1C")
            strokeWidth = 2.5f
        }
        canvas.drawLine(324f, 642f, width - 324f, 642f, redUnderlinePaint)

        // 9. Course completion statement + Course name + Red exam score percentage
        bodySerifPaint.textSize = 31f
        canvas.drawText("has successfully completed the", width / 2f, 692f, bodySerifPaint)

        val courseTitle = cert.courseTitleEn.ifBlank { cert.courseTitleAr }.trim()
        val courseHasArabic = ARABIC_REGEX.containsMatchIn(courseTitle)
        val courseDisplay = if (courseHasArabic || courseTitle.contains("course", ignoreCase = true) || courseTitle.contains("track", ignoreCase = true)) {
            courseTitle
        } else {
            "$courseTitle Course"
        }
        val coursePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0D0D0D")
            textSize = 44f
            textAlign = Paint.Align.CENTER
            typeface = if (courseHasArabic) cairoBold else playfairBold
        }
        while (coursePaint.measureText(courseDisplay) > 1060f && coursePaint.textSize > 26f) {
            coursePaint.textSize -= 2f
        }
        canvas.drawText(courseDisplay, width / 2f, 745f, coursePaint)

        // Draw "and passed the final exam with a score of " (black) + "<score>%" (RED) centered seamlessly
        val scorePrefix = "and passed the final exam with a score of "
        val scoreText = "${cert.scorePercent}%"
        val scorePrefixPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#141414")
            textSize = 31f
            textAlign = Paint.Align.LEFT
            typeface = playfairTypeface
        }
        val scoreRedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#EE0E0E")
            textSize = 43f
            textAlign = Paint.Align.LEFT
            typeface = playfairBold
        }
        val prefixWidth = scorePrefixPaint.measureText(scorePrefix)
        val scoreWidth = scoreRedPaint.measureText(scoreText)
        val combinedStartX = (width - (prefixWidth + scoreWidth)) / 2f
        canvas.drawText(scorePrefix, combinedStartX, 796f, scorePrefixPaint)
        canvas.drawText(scoreText, combinedStartX + prefixWidth, 797f, scoreRedPaint)

        // Awarding paragraph
        val awardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1C1C1C")
            textSize = 24f
            textAlign = Paint.Align.CENTER
            typeface = playfairTypeface
        }
        canvas.drawText("This certificate is awarded by NEXORA by Heba Nasr", width / 2f, 842f, awardPaint)
        canvas.drawText("in recognition of your dedication, hard work and commitment to learning.", width / 2f, 874f, awardPaint)

        // 10. Bottom Row (Director signature | Issue Date | Certificate Number | QR Code & Verify URL)
        val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#7D44BA")
            strokeWidth = 2f
        }
        canvas.drawLine(538f, 944f, 538f, 1044f, dividerPaint)
        canvas.drawLine(826f, 944f, 826f, 1044f, dividerPaint)
        canvas.drawLine(1204f, 944f, 1204f, 1044f, dividerPaint)

        // Column 1: Black "Director" + Red Handwritten "Heba Nasr" signature with slanted red swoosh
        val directorLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#101010")
            textSize = 25f
            textAlign = Paint.Align.CENTER
            typeface = playfairBold
        }
        canvas.drawText("Director", 336f, 944f, directorLabelPaint)

        canvas.save()
        canvas.rotate(-13f, 336f, 1004f)
        val sigPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#EF1010")
            textSize = 48f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(dancingTypeface, Typeface.BOLD)
        }
        canvas.drawText("Heba Nasr", 336f, 1006f, sigPaint)
        val sigLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#EF1010")
            strokeWidth = 3f
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        val sigPath = Path().apply {
            moveTo(210f, 1020f)
            quadTo(335f, 1011f, 456f, 1024f)
        }
        canvas.drawPath(sigPath, sigLinePaint)
        canvas.restore()

        // Column 2: Issue Date (Black)
        val metaLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#242424")
            textSize = 22f
            textAlign = Paint.Align.CENTER
            typeface = playfairTypeface
        }
        val metaValuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0D0D0D")
            textSize = 31f
            textAlign = Paint.Align.CENTER
            typeface = playfairTypeface
        }
        canvas.drawText("Issue Date", 682f, 968f, metaLabelPaint)
        canvas.drawText(cert.issuedDateLabel, 682f, 1012f, metaValuePaint)

        // Column 3: Certificate Number (Black)
        canvas.drawText("Certificate Number", 1015f, 968f, metaLabelPaint)
        val certNumPaint = Paint(metaValuePaint).apply {
            textSize = 30f
        }
        while (certNumPaint.measureText(cert.certificateCode) > 340f && certNumPaint.textSize > 18f) {
            certNumPaint.textSize -= 1f
        }
        canvas.drawText(cert.certificateCode, 1015f, 1012f, certNumPaint)

        // Column 4: Real QR Code + "Verify Certificate\nat <real domain>"
        val cleanBaseUrl = verificationBaseUrl.trim().trimEnd('/')
            .takeIf { it.startsWith("https://") || it.startsWith("http://") }
            ?: PlatformConfig.DEFAULT_VERIFICATION_BASE_URL
        val verifyUrl = "$cleanBaseUrl/verify/${cert.certificateCode}"
        val verifyHost = cleanBaseUrl.removePrefix("https://").removePrefix("http://").substringBefore('/')

        val qrMatrix = QrCodeGenerator.encode(verifyUrl)
        val qrSize = 128f
        val qrCenterX = 1404f
        val qrLeft = qrCenterX - qrSize / 2f
        val qrTop = 878f
        val cell = qrSize / qrMatrix.size

        val qrBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        val qrBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D6C6EC")
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
        }
        val qrRect = RectF(qrLeft - 8f, qrTop - 8f, qrLeft + qrSize + 8f, qrTop + qrSize + 8f)
        canvas.drawRect(qrRect, qrBgPaint)
        canvas.drawRect(qrRect, qrBorderPaint)

        val qrDarkPaint = Paint().apply { color = Color.parseColor("#111111") }
        for (r in qrMatrix.indices) {
            for (c in qrMatrix.indices) {
                if (qrMatrix[r][c]) {
                    canvas.drawRect(
                        qrLeft + c * cell,
                        qrTop + r * cell,
                        qrLeft + (c + 1) * cell,
                        qrTop + (r + 1) * cell,
                        qrDarkPaint
                    )
                }
            }
        }

        val verifyCaptionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#141414")
            textSize = 20f
            textAlign = Paint.Align.CENTER
            typeface = playfairTypeface
        }
        canvas.drawText("Verify Certificate", qrCenterX, 1038f, verifyCaptionPaint)
        val atDomainText = "at $verifyHost"
        val hostPaint = Paint(verifyCaptionPaint).apply { textSize = 19f }
        while (hostPaint.measureText(atDomainText) > 280f && hostPaint.textSize > 12f) {
            hostPaint.textSize -= 0.5f
        }
        canvas.drawText(atDomainText, qrCenterX, 1062f, hostPaint)

        return bitmap
    }

    private fun drawBackgroundAndWaves(canvas: Canvas, w: Float, h: Float) {
        canvas.drawColor(Color.parseColor("#FCFAFF"))

        // Subtle lavender glow top-left
        val leftGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                140f, 180f, 680f,
                intArrayOf(Color.parseColor("#EFE2FB"), Color.parseColor("#FCFAFF")),
                floatArrayOf(0f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, w, h, leftGlow)

        // Subtle soft purple aura top-right & bottom-right
        val bottomRightGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                w * 0.92f, h * 0.78f, 620f,
                intArrayOf(Color.parseColor("#E9D5FB"), Color.TRANSPARENT),
                floatArrayOf(0f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, w, h, bottomRightGlow)

        // Fine flowing lavender contour lines across left/center
        val waveLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.4f
        }
        for (i in 0 until 20) {
            val t = i / 19f
            val alpha = ((1f - kotlin.math.abs(t - 0.5f) * 1.4f).coerceIn(0.18f, 0.75f) * 130).toInt()
            waveLinePaint.color = Color.argb(alpha, 178, 126, 232)
            val yOff = i * 11.5f
            val path = Path().apply {
                moveTo(-20f, 600f - yOff)
                cubicTo(
                    w * 0.14f, 180f + yOff * 0.7f,
                    w * 0.42f, 440f + yOff * 0.45f,
                    w * 0.68f, 890f - yOff * 0.6f
                )
                cubicTo(
                    w * 0.80f, 1020f - yOff * 0.4f,
                    w * 0.94f, 940f + yOff * 0.3f,
                    w + 40f, 820f + yOff * 0.5f
                )
            }
            canvas.drawPath(path, waveLinePaint)
        }

        // Top-right flowing purple ribbon waves
        val topRightWave1 = Path().apply {
            moveTo(w * 0.52f, 0f)
            cubicTo(w * 0.65f, 88f, w * 0.86f, 200f, w, 260f)
            lineTo(w, 0f)
            close()
        }
        canvas.drawPath(
            topRightWave1,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    w * 0.55f, 0f, w, 260f,
                    Color.parseColor("#38C884EC"), Color.parseColor("#C28A3FD1"),
                    Shader.TileMode.CLAMP
                )
            }
        )

        val topRightWave2 = Path().apply {
            moveTo(w * 0.62f, 0f)
            cubicTo(w * 0.72f, 65f, w * 0.88f, 92f, w, 195f)
            lineTo(w, 0f)
            close()
        }
        canvas.drawPath(
            topRightWave2,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    w * 0.64f, 0f, w, 195f,
                    Color.parseColor("#8E571B9E"), Color.parseColor("#E69C51DF"),
                    Shader.TileMode.CLAMP
                )
            }
        )

        val topRightHighlight = Path().apply {
            moveTo(w * 0.58f, 0f)
            cubicTo(w * 0.70f, 46f, w * 0.87f, 68f, w, 130f)
            lineTo(w, 96f)
            cubicTo(w * 0.86f, 44f, w * 0.72f, 22f, w * 0.64f, 0f)
            close()
        }
        canvas.drawPath(
            topRightHighlight,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#52FFFFFF")
            }
        )

        // Bottom-right flowing multi-layered waves
        val botRightOuter = Path().apply {
            moveTo(w * 0.76f, h)
            cubicTo(w * 0.88f, h * 0.86f, w * 0.94f, h * 0.62f, w, h * 0.36f)
            lineTo(w, h)
            close()
        }
        canvas.drawPath(
            botRightOuter,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    w * 0.78f, h, w, h * 0.42f,
                    Color.parseColor("#42C599F0"), Color.parseColor("#889B53E0"),
                    Shader.TileMode.CLAMP
                )
            }
        )

        val botRightInner = Path().apply {
            moveTo(w * 0.85f, h)
            cubicTo(w * 0.92f, h * 0.88f, w * 0.96f, h * 0.70f, w, h * 0.54f)
            lineTo(w, h)
            close()
        }
        canvas.drawPath(
            botRightInner,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    w * 0.86f, h, w, h * 0.54f,
                    Color.parseColor("#669E57E0"), Color.parseColor("#B57429C2"),
                    Shader.TileMode.CLAMP
                )
            }
        )

        // Bottom-left deep purple corner sweep
        val botLeftOuter = Path().apply {
            moveTo(0f, h * 0.82f)
            cubicTo(85f, h * 0.91f, 240f, h * 0.96f, 450f, h)
            lineTo(0f, h)
            close()
        }
        canvas.drawPath(
            botLeftOuter,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    0f, h * 0.82f, 450f, h,
                    Color.parseColor("#C28A37D6"), Color.parseColor("#38D6B5F7"),
                    Shader.TileMode.CLAMP
                )
            }
        )
        val botLeftInner = Path().apply {
            moveTo(0f, h * 0.89f)
            cubicTo(60f, h * 0.95f, 155f, h * 0.98f, 260f, h)
            lineTo(0f, h)
            close()
        }
        canvas.drawPath(
            botLeftInner,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#C86921B0")
            }
        )
    }

    private fun drawReferenceBorderFrame(canvas: Canvas, w: Float, h: Float) {
        val mOuter = 24f
        val rOuter = 26f
        val outerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#55218B")
            style = Paint.Style.STROKE
            strokeWidth = 3.2f
        }
        // Subtle corner rectangular brackets matching reference
        canvas.drawLine(mOuter, mOuter, mOuter + rOuter, mOuter, outerPaint)
        canvas.drawLine(mOuter, mOuter, mOuter, mOuter + rOuter, outerPaint)
        canvas.drawLine(w - mOuter - rOuter, mOuter, w - mOuter, mOuter, outerPaint)
        canvas.drawLine(w - mOuter, mOuter, w - mOuter, mOuter + rOuter, outerPaint)
        canvas.drawLine(mOuter, h - mOuter, mOuter + rOuter, h - mOuter, outerPaint)
        canvas.drawLine(mOuter, h - mOuter - rOuter, mOuter, h - mOuter, outerPaint)
        canvas.drawLine(w - mOuter - rOuter, h - mOuter, w - mOuter, h - mOuter, outerPaint)
        canvas.drawLine(w - mOuter, h - mOuter - rOuter, w - mOuter, h - mOuter, outerPaint)

        // Outer frame with inward quarter-circle corner arcs
        val outerPath = buildInwardNotchPath(mOuter, mOuter, w - mOuter, h - mOuter, rOuter)
        canvas.drawPath(outerPath, outerPaint)

        // Delicate inner hairline frame
        val mInner = 34f
        val rInner = 20f
        val innerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#854CC2")
            style = Paint.Style.STROKE
            strokeWidth = 1.4f
        }
        val innerPath = buildInwardNotchPath(mInner, mInner, w - mInner, h - mInner, rInner)
        canvas.drawPath(innerPath, innerPaint)
    }

    private fun buildInwardNotchPath(left: Float, top: Float, right: Float, bottom: Float, r: Float): Path {
        return Path().apply {
            moveTo(left + r, top)
            lineTo(right - r, top)
            arcTo(RectF(right - r, top - r, right + r, top + r), 180f, -90f)
            lineTo(right, bottom - r)
            arcTo(RectF(right - r, bottom - r, right + r, bottom + r), 270f, -90f)
            lineTo(left + r, bottom)
            arcTo(RectF(left - r, bottom - r, left + r, bottom + r), 0f, -90f)
            lineTo(left, top + r)
            arcTo(RectF(left - r, top - r, left + r, top + r), 90f, -90f)
            close()
        }
    }

    private fun drawTopLeftSlogan(canvas: Canvas, serifBoldItalic: Typeface, serifItalic: Typeface) {
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#111111")
            textSize = 38f
            typeface = serifBoldItalic
            textAlign = Paint.Align.LEFT
        }
        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#5B1A9E")
            style = Paint.Style.FILL
        }

        val seg1 = "Learn"
        val seg2 = "Grow"
        val seg3 = "Achieve"
        val gap = 46f
        val w1 = textPaint.measureText(seg1)
        val w2 = textPaint.measureText(seg2)
        val w3 = textPaint.measureText(seg3)
        val totalW = w1 + gap + w2 + gap + w3
        val centerX = 308f
        val startX = centerX - totalW / 2f
        val topY = 120f

        canvas.drawText(seg1, startX, topY, textPaint)
        canvas.drawCircle(startX + w1 + gap / 2f, topY - 12f, 5f, dotPaint)
        canvas.drawText(seg2, startX + w1 + gap, topY, textPaint)
        canvas.drawCircle(startX + w1 + gap + w2 + gap / 2f, topY - 12f, 5f, dotPaint)
        canvas.drawText(seg3, startX + w1 + gap + w2 + gap, topY, textPaint)

        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#181818")
            textSize = 26f
            typeface = serifItalic
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("Your Skills .. Your Future", centerX, 162f, subPaint)

        // Tapered upward purple swoosh underneath slogan
        val swooshPath = Path().apply {
            moveTo(166f, 196f)
            quadTo(centerX, 179f, 444f, 194f)
            quadTo(centerX, 185f, 166f, 196f)
            close()
        }
        canvas.drawPath(
            swooshPath,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#6E28B8")
                style = Paint.Style.FILL
            }
        )
    }

    private fun drawOfficialHeaderLogo(context: Context, canvas: Canvas, centerX: Float, wordmarkTypeface: Typeface) {
        // Subtle soft purple luminous aura matching reference image behind the crystal-N logo
        val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                centerX, 134f, 145f,
                intArrayOf(Color.parseColor("#44A55AE8"), Color.TRANSPARENT),
                floatArrayOf(0f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawCircle(centerX, 134f, 145f, glowPaint)

        val rawLogo = BitmapFactory.decodeResource(context.resources, R.drawable.img_nexora_logo_light)
        if (rawLogo != null) {
            val cleanLogo = extractLogoWithoutDarkBox(rawLogo)
            val logoSize = 232f
            val dest = RectF(
                centerX - logoSize / 2f,
                22f,
                centerX + logoSize / 2f,
                22f + logoSize
            )
            canvas.drawBitmap(cleanLogo, null, dest, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        }

        val wordmarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#4B148C")
            textSize = 60f
            textAlign = Paint.Align.CENTER
            typeface = wordmarkTypeface
        }
        canvas.drawText("Nexora", centerX, 294f, wordmarkPaint)
    }

    private fun extractLogoWithoutDarkBox(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        if (w <= 0 || h <= 0) return src
        val pixels = IntArray(w * h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        val bgPixel = src.getPixel(min(4, w - 1), min(4, h - 1))
        val bgR = Color.red(bgPixel)
        val bgG = Color.green(bgPixel)
        val bgB = Color.blue(bgPixel)

        val cx = w / 2f
        val cy = h / 2f
        val rx = w / 2f
        val ry = h / 2f

        for (i in pixels.indices) {
            val px = pixels[i]
            val r = Color.red(px)
            val g = Color.green(px)
            val b = Color.blue(px)

            val dr = max(0, r - bgR)
            val dg = max(0, g - bgG)
            val db = max(0, b - bgB)
            val diff = max(dr, max(dg, db))

            val x = i % w
            val y = i / w
            val normDist = hypot((x - cx) / rx, (y - cy) / ry)

            val rawAlpha = ((diff - 16f) / 68f).coerceIn(0f, 1f).pow(0.70f)
            val edgeMask = (1f - ((normDist - 0.80f) / 0.16f)).coerceIn(0f, 1f)
            val a = (rawAlpha * edgeMask * 255f).toInt().coerceIn(0, 255)

            if (a <= 2) {
                pixels[i] = Color.TRANSPARENT
            } else if (a < 252) {
                val af = a / 255f
                val outR = (((r - bgR * (1f - af)) / af)).toInt().coerceIn(0, 255)
                val outG = (((g - bgG * (1f - af)) / af)).toInt().coerceIn(0, 255)
                val outB = (((b - bgB * (1f - af)) / af)).toInt().coerceIn(0, 255)
                pixels[i] = Color.argb(a, outR, outG, outB)
            } else {
                pixels[i] = Color.argb(255, r, g, b)
            }
        }
        return Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun drawGraduationSeal(canvas: Canvas, cx: Float, cy: Float) {
        // 1. Two downward splayed purple ribbons with gold borders & V-notch tails
        fun drawRibbon(angleDeg: Float) {
            canvas.save()
            canvas.translate(cx, cy + 54f)
            canvas.rotate(angleDeg)
            val ribbon = Path().apply {
                moveTo(-22f, 0f)
                lineTo(22f, 0f)
                lineTo(22f, 118f)
                lineTo(0f, 98f)
                lineTo(-22f, 118f)
                close()
            }
            val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    0f, 0f, 0f, 118f,
                    Color.parseColor("#421478"), Color.parseColor("#863ED1"),
                    Shader.TileMode.CLAMP
                )
            }
            val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#E3A73B")
                style = Paint.Style.STROKE
                strokeWidth = 2.6f
            }
            canvas.drawPath(ribbon, fillPaint)
            canvas.drawPath(ribbon, borderPaint)
            canvas.restore()
        }
        drawRibbon(20f)
        drawRibbon(-20f)

        // 2. Scalloped outer gold rosette
        val scallops = 24
        val outerR = 102f
        val innerR = 92f
        val rosettePath = Path()
        val steps = scallops * 2
        for (i in 0 until steps) {
            val angle = (i.toDouble() / steps) * 2.0 * PI
            val r = if (i % 2 == 0) outerR else innerR
            val x = cx + (cos(angle) * r).toFloat()
            val y = cy + (sin(angle) * r).toFloat()
            if (i == 0) rosettePath.moveTo(x, y) else rosettePath.lineTo(x, y)
        }
        rosettePath.close()

        val rosetteShadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#2A4B148C")
        }
        canvas.save()
        canvas.translate(4f, 6f)
        canvas.drawPath(rosettePath, rosetteShadow)
        canvas.restore()

        val goldFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                cx - 24f, cy - 28f, outerR * 1.4f,
                intArrayOf(
                    Color.parseColor("#FFF2AE"),
                    Color.parseColor("#F5B642"),
                    Color.parseColor("#D47E19")
                ),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawPath(rosettePath, goldFillPaint)
        canvas.drawPath(
            rosettePath,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#B86812")
                style = Paint.Style.STROKE
                strokeWidth = 2.2f
            }
        )

        // Inner circular gold groove
        canvas.drawCircle(
            cx, cy, 74f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#C9781A")
                style = Paint.Style.STROKE
                strokeWidth = 2.4f
            }
        )

        // 3. Symmetrical black laurel wreath inside seal
        val iconBlack = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#181818")
            style = Paint.Style.FILL
        }
        val stemPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#181818")
            style = Paint.Style.STROKE
            strokeWidth = 3f
            strokeCap = Paint.Cap.ROUND
        }
        for (side in listOf(-1f, 1f)) {
            val stemRect = RectF(cx - 56f, cy - 52f, cx + 56f, cy + 56f)
            if (side < 0) {
                canvas.drawArc(stemRect, 112f, 132f, false, stemPaint)
            } else {
                canvas.drawArc(stemRect, 68f, -132f, false, stemPaint)
            }
            for (k in 0 until 7) {
                val deg = 122f + k * 19f
                val rad = Math.toRadians(if (side < 0) deg.toDouble() else (180.0 - deg))
                val lx = cx + (cos(rad) * 55f).toFloat()
                val ly = cy + (sin(rad) * 53f).toFloat()
                canvas.save()
                canvas.translate(lx, ly)
                canvas.rotate(if (side < 0) deg - 75f else (180f - deg) + 75f)
                val leaf = RectF(-5.5f, -10f, 5.5f, 10f)
                canvas.drawOval(leaf, iconBlack)
                canvas.restore()
            }
        }

        // 4. Black Academic Graduation Cap (mortarboard + skullcap + tassel)
        val capDiamond = Path().apply {
            moveTo(cx, cy - 30f)
            lineTo(cx + 38f, cy - 12f)
            lineTo(cx, cy + 5f)
            lineTo(cx - 38f, cy - 12f)
            close()
        }
        canvas.drawPath(capDiamond, iconBlack)

        val capBase = Path().apply {
            moveTo(cx - 21f, cy - 2f)
            lineTo(cx, cy + 8f)
            lineTo(cx + 21f, cy - 2f)
            lineTo(cx + 21f, cy + 16f)
            quadTo(cx, cy + 27f, cx - 21f, cy + 16f)
            close()
        }
        canvas.drawPath(capBase, iconBlack)

        val tasselCord = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#181818")
            style = Paint.Style.STROKE
            strokeWidth = 2.6f
        }
        canvas.drawLine(cx - 29f, cy - 7f, cx - 29f, cy + 15f, tasselCord)
        canvas.drawCircle(cx - 29f, cy + 17f, 4f, iconBlack)
    }

    fun saveCertificatePngFile(
        context: Context,
        cert: Certificate,
        verificationBaseUrl: String = PlatformConfig.DEFAULT_VERIFICATION_BASE_URL
    ): File {
        val dir = File(context.cacheDir, "certificates").apply { mkdirs() }
        val file = File(dir, "${cert.certificateCode}.png")
        val bitmap = renderCertificateBitmap(context, cert, verificationBaseUrl)
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        return file
    }

    fun saveCertificatePdfFile(
        context: Context,
        cert: Certificate,
        verificationBaseUrl: String = PlatformConfig.DEFAULT_VERIFICATION_BASE_URL
    ): File {
        val dir = File(context.cacheDir, "certificates").apply { mkdirs() }
        val file = File(dir, "${cert.certificateCode}.pdf")
        val bitmap = renderCertificateBitmap(context, cert, verificationBaseUrl)
        val doc = PdfDocument()
        try {
            val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, 1).create()
            val page = doc.startPage(pageInfo)
            page.canvas.drawBitmap(bitmap, 0f, 0f, null)
            doc.finishPage(page)
            FileOutputStream(file).use { out -> doc.writeTo(out) }
        } finally {
            runCatching { doc.close() }
        }
        return file
    }

    fun shareCertificatePng(
        context: Context,
        cert: Certificate,
        verificationBaseUrl: String = PlatformConfig.DEFAULT_VERIFICATION_BASE_URL
    ): Result<Unit> = runCatching {
        val file = saveCertificatePngFile(context, cert, verificationBaseUrl)
        shareFile(context, file, "image/png", "NEXORA Certificate ${cert.certificateCode}")
    }

    fun shareCertificatePdf(
        context: Context,
        cert: Certificate,
        verificationBaseUrl: String = PlatformConfig.DEFAULT_VERIFICATION_BASE_URL
    ): Result<Unit> = runCatching {
        val file = saveCertificatePdfFile(context, cert, verificationBaseUrl)
        shareFile(context, file, "application/pdf", "NEXORA Certificate ${cert.certificateCode}")
    }

    fun printCertificate(
        context: Context,
        cert: Certificate,
        verificationBaseUrl: String = PlatformConfig.DEFAULT_VERIFICATION_BASE_URL
    ) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val bitmap = renderCertificateBitmap(context, cert, verificationBaseUrl)
        val jobName = "NEXORA_${cert.certificateCode}"
        printManager.print(
            jobName,
            object : PrintDocumentAdapter() {
                override fun onLayout(
                    oldAttributes: PrintAttributes?,
                    newAttributes: PrintAttributes?,
                    cancellationSignal: CancellationSignal?,
                    callback: LayoutResultCallback,
                    extras: Bundle?
                ) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback.onLayoutCancelled()
                        return
                    }
                    val info = PrintDocumentInfo.Builder("${cert.certificateCode}.pdf")
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(1)
                        .build()
                    callback.onLayoutFinished(info, true)
                }

                override fun onWrite(
                    pages: Array<out PageRange>?,
                    destination: ParcelFileDescriptor,
                    cancellationSignal: CancellationSignal?,
                    callback: WriteResultCallback
                ) {
                    val doc = PdfDocument()
                    val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, 1).create()
                    val page = doc.startPage(pageInfo)
                    page.canvas.drawBitmap(bitmap, 0f, 0f, null)
                    doc.finishPage(page)
                    try {
                        FileOutputStream(destination.fileDescriptor).use { out -> doc.writeTo(out) }
                        callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                    } catch (e: Exception) {
                        callback.onWriteFailed(e.message)
                    } finally {
                        doc.close()
                    }
                }
            },
            PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4.asLandscape())
                .build()
        )
    }

    private fun shareFile(context: Context, file: File, mimeType: String, title: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, title))
    }
}
