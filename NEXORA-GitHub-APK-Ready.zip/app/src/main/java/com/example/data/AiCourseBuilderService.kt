package com.example.data

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

data class AiGeneratedLessonDraft(
    val orderIndex: Int,
    val moduleTitleAr: String,
    val moduleTitleEn: String,
    val titleAr: String,
    val titleEn: String,
    val descriptionAr: String,
    val descriptionEn: String,
    val objectivesAr: String,
    val objectivesEn: String,
    val suggestedYoutubeUrl: String,
    val verifiedVideoId: String? = null,
    val verificationNote: String = ""
)

data class AiGeneratedQuestionDraft(
    val questionAr: String,
    val questionEn: String,
    val optionsAr: List<String>,
    val optionsEn: List<String>,
    val correctIndex: Int
)

data class AiCourseDraft(
    val titleAr: String,
    val titleEn: String,
    val descriptionAr: String,
    val descriptionEn: String,
    val category: String,
    val lessons: List<AiGeneratedLessonDraft>,
    val questions: List<AiGeneratedQuestionDraft>
)

data class AiCoursePatchDraft(
    val courseId: String,
    val titleAr: String? = null,
    val titleEn: String? = null,
    val descriptionAr: String? = null,
    val descriptionEn: String? = null,
    val priceEgp: Double? = null,
    val discountPercent: Long? = null,
    val paid: Boolean? = null,
    val published: Boolean? = null
)

data class AiLessonAdditionDraft(
    val targetCourseId: String,
    val moduleTitleAr: String,
    val moduleTitleEn: String,
    val titleAr: String,
    val titleEn: String,
    val descriptionAr: String,
    val descriptionEn: String,
    val objectivesAr: String,
    val objectivesEn: String,
    val verifiedVideoId: String? = null,
    val verificationNote: String = ""
)

data class AiAdminUpdatePlan(
    val summaryAr: String,
    val summaryEn: String,
    val coursePatches: List<AiCoursePatchDraft>,
    val newLesson: AiLessonAdditionDraft? = null,
    val updateAnnouncementAr: String? = null,
    val updateAnnouncementEn: String? = null,
    val updateOfferBannerAr: String? = null,
    val updateOfferBannerEn: String? = null,
    val broadcastTitleAr: String? = null,
    val broadcastTitleEn: String? = null,
    val broadcastBodyAr: String? = null,
    val broadcastBodyEn: String? = null
)

class AiCourseBuilderService(
    private val youtubeVerifier: YouTubeVerifier = YouTubeVerifier()
) {
    private val courseSchema = Schema.obj(
        properties = mapOf(
            "titleAr" to Schema.string("Course title in Arabic"),
            "titleEn" to Schema.string("Course title in English"),
            "descriptionAr" to Schema.string("Detailed course description in Arabic"),
            "descriptionEn" to Schema.string("Detailed course description in English"),
            "category" to Schema.string("Short category label such as Technology, Design, Languages, Media, Security"),
            "lessons" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "orderIndex" to Schema.integer("Lesson number starting at 1"),
                        "moduleTitleAr" to Schema.string("Module title in Arabic"),
                        "moduleTitleEn" to Schema.string("Module title in English"),
                        "titleAr" to Schema.string("Lesson title in Arabic"),
                        "titleEn" to Schema.string("Lesson title in English"),
                        "descriptionAr" to Schema.string("Lesson description in Arabic"),
                        "descriptionEn" to Schema.string("Lesson description in English"),
                        "objectivesAr" to Schema.string("Learning objectives in Arabic"),
                        "objectivesEn" to Schema.string("Learning objectives in English"),
                        "suggestedYoutubeUrl" to Schema.string("Real YouTube watch URL if known, or empty string if uncertain")
                    )
                ),
                description = "20 structured lessons ordered from beginner to advanced"
            ),
            "questions" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "questionAr" to Schema.string("Question text in Arabic"),
                        "questionEn" to Schema.string("Question text in English"),
                        "optionsAr" to Schema.array(Schema.string(), "4 options in Arabic"),
                        "optionsEn" to Schema.array(Schema.string(), "4 options in English"),
                        "correctIndex" to Schema.integer("0-based index of the correct option")
                    )
                ),
                description = "8 to 10 multiple-choice exam questions"
            )
        )
    )

    private val updatePlanSchema = Schema.obj(
        properties = mapOf(
            "summaryAr" to Schema.string("Concise Arabic summary of all planned updates"),
            "summaryEn" to Schema.string("Concise English summary of all planned updates"),
            "coursePatches" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "courseId" to Schema.string("Existing course ID to update"),
                        "titleAr" to Schema.string("New Arabic title, or empty string if unchanged"),
                        "titleEn" to Schema.string("New English title, or empty string if unchanged"),
                        "descriptionAr" to Schema.string("New Arabic description, or empty string if unchanged"),
                        "descriptionEn" to Schema.string("New English description, or empty string if unchanged"),
                        "priceEgp" to Schema.double("New price in EGP, or -1 if unchanged"),
                        "discountPercent" to Schema.integer("New discount percent 0..95, or -1 if unchanged"),
                        "paidFlag" to Schema.integer("1 for paid, 0 for free, -1 if unchanged"),
                        "publishedFlag" to Schema.integer("1 for published, 0 for hidden, -1 if unchanged")
                    )
                ),
                description = "List of updates to existing courses (empty if none)"
            ),
            "hasNewLesson" to Schema.boolean("True if adding a new lesson to an existing course"),
            "newLessonCourseId" to Schema.string("Target course ID for the new lesson, or empty string"),
            "newLessonModuleAr" to Schema.string("Module title in Arabic"),
            "newLessonModuleEn" to Schema.string("Module title in English"),
            "newLessonTitleAr" to Schema.string("New lesson title in Arabic"),
            "newLessonTitleEn" to Schema.string("New lesson title in English"),
            "newLessonDescAr" to Schema.string("New lesson description in Arabic"),
            "newLessonDescEn" to Schema.string("New lesson description in English"),
            "newLessonObjAr" to Schema.string("New lesson objectives in Arabic"),
            "newLessonObjEn" to Schema.string("New lesson objectives in English"),
            "newLessonYoutubeUrl" to Schema.string("Real YouTube URL if known, or empty string"),
            "updateAnnouncementAr" to Schema.string("Updated platform announcement in Arabic, or empty string if unchanged"),
            "updateAnnouncementEn" to Schema.string("Updated platform announcement in English, or empty string if unchanged"),
            "updateOfferBannerAr" to Schema.string("Updated offer banner in Arabic, or empty string if unchanged"),
            "updateOfferBannerEn" to Schema.string("Updated offer banner in English, or empty string if unchanged"),
            "broadcastTitleAr" to Schema.string("Notification title in Arabic to send to all students, or empty string if none"),
            "broadcastTitleEn" to Schema.string("Notification title in English to send to all students, or empty string if none"),
            "broadcastBodyAr" to Schema.string("Notification body in Arabic, or empty string if none"),
            "broadcastBodyEn" to Schema.string("Notification body in English, or empty string if none")
        )
    )

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = courseSchema
            }
        )
    }

    private val updatePlannerModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = updatePlanSchema
            }
        )
    }

    suspend fun generateCourseDraft(
        topic: String,
        level: String
    ): Result<AiCourseDraft> {
        return try {
            val prompt = """
                You are the curriculum architect for NEXORA by HEBA NASR.
                Build a complete, practical course draft for topic: "$topic" at level: "$level".
                Requirements:
                1. Provide 20 lessons ordered progressively from beginner to advanced across 4 modules.
                2. Provide rich Arabic and English titles, descriptions, and objectives.
                3. For suggestedYoutubeUrl: ONLY include a YouTube URL if you are confident it is real, otherwise return an empty string "". Never invent fake video IDs.
                4. Provide 8 multiple-choice exam questions (4 options each, both Arabic and English, with correctIndex 0..3).
            """.trimIndent()

            val response = withTimeout(60_000L) {
                model.generateContent(prompt)
            }
            val rawJson = response.text
                ?: return Result.failure(IllegalStateException("Model returned an empty response."))

            val json = JSONObject(rawJson)
            val lessonsJson = json.getJSONArray("lessons")
            val lessonDrafts = ArrayList<AiGeneratedLessonDraft>(lessonsJson.length())

            for (i in 0 until lessonsJson.length()) {
                val obj = lessonsJson.getJSONObject(i)
                val rawUrl = obj.optString("suggestedYoutubeUrl", "").trim()
                // Strict verification rule: AI never publishes unverified links as valid
                var verifiedId: String? = null
                var note = if (rawUrl.isEmpty()) "Needs Admin video attachment" else "Unverified"
                if (rawUrl.isNotEmpty()) {
                    val verify = youtubeVerifier.verifyUrlOrId(rawUrl)
                    if (verify.valid && verify.videoId != null) {
                        verifiedId = verify.videoId
                        note = "Verified: ${verify.title ?: verify.videoId}"
                    } else {
                        note = "Rejected unverified AI link (${verify.error ?: "unavailable"})"
                    }
                }
                lessonDrafts.add(
                    AiGeneratedLessonDraft(
                        orderIndex = obj.optInt("orderIndex", i + 1),
                        moduleTitleAr = obj.optString("moduleTitleAr"),
                        moduleTitleEn = obj.optString("moduleTitleEn"),
                        titleAr = obj.optString("titleAr"),
                        titleEn = obj.optString("titleEn"),
                        descriptionAr = obj.optString("descriptionAr"),
                        descriptionEn = obj.optString("descriptionEn"),
                        objectivesAr = obj.optString("objectivesAr"),
                        objectivesEn = obj.optString("objectivesEn"),
                        suggestedYoutubeUrl = if (verifiedId != null) "https://www.youtube.com/watch?v=$verifiedId" else "",
                        verifiedVideoId = verifiedId,
                        verificationNote = note
                    )
                )
            }

            val questionsJson = json.getJSONArray("questions")
            val questionDrafts = ArrayList<AiGeneratedQuestionDraft>(questionsJson.length())
            for (i in 0 until questionsJson.length()) {
                val obj = questionsJson.getJSONObject(i)
                val oAr = obj.getJSONArray("optionsAr")
                val oEn = obj.getJSONArray("optionsEn")
                questionDrafts.add(
                    AiGeneratedQuestionDraft(
                        questionAr = obj.optString("questionAr"),
                        questionEn = obj.optString("questionEn"),
                        optionsAr = (0 until oAr.length()).map { oAr.getString(it) },
                        optionsEn = (0 until oEn.length()).map { oEn.getString(it) },
                        correctIndex = obj.optInt("correctIndex", 0).coerceIn(0, 3)
                    )
                )
            }

            Result.success(
                AiCourseDraft(
                    titleAr = json.optString("titleAr", topic),
                    titleEn = json.optString("titleEn", topic),
                    descriptionAr = json.optString("descriptionAr"),
                    descriptionEn = json.optString("descriptionEn"),
                    category = json.optString("category", "Technology"),
                    lessons = lessonDrafts,
                    questions = questionDrafts
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI course generation timed out", e)
            Result.failure(IllegalStateException("AI generation timed out after 60 seconds. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI course generation failed", e)
            Result.failure(e)
        }
    }

    suspend fun generateAdminUpdatePlan(
        instruction: String,
        existingCourses: List<com.example.model.Course>,
        currentConfig: com.example.model.PlatformConfig
    ): Result<AiAdminUpdatePlan> {
        return try {
            val catalogSummary = existingCourses.joinToString("\n") { c ->
                "- id=${c.id} | titleAr=${c.titleAr} | titleEn=${c.titleEn} | paid=${c.paid} | priceEgp=${c.priceEgp.toInt()} | discount=${c.discountPercent}% | lessons=${c.lessonCount} | published=${c.published}"
            }
            val prompt = """
                You are the smart platform assistant for NEXORA by HEBA NASR.
                Admin instruction: "$instruction"
                
                Current courses in the platform:
                $catalogSummary
                
                Current platform banners:
                - announcementAr: ${currentConfig.announcementAr}
                - announcementEn: ${currentConfig.announcementEn}
                - activeOfferBannerAr: ${currentConfig.activeOfferBannerAr}
                - activeOfferBannerEn: ${currentConfig.activeOfferBannerEn}
                
                Produce a clean, safe update plan in JSON:
                - Use exact existing courseId values when patching courses.
                - Use empty string "" for text fields that should NOT change, and -1 for numeric/flag fields that should NOT change.
                - If the admin asks to add a lesson to a course, set hasNewLesson=true and fill bilingual titles, descriptions, and objectives. Only put a YouTube URL if you are sure it is real, otherwise "".
                - If the admin asks to notify students or announce a change/offer, populate broadcastTitleAr/En and broadcastBodyAr/En.
                - Keep Arabic and English texts concise and professional.
            """.trimIndent()

            val response = withTimeout(45_000L) {
                updatePlannerModel.generateContent(prompt)
            }
            val rawJson = response.text
                ?: return Result.failure(IllegalStateException("AI returned an empty plan."))

            val json = JSONObject(rawJson)
            val validCourseIds = existingCourses.map { it.id }.toSet()
            val patchesJson = json.optJSONArray("coursePatches")
            val patches = mutableListOf<AiCoursePatchDraft>()
            if (patchesJson != null) {
                for (i in 0 until patchesJson.length()) {
                    val p = patchesJson.getJSONObject(i)
                    val cid = p.optString("courseId", "").trim()
                    if (cid !in validCourseIds) continue
                    val rawPrice = p.optDouble("priceEgp", -1.0)
                    val rawDiscount = p.optLong("discountPercent", -1L)
                    val paidFlag = p.optInt("paidFlag", -1)
                    val pubFlag = p.optInt("publishedFlag", -1)
                    patches.add(
                        AiCoursePatchDraft(
                            courseId = cid,
                            titleAr = p.optString("titleAr").trim().takeIf { it.isNotEmpty() },
                            titleEn = p.optString("titleEn").trim().takeIf { it.isNotEmpty() },
                            descriptionAr = p.optString("descriptionAr").trim().takeIf { it.isNotEmpty() },
                            descriptionEn = p.optString("descriptionEn").trim().takeIf { it.isNotEmpty() },
                            priceEgp = if (rawPrice >= 0.0) rawPrice.coerceAtMost(100_000.0) else null,
                            discountPercent = if (rawDiscount >= 0L) rawDiscount.coerceIn(0L, 95L) else null,
                            paid = when (paidFlag) { 1 -> true; 0 -> false; else -> null },
                            published = when (pubFlag) { 1 -> true; 0 -> false; else -> null }
                        )
                    )
                }
            }

            val hasNewLesson = json.optBoolean("hasNewLesson", false)
            val newLessonCourseId = json.optString("newLessonCourseId", "").trim()
            val newLesson = if (hasNewLesson && newLessonCourseId in validCourseIds) {
                val ytRaw = json.optString("newLessonYoutubeUrl", "").trim()
                var verifiedId: String? = null
                var note = "Pending video link"
                if (ytRaw.isNotEmpty()) {
                    val verify = youtubeVerifier.verifyUrlOrId(ytRaw)
                    if (verify.valid && verify.videoId != null) {
                        verifiedId = verify.videoId
                        note = "Verified: ${verify.title ?: verify.videoId}"
                    } else {
                        note = "Rejected unverified AI link"
                    }
                }
                AiLessonAdditionDraft(
                    targetCourseId = newLessonCourseId,
                    moduleTitleAr = json.optString("newLessonModuleAr").ifBlank { "إضافة حديثة" },
                    moduleTitleEn = json.optString("newLessonModuleEn").ifBlank { "New Addition" },
                    titleAr = json.optString("newLessonTitleAr").ifBlank { "درس إضافي" },
                    titleEn = json.optString("newLessonTitleEn").ifBlank { "Bonus Lesson" },
                    descriptionAr = json.optString("newLessonDescAr").ifBlank { "محتوى مضاف حديثًا عبر الإدارة." },
                    descriptionEn = json.optString("newLessonDescEn").ifBlank { "Newly added curriculum module." },
                    objectivesAr = json.optString("newLessonObjAr"),
                    objectivesEn = json.optString("newLessonObjEn"),
                    verifiedVideoId = verifiedId,
                    verificationNote = note
                )
            } else null

            Result.success(
                AiAdminUpdatePlan(
                    summaryAr = json.optString("summaryAr").ifBlank { "خطة تحديث بالذكاء الاصطناعي" },
                    summaryEn = json.optString("summaryEn").ifBlank { "AI Platform Update Plan" },
                    coursePatches = patches,
                    newLesson = newLesson,
                    updateAnnouncementAr = json.optString("updateAnnouncementAr").trim().takeIf { it.isNotEmpty() },
                    updateAnnouncementEn = json.optString("updateAnnouncementEn").trim().takeIf { it.isNotEmpty() },
                    updateOfferBannerAr = json.optString("updateOfferBannerAr").trim().takeIf { it.isNotEmpty() },
                    updateOfferBannerEn = json.optString("updateOfferBannerEn").trim().takeIf { it.isNotEmpty() },
                    broadcastTitleAr = json.optString("broadcastTitleAr").trim().takeIf { it.isNotEmpty() },
                    broadcastTitleEn = json.optString("broadcastTitleEn").trim().takeIf { it.isNotEmpty() },
                    broadcastBodyAr = json.optString("broadcastBodyAr").trim().takeIf { it.isNotEmpty() },
                    broadcastBodyEn = json.optString("broadcastBodyEn").trim().takeIf { it.isNotEmpty() }
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI update planner timed out", e)
            Result.failure(IllegalStateException("AI planning timed out. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI update planner failed", e)
            Result.failure(e)
        }
    }

    private companion object {
        const val TAG = "AiCourseBuilder"
    }
}
