package com.example.data

import android.content.Context
import com.example.R
import com.example.core.SecurityUtils
import com.example.model.*
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NexoraRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    companion object {
        const val BOOTSTRAP_ADMIN_EMAIL = "heba55nasr@gmail.com"
    }

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    suspend fun checkIsAdmin(user: FirebaseUser?): Boolean {
        if (user == null) return false
        return user.email.equals(BOOTSTRAP_ADMIN_EMAIL, ignoreCase = true) && user.isEmailVerified
    }

    // Ensure user profile exists; never overwrites existing student edits or role
    suspend fun ensureOrCreateProfile(
        fullName: String,
        preferredLang: String,
        firstName: String = "",
        fatherName: String = "",
        familyName: String = ""
    ): Result<UserProfile> {
        val user = auth.currentUser ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "users/${user.uid}"
        return try {
            val docRef = db.collection("users").document(user.uid)
            val snap = docRef.get().await()
            if (snap.exists()) {
                val existing = snap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    ?: UserProfile(userId = user.uid, fullName = fullName, email = user.email.orEmpty())
                Result.success(existing)
            } else {
                val split = if (firstName.isBlank() && fatherName.isBlank() && familyName.isBlank()) {
                    SecurityUtils.splitTripleName(fullName)
                } else {
                    Triple(firstName.trim(), fatherName.trim(), familyName.trim())
                }
                val combined = SecurityUtils.composeTripleName(split.first, split.second, split.third)
                    .ifBlank { fullName.trim() }
                require(SecurityUtils.isTripleName(combined)) {
                    "يرجى إدخال الاسم الثلاثي كاملًا (الاسم الأول، اسم الأب، اسم العائلة)"
                }
                val profile = UserProfile(
                    userId = user.uid,
                    firstName = split.first,
                    fatherName = split.second,
                    familyName = split.third,
                    fullName = combined,
                    email = user.email.orEmpty(),
                    photoUrl = user.photoUrl?.toString(),
                    preferredLang = if (preferredLang in listOf("ar", "en")) preferredLang else "ar",
                    accountStatus = "ACTIVE",
                    role = "STUDENT",
                    subscriptionPlan = "NONE"
                )
                docRef.set(profile.toCreateMap()).await()
                Result.success(profile.copy(id = user.uid))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun updateProfile(
        fullName: String,
        preferredLang: String,
        firstName: String = "",
        fatherName: String = "",
        familyName: String = ""
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "users/$uid"
        return try {
            val split = if (firstName.isBlank() && fatherName.isBlank() && familyName.isBlank()) {
                SecurityUtils.splitTripleName(fullName)
            } else {
                Triple(firstName.trim(), fatherName.trim(), familyName.trim())
            }
            val combined = SecurityUtils.composeTripleName(split.first, split.second, split.third)
                .ifBlank { fullName.trim() }
            require(SecurityUtils.isTripleName(combined)) {
                "يرجى كتابة الاسم الثلاثي كاملًا (الاسم الأول، اسم الأب، اسم العائلة)"
            }
            val docRef = db.collection("users").document(uid)
            if (!docRef.get().await().exists()) {
                return ensureOrCreateProfile(
                    fullName = combined,
                    preferredLang = preferredLang,
                    firstName = split.first,
                    fatherName = split.second,
                    familyName = split.third
                ).map { Unit }
            }
            docRef.update(
                mapOf(
                    "firstName" to split.first.take(40),
                    "fatherName" to split.second.take(40),
                    "familyName" to split.third.take(40),
                    "fullName" to combined.take(120),
                    "preferredLang" to preferredLang,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> =
        db.collection("users").document(userId)
            .snapshots()
            .map { it.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }

    // Courses stream: students strictly query whereEqualTo("published", true) to align with rules
    fun observeCourses(isAdmin: Boolean): Flow<List<Course>> = flow {
        val query: Query = if (isAdmin) {
            db.collection("courses")
        } else {
            db.collection("courses").whereEqualTo("published", true)
        }
        val path = "courses"
        emitAll(
            query.snapshots().map { snap ->
                val remote = snap.toObjects(Course::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                val list = if (remote.isEmpty()) CourseSeedCourses.courses else remote
                list.sortedBy { it.sortOrder }
            }.catch { err ->
                val fsErr = generateSequence(err) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr == null && err is CancellationException) throw err
                handleFirestoreError(fsErr ?: err, OperationType.LIST, path)
                throw err
            }
        )
    }

    fun observeLessons(courseId: String, isAdmin: Boolean): Flow<List<Lesson>> = flow {
        val base = db.collection("courses").document(courseId).collection("lessons")
        val query: Query = if (isAdmin) base else base.whereEqualTo("published", true)
        emitAll(
            query.snapshots().map { snap ->
                val remote = snap.toObjects(Lesson::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                val list = if (remote.isEmpty()) CourseSeedCourses.buildLessonsForCourse(courseId) else remote
                list.sortedBy { it.orderIndex }
            }
        )
    }

    fun observeQuestions(courseId: String): Flow<List<ExamQuestion>> =
        db.collection("courses").document(courseId).collection("questions")
            .snapshots()
            .map { snap ->
                val remote = snap.toObjects(ExamQuestion::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                val list = if (remote.isEmpty()) CourseSeedExams.buildQuestionsForCourse(courseId).first else remote
                list.sortedBy { it.orderIndex }
            }

    fun observeEnrollments(userId: String): Flow<List<Enrollment>> =
        db.collection("users").document(userId).collection("enrollments")
            .snapshots()
            .map { it.toObjects(Enrollment::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }

    fun observeProgress(userId: String): Flow<List<LessonProgress>> =
        db.collection("users").document(userId).collection("progress")
            .snapshots()
            .map { it.toObjects(LessonProgress::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }

    fun observeExamAttempts(userId: String): Flow<List<ExamAttempt>> =
        db.collection("users").document(userId).collection("exam_attempts")
            .snapshots()
            .map { snap ->
                snap.toObjects(ExamAttempt::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }

    fun observeStudentPayments(userId: String): Flow<List<PaymentRequest>> =
        db.collection("payments")
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(PaymentRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }

    fun observeAllPaymentsAdmin(): Flow<List<PaymentRequest>> =
        db.collection("payments")
            .snapshots()
            .map { snap ->
                snap.toObjects(PaymentRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }

    fun observeStudentCertificates(userId: String): Flow<List<Certificate>> =
        db.collection("certificates")
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(Certificate::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }

    fun observeAllCertificatesAdmin(): Flow<List<Certificate>> =
        db.collection("certificates")
            .snapshots()
            .map { snap ->
                snap.toObjects(Certificate::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }

    fun observeNotifications(userId: String): Flow<List<StudentNotification>> =
        db.collection("users").document(userId).collection("notifications")
            .snapshots()
            .map { snap ->
                snap.toObjects(StudentNotification::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }

    fun observePlatformConfig(): Flow<PlatformConfig> =
        db.collection("platform_config").document("main")
            .snapshots()
            .map { snap ->
                snap.toObject(PlatformConfig::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    ?: PlatformConfig()
            }

    fun observeAllUsersAdmin(): Flow<List<UserProfile>> =
        db.collection("users")
            .snapshots()
            .map { it.toObjects(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }

    fun observeStudentTickets(userId: String): Flow<List<SupportTicket>> =
        db.collection("support_tickets")
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(SupportTicket::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }

    fun observeAllTicketsAdmin(): Flow<List<SupportTicket>> =
        db.collection("support_tickets")
            .snapshots()
            .map { snap ->
                snap.toObjects(SupportTicket::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }

    fun observePromoCodesAdmin(): Flow<List<PromoCode>> =
        db.collection("promo_codes")
            .snapshots()
            .map { it.toObjects(PromoCode::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }

    // Non-destructive initial catalog sync (creates ONLY documents that do not exist yet!)
    suspend fun seedInitialCatalogIfNeeded(): Result<Unit> {
        return try {
            val configRef = db.collection("platform_config").document("main")
            if (!configRef.get().await().exists()) {
                configRef.set(
                    mapOf(
                        "wePayNumber" to "01557701433",
                        "announcementAr" to "أهلًا بكم في منصة NEXORA by HEBA NASR — تعلم اليوم لتقود الغد.",
                        "announcementEn" to "Welcome to NEXORA by HEBA NASR — Learn Today. Lead Tomorrow.",
                        "activeOfferBannerAr" to "خصومات خاصة على مسارات البرمجة والأمن السيبراني",
                        "activeOfferBannerEn" to "Special offers on Programming & Cybersecurity tracks",
                        "supportEmail" to BOOTSTRAP_ADMIN_EMAIL,
                        "accentPreset" to "MAUVE_MATTE",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            val legacySeedPrices = mapOf(
                "programming" to listOf(750.0),
                "digital_art" to listOf(650.0),
                "video_editing" to listOf(700.0),
                "voice_over" to listOf(550.0),
                "cybersecurity" to listOf(900.0, 200.0)
            )
            for (course in CourseSeedCourses.courses) {
                val courseRef = db.collection("courses").document(course.id)
                val existingSnap = courseRef.get().await()
                if (!existingSnap.exists()) {
                    courseRef.set(course.toCreateMap()).await()
                } else {
                    val currentPrice = existingSnap.getDouble("priceEgp")
                    val legacyPrices = legacySeedPrices[course.id].orEmpty()
                    if (currentPrice != null && currentPrice in legacyPrices) {
                        courseRef.update(
                            mapOf(
                                "priceEgp" to course.priceEgp,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        ).await()
                    }
                }
                val seededLessons = CourseSeedCourses.buildLessonsForCourse(course.id)
                val existingLessonsSnap = courseRef.collection("lessons").get().await()
                if (existingLessonsSnap.isEmpty) {
                    val batch = db.batch()
                    seededLessons.forEach { lesson ->
                        batch.set(courseRef.collection("lessons").document(lesson.id), lesson.toCreateMap())
                        batch.set(courseRef.collection("lesson_videos").document(lesson.id), lesson.toVideoPayloadMap())
                    }
                    batch.commit().await()
                } else {
                    // Non-destructively fill any previously placeholder lessons and ensure protected lesson_videos exist
                    val seedById = seededLessons.associateBy { it.id }
                    val existingVideosSnap = runCatching { courseRef.collection("lesson_videos").get().await() }.getOrNull()
                    val existingVideoIds = existingVideosSnap?.documents?.map { it.id }?.toSet().orEmpty()
                    val upgradeBatch = db.batch()
                    var upgradeCount = 0
                    for (doc in existingLessonsSnap.documents) {
                        val seedLesson = seedById[doc.id]
                        val status = doc.getString("videoStatus").orEmpty()
                        val hasAr = !doc.getString("youtubeIdAr").isNullOrBlank()
                        val hasEn = !doc.getString("youtubeIdEn").isNullOrBlank()
                        if (seedLesson != null && status == "NEEDS_CONTENT" && !hasAr && !hasEn) {
                            val patch = mutableMapOf<String, Any>(
                                "videoStatus" to seedLesson.videoStatus,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                            seedLesson.youtubeIdAr?.takeIf { it.isNotBlank() }?.let { patch["youtubeIdAr"] = it }
                            seedLesson.youtubeIdEn?.takeIf { it.isNotBlank() }?.let { patch["youtubeIdEn"] = it }
                            upgradeBatch.update(doc.reference, patch)
                            upgradeCount++
                        }
                        if (doc.id !in existingVideoIds) {
                            val ytAr = doc.getString("youtubeIdAr")?.takeIf { it.isNotBlank() } ?: seedLesson?.youtubeIdAr
                            val ytEn = doc.getString("youtubeIdEn")?.takeIf { it.isNotBlank() } ?: seedLesson?.youtubeIdEn
                            val freePrev = doc.getBoolean("freePreview") ?: false
                            val vStatus = if (!ytAr.isNullOrBlank() || !ytEn.isNullOrBlank()) "READY" else "NEEDS_CONTENT"
                            upgradeBatch.set(
                                courseRef.collection("lesson_videos").document(doc.id),
                                mapOf(
                                    "courseId" to course.id,
                                    "lessonId" to doc.id,
                                    "youtubeIdAr" to ytAr,
                                    "youtubeIdEn" to ytEn,
                                    "freePreview" to freePrev,
                                    "videoStatus" to vStatus,
                                    "published" to (doc.getBoolean("published") ?: true),
                                    "updatedAt" to FieldValue.serverTimestamp()
                                ).filterValues { it != null }
                            )
                            upgradeCount++
                        }
                    }
                    if (upgradeCount > 0) {
                        upgradeBatch.commit().await()
                    }
                }
                val questionsSnap = courseRef.collection("questions").limit(1).get().await()
                if (questionsSnap.isEmpty) {
                    val (questions, keys) = CourseSeedExams.buildQuestionsForCourse(course.id)
                    val batch = db.batch()
                    questions.forEach { q ->
                        batch.set(courseRef.collection("questions").document(q.id), q.toCreateMap())
                    }
                    keys.forEach { (qId, correctIdx) ->
                        batch.set(
                            courseRef.collection("admin_keys").document(qId),
                            mapOf(
                                "courseId" to course.id,
                                "questionId" to qId,
                                "correctIndex" to correctIdx,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                    }
                    batch.commit().await()
                }
            }

            seedDefaultPromoCodesIfNeeded()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "courses")
            Result.failure(e)
        }
    }

    suspend fun enrollFreeCourse(courseId: String): Result<Unit> {
        val uid = try { requireUserId() } catch (e: Exception) { return Result.failure(e) }
        val path = "users/$uid/enrollments/$courseId"
        return try {
            db.collection("users").document(uid).collection("enrollments").document(courseId).set(
                mapOf(
                    "userId" to uid,
                    "courseId" to courseId,
                    "accessType" to "FREE",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleLessonComplete(courseId: String, lessonId: String, completed: Boolean): Result<Unit> {
        val uid = try { requireUserId() } catch (e: Exception) { return Result.failure(e) }
        val path = "users/$uid/progress/$lessonId"
        return try {
            val docRef = db.collection("users").document(uid).collection("progress").document(lessonId)
            val snap = docRef.get().await()
            if (snap.exists()) {
                docRef.update(
                    mapOf(
                        "completed" to completed,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "courseId" to courseId,
                        "lessonId" to lessonId,
                        "completed" to completed,
                        "watchedSeconds" to 0L,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun validatePromoCode(codeInput: String): Result<PromoCode?> {
        val clean = codeInput.trim().uppercase(Locale.US)
        if (clean.isEmpty()) return Result.success(null)
        return try {
            val snap = db.collection("promo_codes").document(clean).get().await()
            val promo = snap.toObject(PromoCode::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            if (promo != null && promo.active) Result.success(promo) else Result.success(null)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, "promo_codes/$clean")
            Result.failure(e)
        }
    }

    suspend fun verifyLessonVideoAccess(course: Course, lesson: Lesson): Result<Lesson> {
        val uid = try { requireUserId() } catch (e: Exception) { return Result.failure(e) }
        val videoPath = "courses/${course.id}/lesson_videos/${lesson.id}"
        val paidBlockedMsg = "هذا الكورس مدفوع. لمشاهدة الفيديوهات والدروس، يرجى تحويل رسوم الكورس أولاً."
        return try {
            val videoSnap = runCatching {
                db.collection("courses").document(course.id)
                    .collection("lesson_videos").document(lesson.id).get().await()
            }.getOrElse { err ->
                val fsErr = generateSequence(err) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                    handleFirestoreError(fsErr, OperationType.GET, videoPath)
                    return Result.failure(IllegalStateException(paidBlockedMsg))
                }
                null
            }
            if (videoSnap != null && videoSnap.exists()) {
                val payload = videoSnap.toObject(LessonVideoPayload::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                if (payload != null) {
                    return Result.success(
                        lesson.copy(
                            youtubeIdAr = payload.youtubeIdAr ?: lesson.youtubeIdAr,
                            youtubeIdEn = payload.youtubeIdEn ?: lesson.youtubeIdEn,
                            freePreview = payload.freePreview,
                            videoStatus = payload.videoStatus
                        )
                    )
                }
            }
            // Authoritative backend verification against course document, enrollment, or annual plan
            val authoritativeCourseSnap = runCatching {
                db.collection("courses").document(course.id).get().await()
            }.getOrNull()
            val authoritativePaid = authoritativeCourseSnap?.getBoolean("paid") ?: course.paid
            val authoritativePreview = runCatching {
                db.collection("courses").document(course.id)
                    .collection("lessons").document(lesson.id).get().await()
                    .getBoolean("freePreview")
            }.getOrNull() ?: lesson.freePreview

            if (!authoritativePaid || authoritativePreview || auth.currentUser?.email.equals(BOOTSTRAP_ADMIN_EMAIL, true)) {
                return Result.success(lesson)
            }
            val enrolled = db.collection("users").document(uid)
                .collection("enrollments").document(course.id).get().await().exists()
            if (enrolled) return Result.success(lesson)
            val userDoc = db.collection("users").document(uid).get().await()
            val annual = userDoc.getString("subscriptionPlan") == "ANNUAL"
            if (annual) return Result.success(lesson)
            Result.failure(IllegalStateException(paidBlockedMsg))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, videoPath)
            Result.failure(e)
        }
    }

    suspend fun submitWePayPayment(
        studentName: String,
        studentEmail: String,
        course: Course,
        promoCode: String?,
        targetLessonId: String?,
        paymentMethod: String,
        wePayNumber: String,
        senderPhone: String,
        transactionRef: String,
        proofBase64: String?
    ): Result<String> {
        val uid = try { requireUserId() } catch (e: Exception) { return Result.failure(e) }
        val cleanName = studentName.trim().take(120)
        val cleanPhone = senderPhone.trim()
        val cleanRef = transactionRef.trim()
        if (!SecurityUtils.isTripleName(cleanName)) {
            return Result.failure(IllegalArgumentException("يرجى كتابة الاسم الثلاثي كاملًا ليظهر في الشهادة"))
        }
        if (cleanPhone.length < 6) {
            return Result.failure(IllegalArgumentException("يرجى إدخال رقم الهاتف المُحوّل منه بشكل صحيح"))
        }
        if (cleanRef.length < 2) {
            return Result.failure(IllegalArgumentException("يرجى إدخال رقم العملية / المرجع"))
        }
        if (!course.paid) {
            return Result.failure(IllegalArgumentException("هذا الكورس مجاني بالكامل ولا يتطلب دفعًا."))
        }
        val payId = SecurityUtils.generateDocId("pay")
        val path = "payments/$payId"
        return try {
            val userRef = db.collection("users").document(uid)
            val alreadyEnrolled = runCatching {
                userRef.collection("enrollments").document(course.id).get().await().exists()
            }.getOrDefault(false)
            if (alreadyEnrolled) {
                return Result.failure(IllegalStateException("أنت مسجل بالفعل في هذا الكورس."))
            }
            val existingPayments = runCatching {
                db.collection("payments")
                    .whereEqualTo("userId", uid)
                    .get().await()
            }.getOrNull()
            val hasOpenOrApproved = existingPayments?.documents?.any { doc ->
                doc.getString("courseId") == course.id &&
                    doc.getString("status") in listOf("PENDING", "APPROVED")
            } == true
            if (hasOpenOrApproved) {
                return Result.failure(IllegalStateException("يوجد طلب دفع قيد المراجعة أو معتمد بالفعل لهذا الكورس."))
            }

            // Recompute authoritative course price on backend record rather than trusting frontend amount
            val courseSnap = runCatching { db.collection("courses").document(course.id).get().await() }.getOrNull()
            val serverPrice = courseSnap?.getDouble("priceEgp") ?: course.priceEgp
            val serverDiscount = courseSnap?.getLong("discountPercent") ?: course.discountPercent
            val baseAmount = serverPrice * (100.0 - serverDiscount.coerceIn(0, 100)) / 100.0

            val cleanPromo = promoCode?.trim()?.uppercase(Locale.US)?.takeIf { it.isNotEmpty() }
            val verifiedPromo = cleanPromo?.let { code ->
                validatePromoCode(code).getOrNull()
            }
            val authoritativeAmount = if (verifiedPromo != null) {
                (baseAmount * (100.0 - verifiedPromo.discountPercent) / 100.0).coerceAtLeast(0.0)
            } else baseAmount

            val payload = PaymentRequest(
                userId = uid,
                studentName = cleanName,
                studentEmail = studentEmail,
                courseId = course.id,
                courseTitle = course.titleEn,
                amountEgp = authoritativeAmount,
                originalPriceEgp = serverPrice,
                promoCode = verifiedPromo?.code,
                targetLessonId = targetLessonId?.takeIf { it.isNotBlank() },
                paymentMethod = paymentMethod.trim().ifBlank { "WE Pay" }.take(60),
                transferNumber = wePayNumber.trim().ifBlank { "01557701433" },
                senderPhone = cleanPhone,
                transactionRef = cleanRef,
                proofImageBase64 = proofBase64?.takeIf { it.isNotBlank() },
                status = "PENDING"
            )

            val batch = db.batch()
            // 1. Create PENDING payment request (never auto-unlocks course until verified)
            batch.set(db.collection("payments").document(payId), payload.toCreateMap())
            // 2. Keep user's triple name updated cleanly if profile exists
            val userExists = runCatching { userRef.get().await().exists() }.getOrDefault(false)
            if (userExists) {
                val split = SecurityUtils.splitTripleName(cleanName)
                batch.update(
                    userRef,
                    mapOf(
                        "firstName" to split.first.take(40),
                        "fatherName" to split.second.take(40),
                        "familyName" to split.third.take(40),
                        "fullName" to cleanName,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            // 3. Pending confirmation notification
            val notifId = SecurityUtils.generateDocId("notif")
            batch.set(
                userRef.collection("notifications").document(notifId),
                mapOf(
                    "userId" to uid,
                    "titleAr" to "تم استلام طلب الدفع — قيد التحقق",
                    "titleEn" to "Payment Submitted — Pending Verification",
                    "bodyAr" to "تم تسجيل طلب الدفع لكورس ${course.titleAr} بمبلغ ${authoritativeAmount.toInt()} ج.م (مرجع: $cleanRef). سيتم فتح الكورس تلقائيًا فور التحقق من الدفع.",
                    "bodyEn" to "Payment request for ${course.titleEn} (${authoritativeAmount.toInt()} EGP, Ref: $cleanRef) is Pending. The course unlocks automatically once verified.",
                    "type" to "PAYMENT_PENDING",
                    "read" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(payId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    // Admin payment verification (PENDING -> APPROVED/REJECTED); auto-enrolls ONLY upon approval
    suspend fun reviewPayment(payment: PaymentRequest, approve: Boolean, adminNote: String): Result<Unit> {
        val adminUid = try { requireUserId() } catch (e: Exception) { return Result.failure(e) }
        val path = "payments/${payment.id}"
        return try {
            val payRef = db.collection("payments").document(payment.id)
            val currentPaySnap = payRef.get().await()
            val currentStatus = currentPaySnap.getString("status")
            if (approve && currentStatus == "APPROVED") {
                return Result.failure(IllegalStateException("تم توثيق هذا الدفع مسبقًا ومنع التكرار."))
            }

            val enrollRef = db.collection("users").document(payment.userId)
                .collection("enrollments").document(payment.courseId)
            val existingEnroll = runCatching { enrollRef.get().await() }.getOrNull()

            val batch = db.batch()
            batch.update(
                payRef,
                mapOf(
                    "status" to if (approve) "APPROVED" else "REJECTED",
                    "adminNote" to adminNote.ifBlank { if (approve) "Verified & Approved by Admin" else "Payment verification failed" },
                    "reviewedBy" to adminUid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            if (approve && (existingEnroll == null || !existingEnroll.exists())) {
                batch.set(
                    enrollRef,
                    mapOf(
                        "userId" to payment.userId,
                        "courseId" to payment.courseId,
                        "accessType" to "PAID_APPROVED",
                        "paymentId" to payment.id,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else if (!approve && existingEnroll != null && existingEnroll.exists() &&
                existingEnroll.getString("paymentId") == payment.id
            ) {
                batch.delete(enrollRef)
            }
            val notifId = SecurityUtils.generateDocId("notif")
            val notifRef = db.collection("users").document(payment.userId)
                .collection("notifications").document(notifId)
            batch.set(
                notifRef,
                mapOf(
                    "userId" to payment.userId,
                    "titleAr" to if (approve) "تم توثيق الدفع وتفعيل الكورس" else "تم رفض طلب الدفع",
                    "titleEn" to if (approve) "Payment Verified & Course Unlocked" else "Payment Request Rejected",
                    "bodyAr" to if (approve) "تم التحقق من الدفع وتفعيل كورس ${payment.courseTitle} بنجاح. يمكنك متابعة دروسك الآن." else "تم رفض طلب دفع ${payment.courseTitle}: ${adminNote.ifBlank { "يرجى مراجعة بيانات التحويل" }}",
                    "bodyEn" to if (approve) "Your payment was verified and ${payment.courseTitle} is now unlocked!" else "Payment for ${payment.courseTitle} was rejected: $adminNote",
                    "type" to if (approve) "PAYMENT_APPROVED" else "PAYMENT_REJECTED",
                    "read" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun submitExamAttempt(
        course: Course,
        questions: List<ExamQuestion>,
        selectedIndices: Map<String, Int>
    ): Result<ExamAttempt> {
        val uid = try { requireUserId() } catch (e: Exception) { return Result.failure(e) }
        val attemptId = SecurityUtils.generateDocId("att")
        val path = "users/$uid/exam_attempts/$attemptId"
        return try {
            // Backend authorization check before allowing exam submission
            val userRef = db.collection("users").document(uid)
            val isAuthorizedAdmin = auth.currentUser?.email.equals(BOOTSTRAP_ADMIN_EMAIL, true)
            if (course.paid && !isAuthorizedAdmin) {
                val enrolled = userRef.collection("enrollments").document(course.id).get().await().exists()
                val annual = userRef.get().await().getString("subscriptionPlan") == "ANNUAL"
                if (!enrolled && !annual) {
                    return Result.failure(IllegalStateException("يجب تفعيل الاشتراك في الكورس أولًا قبل دخول الامتحان."))
                }
            }
            var correct = 0
            for (question in questions) {
                val chosen = selectedIndices[question.id] ?: -1
                if (chosen >= 0 && SecurityUtils.hashExamAnswer(course.id, question.id, chosen) == question.answerHash) {
                    correct++
                }
            }
            val total = questions.size.coerceAtLeast(1)
            val percent = ((correct * 100.0) / total).toInt().coerceIn(0, 100)
            val passed = percent >= course.passingScore

            userRef.collection("exam_attempts").document(attemptId).set(
                mapOf(
                    "userId" to uid,
                    "courseId" to course.id,
                    "courseTitle" to course.titleEn,
                    "scorePercent" to percent.toLong(),
                    "correctCount" to correct.toLong(),
                    "totalQuestions" to total.toLong(),
                    "passed" to passed,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()

            Result.success(
                ExamAttempt(
                    id = attemptId,
                    userId = uid,
                    courseId = course.id,
                    courseTitle = course.titleEn,
                    scorePercent = percent.toLong(),
                    correctCount = correct.toLong(),
                    totalQuestions = total.toLong(),
                    passed = passed
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun issueCertificate(
        course: Course,
        scorePercent: Long
    ): Result<Certificate> {
        val uid = try { requireUserId() } catch (e: Exception) { return Result.failure(e) }
        if (scorePercent < course.passingScore) {
            return Result.failure(IllegalStateException("Minimum passing score of ${course.passingScore}% is required."))
        }
        val path = "certificates"
        return try {
            // Retrieve verified student full name directly from database profile (never from email or placeholder)
            val userRef = db.collection("users").document(uid)
            val userSnap = userRef.get().await()
            val profile = userSnap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("يرجى استكمال ملفك الشخصي بالاسم الثلاثي أولًا."))
            val dbFullName = profile.fullName.trim()
            if (!SecurityUtils.isTripleName(dbFullName)) {
                return Result.failure(IllegalStateException("يجب إدخال الاسم الثلاثي كاملًا في ملفك الشخصي قبل إصدار الشهادة."))
            }

            // Verify enrollment / course access
            val isAuthorizedAdmin = auth.currentUser?.email.equals(BOOTSTRAP_ADMIN_EMAIL, true)
            if (course.paid && !isAuthorizedAdmin) {
                val enrolled = userRef.collection("enrollments").document(course.id).get().await().exists()
                val annual = profile.hasActiveAnnualSubscription()
                if (!enrolled && !annual) {
                    return Result.failure(IllegalStateException("لا يمكن إصدار شهادة لكورس مدفوع غير مُفعّل."))
                }
            }

            // Verify all required lessons are completed before issuing certificate
            if (!isAuthorizedAdmin) {
                val lessonsSnap = db.collection("courses").document(course.id)
                    .collection("lessons").whereEqualTo("published", true).get().await()
                val requiredLessonIds = if (lessonsSnap.isEmpty) {
                    CourseSeedCourses.buildLessonsForCourse(course.id).map { it.id }.toSet()
                } else {
                    lessonsSnap.documents.map { it.id }.toSet()
                }
                val progressSnap = userRef.collection("progress").get().await()
                val completedIds = progressSnap.documents
                    .filter { it.getString("courseId") == course.id && it.getBoolean("completed") == true }
                    .map { it.getString("lessonId") ?: it.id }
                    .toSet()
                if (requiredLessonIds.isNotEmpty() && !completedIds.containsAll(requiredLessonIds)) {
                    return Result.failure(IllegalStateException("يجب إكمال جميع دروس الكورس (${completedIds.size}/${requiredLessonIds.size}) قبل إصدار الشهادة."))
                }
            }

            // Return existing non-revoked certificate if already issued for this student & course (preserves original date & code)
            val existingCerts = db.collection("certificates").whereEqualTo("userId", uid).get().await()
            val alreadyIssued = existingCerts.toObjects(Certificate::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .firstOrNull { it.courseId == course.id && !it.revoked }
            if (alreadyIssued != null) {
                return Result.success(alreadyIssued)
            }

            // Obtain authoritative server timestamp converted to Egypt timezone (Africa/Cairo)
            userRef.update(mapOf("updatedAt" to FieldValue.serverTimestamp())).await()
            val serverDate = runCatching {
                userRef.get(com.google.firebase.firestore.Source.SERVER).await()
                    .getTimestamp("updatedAt")?.toDate()
            }.getOrNull() ?: userSnap.getTimestamp("updatedAt")?.toDate() ?: Date()
            val egyptYear = SecurityUtils.currentEgyptYear(serverDate)
            val dateLabel = SecurityUtils.formatEgyptDate(serverDate)

            val issuedCert = db.runTransaction { tx ->
                val counterRef = db.collection("certificate_counters").document(egyptYear.toString())
                val counterSnap = tx.get(counterRef)
                val counterExists = counterSnap.exists()
                val nextSeq = if (counterExists) {
                    (counterSnap.getLong("lastSeq") ?: 0L) + 1L
                } else {
                    1L
                }
                val code = SecurityUtils.formatSequentialCertificateCode(egyptYear, nextSeq)
                val certRef = db.collection("certificates").document(code)
                val existingAtCode = tx.get(certRef)
                if (existingAtCode.exists()) {
                    throw IllegalStateException("Certificate sequence collision for $code; retrying transaction.")
                }

                val counterPayload = mapOf(
                    "year" to egyptYear.toLong(),
                    "lastSeq" to nextSeq,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (counterExists) {
                    tx.update(counterRef, counterPayload)
                } else {
                    tx.set(counterRef, counterPayload)
                }

                tx.set(
                    certRef,
                    mapOf(
                        "userId" to uid,
                        "courseId" to course.id,
                        "studentName" to dbFullName,
                        "courseTitleAr" to course.titleAr,
                        "courseTitleEn" to course.titleEn,
                        "certificateCode" to code,
                        "scorePercent" to scorePercent,
                        "issuedDateLabel" to dateLabel,
                        "issuerName" to "NEXORA by HEBA NASR",
                        "revoked" to false,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )

                val notifId = SecurityUtils.generateDocId("notif")
                val notifRef = userRef.collection("notifications").document(notifId)
                tx.set(
                    notifRef,
                    mapOf(
                        "userId" to uid,
                        "titleAr" to "تم إصدار شهادتك الجديدة",
                        "titleEn" to "Certificate Issued",
                        "bodyAr" to "تهانينا $dbFullName! تم إصدار شهادة ${course.titleAr} برقم $code.",
                        "bodyEn" to "Congratulations $dbFullName! Your certificate for ${course.titleEn} ($code) is ready.",
                        "type" to "CERTIFICATE_ISSUED",
                        "read" to false,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )

                Certificate(
                    id = code,
                    userId = uid,
                    courseId = course.id,
                    studentName = dbFullName,
                    courseTitleAr = course.titleAr,
                    courseTitleEn = course.titleEn,
                    certificateCode = code,
                    scorePercent = scorePercent,
                    issuedDateLabel = dateLabel,
                    issuerName = "NEXORA by HEBA NASR",
                    revoked = false
                )
            }.await()

            Result.success(issuedCert)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun verifyCertificateByCode(code: String): Result<Certificate?> {
        val clean = code.trim().uppercase(Locale.US)
        if (clean.isEmpty()) return Result.success(null)
        return try {
            val snap = db.collection("certificates").document(clean).get().await()
            Result.success(snap.toObject(Certificate::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, "certificates/$clean")
            Result.failure(e)
        }
    }

    suspend fun markNotificationRead(notificationId: String): Result<Unit> {
        val uid = try { requireUserId() } catch (e: Exception) { return Result.failure(e) }
        return try {
            db.collection("users").document(uid).collection("notifications").document(notificationId)
                .update(mapOf("read" to true, "updatedAt" to FieldValue.serverTimestamp())).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$uid/notifications/$notificationId")
            Result.failure(e)
        }
    }

    suspend fun submitSupportTicket(studentName: String, studentEmail: String, subject: String, message: String): Result<Unit> {
        val uid = try { requireUserId() } catch (e: Exception) { return Result.failure(e) }
        val ticketId = SecurityUtils.generateDocId("tkt")
        return try {
            db.collection("support_tickets").document(ticketId).set(
                mapOf(
                    "userId" to uid,
                    "studentName" to studentName,
                    "studentEmail" to studentEmail,
                    "subject" to subject.trim(),
                    "message" to message.trim(),
                    "status" to "OPEN",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "support_tickets/$ticketId")
            Result.failure(e)
        }
    }

    // Admin CRUD operations
    suspend fun adminSaveCourse(course: Course): Result<Unit> {
        val docId = course.id.ifBlank { SecurityUtils.generateDocId("crs") }
        return try {
            val ref = db.collection("courses").document(docId)
            if (ref.get().await().exists()) {
                ref.update(
                    mapOf(
                        "titleAr" to course.titleAr,
                        "titleEn" to course.titleEn,
                        "descriptionAr" to course.descriptionAr,
                        "descriptionEn" to course.descriptionEn,
                        "category" to course.category,
                        "paid" to course.paid,
                        "priceEgp" to course.priceEgp,
                        "discountPercent" to course.discountPercent,
                        "published" to course.published,
                        "lessonCount" to course.lessonCount,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                ref.set(course.copy(id = docId).toCreateMap()).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "courses/$docId")
            Result.failure(e)
        }
    }

    suspend fun adminDeleteCourse(courseId: String): Result<Unit> {
        return try {
            db.collection("courses").document(courseId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "courses/$courseId")
            Result.failure(e)
        }
    }

    suspend fun adminSaveLesson(lesson: Lesson): Result<Unit> {
        val lessonId = lesson.id.ifBlank { SecurityUtils.generateDocId("lsn") }
        val path = "courses/${lesson.courseId}/lessons/$lessonId"
        return try {
            val courseRef = db.collection("courses").document(lesson.courseId)
            val ref = courseRef.collection("lessons").document(lessonId)
            val videoRef = courseRef.collection("lesson_videos").document(lessonId)
            val hasVideo = !lesson.youtubeIdAr.isNullOrBlank() || !lesson.youtubeIdEn.isNullOrBlank()
            val status = if (hasVideo) "READY" else "NEEDS_CONTENT"
            val savedLesson = lesson.copy(id = lessonId, videoStatus = status)
            if (ref.get().await().exists()) {
                val updateMap = mutableMapOf<String, Any>(
                    "orderIndex" to lesson.orderIndex,
                    "titleAr" to lesson.titleAr,
                    "titleEn" to lesson.titleEn,
                    "descriptionAr" to lesson.descriptionAr,
                    "descriptionEn" to lesson.descriptionEn,
                    "durationLabel" to lesson.durationLabel,
                    "freePreview" to lesson.freePreview,
                    "videoStatus" to status,
                    "published" to lesson.published,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                lesson.youtubeIdAr?.takeIf { it.isNotBlank() }?.let { updateMap["youtubeIdAr"] = it }
                lesson.youtubeIdEn?.takeIf { it.isNotBlank() }?.let { updateMap["youtubeIdEn"] = it }
                ref.update(updateMap).await()
            } else {
                ref.set(savedLesson.toCreateMap()).await()
            }
            videoRef.set(savedLesson.toVideoPayloadMap()).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun adminPublishAiCourse(draft: AiCourseDraft, paid: Boolean, priceEgp: Double): Result<String> {
        val courseId = SecurityUtils.generateDocId("ai_crs")
        return try {
            val batch = db.batch()
            val courseRef = db.collection("courses").document(courseId)
            val course = Course(
                id = courseId,
                titleAr = draft.titleAr,
                titleEn = draft.titleEn,
                descriptionAr = draft.descriptionAr,
                descriptionEn = draft.descriptionEn,
                category = draft.category.ifBlank { "Technology" },
                paid = paid,
                priceEgp = if (paid) priceEgp else 0.0,
                discountPercent = 0L,
                thumbnailKey = "programming",
                defaultLang = "ar",
                supportsBilingual = true,
                passingScore = 75L,
                published = true,
                lessonCount = draft.lessons.size.toLong(),
                sortOrder = 99L
            )
            batch.set(courseRef, course.toCreateMap())

            draft.lessons.forEachIndexed { idx, l ->
                val lid = "${courseId}_l${(idx + 1).toString().padStart(2, '0')}"
                val lesson = Lesson(
                    id = lid,
                    courseId = courseId,
                    orderIndex = (idx + 1).toLong(),
                    moduleTitleAr = l.moduleTitleAr.ifBlank { "الوحدة ${(idx / 5) + 1}" },
                    moduleTitleEn = l.moduleTitleEn.ifBlank { "Module ${(idx / 5) + 1}" },
                    titleAr = l.titleAr,
                    titleEn = l.titleEn,
                    descriptionAr = l.descriptionAr,
                    descriptionEn = l.descriptionEn,
                    objectivesAr = l.objectivesAr,
                    objectivesEn = l.objectivesEn,
                    durationLabel = "15m",
                    youtubeIdAr = l.verifiedVideoId,
                    defaultLang = "ar",
                    videoStatus = if (l.verifiedVideoId != null) "READY" else "NEEDS_CONTENT",
                    published = true
                )
                batch.set(courseRef.collection("lessons").document(lid), lesson.toCreateMap())
                batch.set(courseRef.collection("lesson_videos").document(lid), lesson.toVideoPayloadMap())
            }

            draft.questions.forEachIndexed { idx, q ->
                val qid = "${courseId}_q${(idx + 1).toString().padStart(2, '0')}"
                val examQ = ExamQuestion(
                    id = qid,
                    courseId = courseId,
                    orderIndex = (idx + 1).toLong(),
                    questionAr = q.questionAr,
                    questionEn = q.questionEn,
                    optionsAr = q.optionsAr,
                    optionsEn = q.optionsEn,
                    answerHash = SecurityUtils.hashExamAnswer(courseId, qid, q.correctIndex)
                )
                batch.set(courseRef.collection("questions").document(qid), examQ.toCreateMap())
                batch.set(
                    courseRef.collection("admin_keys").document(qid),
                    mapOf(
                        "courseId" to courseId,
                        "questionId" to qid,
                        "correctIndex" to q.correctIndex,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }

            batch.commit().await()
            Result.success(courseId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "courses/$courseId")
            Result.failure(e)
        }
    }

    private suspend fun seedDefaultPromoCodesIfNeeded() {
        val defaultPromos = listOf(
            Triple("NEXORA10", 10L, "خصم 10% للطلاب الجدد / 10% Welcome Discount"),
            Triple("NEXORA15", 15L, "خصم 15% على الكورسات المدفوعة / 15% Track Discount"),
            Triple("NEXORA20", 20L, "خصم 20% خاص بالمنصة / 20% Platform Offer"),
            Triple("NEXORA25", 25L, "خصم 25% للتميز الدراسي / 25% Merit Offer"),
            Triple("NEXORA30", 30L, "خصم 30% موسمي / 30% Seasonal Offer"),
            Triple("NEXORA50", 50L, "خصم 50% استثنائي / 50% Special Offer"),
            Triple("HEBA10", 10L, "هدية هبة نصر 10% / Heba Nasr 10% Gift"),
            Triple("HEBA20", 20L, "هدية هبة نصر 20% / Heba Nasr 20% Gift"),
            Triple("HEBA30", 30L, "هدية هبة نصر 30% / Heba Nasr 30% Gift"),
            Triple("WELCOME15", 15L, "خصم الترحيب 15% / Welcome 15% Discount"),
            Triple("STUDENT10", 10L, "دعم الطالب 10% / Student Support 10%"),
            Triple("STUDENT20", 20L, "دعم الطالب 20% / Student Support 20%"),
            Triple("VIP25", 25L, "خصم VIP بنسبة 25% / VIP 25% Discount"),
            Triple("VIP40", 40L, "خصم VIP بنسبة 40% / VIP 40% Discount"),
            Triple("CYBER20", 20L, "خصم مسار الأمن السيبراني / Cybersecurity 20% Off"),
            Triple("CODE25", 25L, "خصم مسار البرمجة / Programming 25% Off"),
            Triple("ART20", 20L, "خصم التصميم الرقمي / Digital Art 20% Off"),
            Triple("VIDEO15", 15L, "خصم المونتاج وتحرير الفيديو / Video Editing 15% Off"),
            Triple("VOICE20", 20L, "خصم التعليق الصوتي / Voice Over 20% Off"),
            Triple("SCHOLAR50", 50L, "منحة تفوق 50% / Scholarship 50% Off")
        )
        val existingSnap = db.collection("promo_codes").get().await()
        val existingIds = existingSnap.documents.map { it.id }.toSet()
        val missing = defaultPromos.filter { (code, _, _) -> code !in existingIds }
        if (missing.isEmpty()) return
        val batch = db.batch()
        missing.forEach { (code, pct, desc) ->
            batch.set(
                db.collection("promo_codes").document(code),
                mapOf(
                    "code" to code,
                    "discountPercent" to pct,
                    "active" to true,
                    "description" to desc,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }
        batch.commit().await()
    }

    suspend fun adminSavePromoCode(code: String, discountPercent: Long, description: String): Result<Unit> {
        val clean = code.trim().uppercase(Locale.US)
        return try {
            db.collection("promo_codes").document(clean).set(
                mapOf(
                    "code" to clean,
                    "discountPercent" to discountPercent.coerceIn(1, 100),
                    "active" to true,
                    "description" to description.take(200),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "promo_codes/$clean")
            Result.failure(e)
        }
    }

    suspend fun adminTogglePromoActive(code: String, active: Boolean): Result<Unit> {
        val clean = code.trim().uppercase(Locale.US)
        return try {
            db.collection("promo_codes").document(clean).update(
                mapOf(
                    "active" to active,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "promo_codes/$clean")
            Result.failure(e)
        }
    }

    suspend fun adminGeneratePromoBatch(discountPercent: Long = 20L, count: Int = 5): Result<List<String>> {
        return try {
            val pct = discountPercent.coerceIn(5L, 90L)
            val generated = mutableListOf<String>()
            val batch = db.batch()
            val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
            val rng = java.security.SecureRandom()
            repeat(count.coerceIn(1, 20)) {
                val suffix = buildString {
                    repeat(4) { append(chars[rng.nextInt(chars.length)]) }
                }
                val code = "NX${pct}_$suffix"
                generated.add(code)
                batch.set(
                    db.collection("promo_codes").document(code),
                    mapOf(
                        "code" to code,
                        "discountPercent" to pct,
                        "active" to true,
                        "description" to "كود خصم خاص $pct% / Special $pct% Promo",
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(generated)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "promo_codes")
            Result.failure(e)
        }
    }

    suspend fun adminSendPromoToStudent(
        targetUserId: String,
        promo: PromoCode,
        customNote: String
    ): Result<Unit> {
        val nid = SecurityUtils.generateDocId("promo_notif")
        val noteClean = customNote.trim()
        val arNote = if (noteClean.isNotEmpty()) " — $noteClean" else ""
        val enNote = if (noteClean.isNotEmpty()) " — $noteClean" else ""
        return try {
            db.collection("users").document(targetUserId).collection("notifications").document(nid).set(
                mapOf(
                    "userId" to targetUserId,
                    "titleAr" to "هدية كود خصم ${promo.discountPercent}% لك!",
                    "titleEn" to "Special ${promo.discountPercent}% Promo Code!",
                    "bodyAr" to "أرسلت لك الإدارة كود الخصم: ${promo.code} بخصم ${promo.discountPercent}% عند الاشتراك عبر WE Pay$arNote".take(595),
                    "bodyEn" to "Admin sent you promo code ${promo.code} for ${promo.discountPercent}% OFF on WE Pay checkout$enNote".take(595),
                    "type" to "PROMO_CODE",
                    "read" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "users/$targetUserId/notifications/$nid")
            Result.failure(e)
        }
    }

    suspend fun adminApplyAiUpdatePlan(
        plan: AiAdminUpdatePlan,
        existingCourses: List<Course>,
        currentConfig: PlatformConfig
    ): Result<Unit> {
        return try {
            val byId = existingCourses.associateBy { it.id }

            // 1. Apply course edits
            for (patch in plan.coursePatches) {
                val orig = byId[patch.courseId] ?: continue
                val ref = db.collection("courses").document(patch.courseId)
                val updateMap = mutableMapOf<String, Any>(
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                patch.titleAr?.take(160)?.let { updateMap["titleAr"] = it }
                patch.titleEn?.take(160)?.let { updateMap["titleEn"] = it }
                patch.descriptionAr?.take(2000)?.let { updateMap["descriptionAr"] = it }
                patch.descriptionEn?.take(2000)?.let { updateMap["descriptionEn"] = it }
                patch.priceEgp?.let { updateMap["priceEgp"] = it.coerceIn(0.0, 100_000.0) }
                patch.discountPercent?.let { updateMap["discountPercent"] = it.coerceIn(0L, 95L) }
                patch.paid?.let { updateMap["paid"] = it }
                patch.published?.let { updateMap["published"] = it }

                if (!ref.get().await().exists()) {
                    val created = orig.copy(
                        titleAr = patch.titleAr ?: orig.titleAr,
                        titleEn = patch.titleEn ?: orig.titleEn,
                        descriptionAr = patch.descriptionAr ?: orig.descriptionAr,
                        descriptionEn = patch.descriptionEn ?: orig.descriptionEn,
                        priceEgp = patch.priceEgp ?: orig.priceEgp,
                        discountPercent = patch.discountPercent ?: orig.discountPercent,
                        paid = patch.paid ?: orig.paid,
                        published = patch.published ?: orig.published
                    )
                    ref.set(created.toCreateMap()).await()
                } else {
                    ref.update(updateMap).await()
                }
            }

            // 2. Append new lesson if requested
            plan.newLesson?.let { nl ->
                val targetCourse = byId[nl.targetCourseId]
                if (targetCourse != null) {
                    val courseRef = db.collection("courses").document(targetCourse.id)
                    val lessonsSnap = courseRef.collection("lessons").get().await()
                    val nextOrder = (lessonsSnap.documents.maxOfOrNull { it.getLong("orderIndex") ?: 0L } ?: targetCourse.lessonCount) + 1L
                    val lid = SecurityUtils.generateDocId("ai_lsn")
                    val lesson = Lesson(
                        id = lid,
                        courseId = targetCourse.id,
                        orderIndex = nextOrder.coerceIn(1L, 1000L),
                        moduleTitleAr = nl.moduleTitleAr.take(160).ifBlank { "إضافة حديثة" },
                        moduleTitleEn = nl.moduleTitleEn.take(160).ifBlank { "New Module" },
                        titleAr = nl.titleAr.take(200),
                        titleEn = nl.titleEn.take(200),
                        descriptionAr = nl.descriptionAr.take(2000),
                        descriptionEn = nl.descriptionEn.take(2000),
                        objectivesAr = nl.objectivesAr.take(1500),
                        objectivesEn = nl.objectivesEn.take(1500),
                        durationLabel = "15m",
                        youtubeIdAr = nl.verifiedVideoId,
                        defaultLang = targetCourse.defaultLang,
                        videoStatus = if (nl.verifiedVideoId != null) "READY" else "NEEDS_CONTENT",
                        published = true
                    )
                    courseRef.collection("lessons").document(lid).set(lesson.toCreateMap()).await()
                    if (courseRef.get().await().exists()) {
                        courseRef.update(
                            mapOf(
                                "lessonCount" to nextOrder.coerceIn(1L, 1000L),
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        ).await()
                    }
                }
            }

            // 3. Update PlatformConfig banners if changed (always syncs live to all users' phones)
            if (plan.updateAnnouncementAr != null || plan.updateAnnouncementEn != null ||
                plan.updateOfferBannerAr != null || plan.updateOfferBannerEn != null
            ) {
                db.collection("platform_config").document("main").set(
                    mapOf(
                        "wePayNumber" to currentConfig.wePayNumber,
                        "announcementAr" to (plan.updateAnnouncementAr ?: currentConfig.announcementAr).take(500),
                        "announcementEn" to (plan.updateAnnouncementEn ?: currentConfig.announcementEn).take(500),
                        "activeOfferBannerAr" to (plan.updateOfferBannerAr ?: currentConfig.activeOfferBannerAr).take(300),
                        "activeOfferBannerEn" to (plan.updateOfferBannerEn ?: currentConfig.activeOfferBannerEn).take(300),
                        "supportEmail" to BOOTSTRAP_ADMIN_EMAIL,
                        "accentPreset" to "MAUVE_MATTE",
                        "verificationBaseUrl" to currentConfig.effectiveVerificationBaseUrl(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            // 4. Broadcast live notification to all users if requested
            if (!plan.broadcastTitleAr.isNullOrBlank() || !plan.broadcastBodyAr.isNullOrBlank()) {
                val titleAr = (plan.broadcastTitleAr ?: "تحديث جديد في منصة NEXORA").take(160)
                val titleEn = (plan.broadcastTitleEn ?: "New NEXORA Platform Update").take(160)
                val bodyAr = (plan.broadcastBodyAr ?: plan.summaryAr).take(600)
                val bodyEn = (plan.broadcastBodyEn ?: plan.summaryEn).take(600)
                val usersSnap = db.collection("users").get().await()
                val chunks = usersSnap.documents.chunked(400)
                for (chunk in chunks) {
                    val b = db.batch()
                    chunk.forEach { uDoc ->
                        val uid = uDoc.id
                        val nid = SecurityUtils.generateDocId("upd")
                        b.set(
                            db.collection("users").document(uid).collection("notifications").document(nid),
                            mapOf(
                                "userId" to uid,
                                "titleAr" to titleAr,
                                "titleEn" to titleEn,
                                "bodyAr" to bodyAr,
                                "bodyEn" to bodyEn,
                                "type" to "PLATFORM_UPDATE",
                                "read" to false,
                                "createdAt" to FieldValue.serverTimestamp(),
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                    }
                    b.commit().await()
                }
            }

            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "courses")
            Result.failure(e)
        }
    }

    suspend fun adminReplyTicket(ticketId: String, reply: String): Result<Unit> {
        return try {
            db.collection("support_tickets").document(ticketId).update(
                mapOf(
                    "status" to "REPLIED",
                    "adminReply" to reply.trim(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "support_tickets/$ticketId")
            Result.failure(e)
        }
    }

    suspend fun adminUpdatePlatformConfig(
        wePayNumber: String,
        announcementAr: String,
        announcementEn: String,
        offerAr: String,
        offerEn: String,
        verificationBaseUrl: String = PlatformConfig.DEFAULT_VERIFICATION_BASE_URL
    ): Result<Unit> {
        return try {
            val cleanVerifyUrl = verificationBaseUrl.trim().trimEnd('/')
                .takeIf { it.startsWith("https://") || it.startsWith("http://") }
                ?: PlatformConfig.DEFAULT_VERIFICATION_BASE_URL
            db.collection("platform_config").document("main").set(
                mapOf(
                    "wePayNumber" to wePayNumber.trim(),
                    "announcementAr" to announcementAr.trim(),
                    "announcementEn" to announcementEn.trim(),
                    "activeOfferBannerAr" to offerAr.trim(),
                    "activeOfferBannerEn" to offerEn.trim(),
                    "supportEmail" to BOOTSTRAP_ADMIN_EMAIL,
                    "accentPreset" to "MAUVE_MATTE",
                    "verificationBaseUrl" to cleanVerifyUrl.take(240),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "platform_config/main")
            Result.failure(e)
        }
    }

    suspend fun adminToggleStudentStatus(userId: String, suspendAccount: Boolean): Result<Unit> {
        return try {
            db.collection("users").document(userId).update(
                mapOf(
                    "accountStatus" to if (suspendAccount) "SUSPENDED" else "ACTIVE",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$userId")
            Result.failure(e)
        }
    }

    suspend fun adminSetAnnualSubscription(userId: String, activeAnnual: Boolean): Result<Unit> {
        return try {
            val batch = db.batch()
            val userRef = db.collection("users").document(userId)
            batch.update(
                userRef,
                mapOf(
                    "subscriptionPlan" to if (activeAnnual) "ANNUAL" else "NONE",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            val nid = SecurityUtils.generateDocId("sub")
            batch.set(
                userRef.collection("notifications").document(nid),
                mapOf(
                    "userId" to userId,
                    "titleAr" to if (activeAnnual) "تم تفعيل الاشتراك السنوي" else "تم إيقاف الاشتراك السنوي",
                    "titleEn" to if (activeAnnual) "Annual Subscription Activated" else "Annual Subscription Ended",
                    "bodyAr" to if (activeAnnual) "تم فتح جميع الكورسات المدفوعة بحسابك عبر الاشتراك السنوي." else "تم تحديث خطة الاشتراك السنوي لحسابك.",
                    "bodyEn" to if (activeAnnual) "All 5 paid tracks are now unlocked under your Annual Subscription." else "Your Annual Subscription status was updated by Admin.",
                    "type" to "SUBSCRIPTION_UPDATE",
                    "read" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$userId")
            Result.failure(e)
        }
    }

    suspend fun adminCorrectStudentName(
        targetUserId: String,
        firstName: String,
        fatherName: String,
        familyName: String,
        updateExistingCertificates: Boolean
    ): Result<Unit> {
        val combined = SecurityUtils.composeTripleName(firstName, fatherName, familyName)
        if (!SecurityUtils.isTripleName(combined)) {
            return Result.failure(IllegalArgumentException("يرجى إدخال الاسم الثلاثي كاملًا لتصحيح اسم الطالب."))
        }
        return try {
            val batch = db.batch()
            val userRef = db.collection("users").document(targetUserId)
            batch.update(
                userRef,
                mapOf(
                    "firstName" to firstName.trim().take(40),
                    "fatherName" to fatherName.trim().take(40),
                    "familyName" to familyName.trim().take(40),
                    "fullName" to combined.take(120),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            if (updateExistingCertificates) {
                val certSnap = db.collection("certificates").whereEqualTo("userId", targetUserId).get().await()
                for (doc in certSnap.documents) {
                    batch.update(doc.reference, mapOf("studentName" to combined.take(120)))
                }
            }
            val nid = SecurityUtils.generateDocId("name_fix")
            batch.set(
                userRef.collection("notifications").document(nid),
                mapOf(
                    "userId" to targetUserId,
                    "titleAr" to "تم تحديث الاسم الثلاثي بواسطة الإدارة",
                    "titleEn" to "Full Name Updated by Admin",
                    "bodyAr" to "تم اعتماد اسمك الرسمي: $combined",
                    "bodyEn" to "Your official student name was updated by Admin to: $combined",
                    "type" to "ADMIN_CORRECTION",
                    "read" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$targetUserId")
            Result.failure(e)
        }
    }

    suspend fun adminFetchStudentDetail(targetUserId: String): Result<Triple<List<Enrollment>, List<LessonProgress>, List<Certificate>>> {
        return try {
            val enrolls = db.collection("users").document(targetUserId).collection("enrollments").get().await()
                .toObjects(Enrollment::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            val prog = db.collection("users").document(targetUserId).collection("progress").get().await()
                .toObjects(LessonProgress::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            val certs = db.collection("certificates").whereEqualTo("userId", targetUserId).get().await()
                .toObjects(Certificate::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            Result.success(Triple(enrolls, prog, certs))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, "users/$targetUserId")
            Result.failure(e)
        }
    }

    suspend fun adminToggleCertificateRevoked(certificateCode: String, revoked: Boolean): Result<Unit> {
        return try {
            db.collection("certificates").document(certificateCode)
                .update(mapOf("revoked" to revoked)).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "certificates/$certificateCode")
            Result.failure(e)
        }
    }

    suspend fun adminSendStudentNotification(
        targetUserId: String,
        titleAr: String,
        titleEn: String,
        bodyAr: String,
        bodyEn: String
    ): Result<Unit> {
        val nid = SecurityUtils.generateDocId("notif")
        return try {
            db.collection("users").document(targetUserId).collection("notifications").document(nid).set(
                mapOf(
                    "userId" to targetUserId,
                    "titleAr" to titleAr,
                    "titleEn" to titleEn,
                    "bodyAr" to bodyAr,
                    "bodyEn" to bodyEn,
                    "type" to "PLATFORM_UPDATE",
                    "read" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "users/$targetUserId/notifications/$nid")
            Result.failure(e)
        }
    }
}
