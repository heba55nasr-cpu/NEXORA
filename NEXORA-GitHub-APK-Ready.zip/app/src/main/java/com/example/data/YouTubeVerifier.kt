package com.example.data

import com.example.core.SecurityUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class VideoVerificationResult(
    val valid: Boolean,
    val videoId: String? = null,
    val title: String? = null,
    val authorName: String? = null,
    val thumbnailUrl: String? = null,
    val error: String? = null
)

class YouTubeVerifier(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()
) {
    suspend fun verifyUrlOrId(rawInput: String): VideoVerificationResult = withContext(Dispatchers.IO) {
        val videoId = SecurityUtils.extractYoutubeVideoId(rawInput)
            ?: return@withContext VideoVerificationResult(
                valid = false,
                error = "Invalid YouTube URL or 11-character Video ID"
            )

        val oEmbedUrl = "https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=$videoId&format=json"
        val request = Request.Builder().url(oEmbedUrl).get().build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext VideoVerificationResult(
                        valid = false,
                        videoId = videoId,
                        error = "Video unavailable or embedding restricted (HTTP ${response.code})"
                    )
                }
                val body = response.body?.string().orEmpty()
                val json = JSONObject(body)
                VideoVerificationResult(
                    valid = true,
                    videoId = videoId,
                    title = json.optString("title"),
                    authorName = json.optString("author_name"),
                    thumbnailUrl = json.optString("thumbnail_url")
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            VideoVerificationResult(
                valid = false,
                videoId = videoId,
                error = e.localizedMessage ?: "Network verification error"
            )
        }
    }
}
