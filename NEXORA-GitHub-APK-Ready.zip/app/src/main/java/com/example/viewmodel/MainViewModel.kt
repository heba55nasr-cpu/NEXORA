package com.example.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.SecurityUtils
import com.example.data.AiAdminUpdatePlan
import com.example.data.AiCourseBuilderService
import com.example.data.AiCourseDraft
import com.example.data.NexoraRepository
import com.example.data.VideoVerificationResult
import com.example.data.YouTubeVerifier
import com.example.model.*
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

val Context.nexoraDataStore: DataStore<Preferences> by preferencesDataStore(name = "nexora_prefs")

object PrefKeys {
    val PREFERRED_LANG = stringPreferencesKey("preferred_lang")
    val DARK_THEME = booleanPreferencesKey("dark_theme")
    val AUTO_LOGIN_ENABLED = booleanPreferencesKey("auto_login_enabled")
    val ONBOARDED_UIDS = androidx.datastore.preferences.core.stringSetPreferencesKey("onboarded_uids")
}

sealed interface CertVerifyUiState {
    data object Idle : CertVerifyUiState
    data object Loading : CertVerifyUiState
    data class Found(val certificate: Certificate) : CertVerifyUiState
    data class NotFound(val code: String) : CertVerifyUiState
    data class Error(val message: String) : CertVerifyUiState
}

data class AdminStudentDetail(
    val userId: String,
    val enrollments: List<Enrollment>,
    val progress: List<LessonProgress>,
    val certificates: List<Certificate>
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(
    private val repository: NexoraRepository,
    private val youtubeVerifier: YouTubeVerifier,
    private val aiCourseBuilder: AiCourseBuilderService,
    private val dataStore: DataStore<Preferences>,
    val currentUserId: String,
    val currentUserEmail: String,
    val currentUserDisplayName: String,
    val isAdmin: Boolean
) : ViewModel() {

    private val _selectedCourseId = MutableStateFlow<String?>(null)
    val selectedCourseId: StateFlow<String?> = _selectedCourseId.asStateFlow()

    private val _selectedLessonId = MutableStateFlow<String?>(null)
    val selectedLessonId: StateFlow<String?> = _selectedLessonId.asStateFlow()

    // Remembers (courseId to lessonId) when a student clicks a locked lesson and gets redirected to payment
    private val _pendingCheckoutTarget = MutableStateFlow<Pair<String, String>?>(null)
    val pendingCheckoutTarget: StateFlow<Pair<String, String>?> = _pendingCheckoutTarget.asStateFlow()

    private val _selectedAdminStudentDetail = MutableStateFlow<AdminStudentDetail?>(null)
    val selectedAdminStudentDetail: StateFlow<AdminStudentDetail?> = _selectedAdminStudentDetail.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _latestExamAttempt = MutableStateFlow<ExamAttempt?>(null)
    val latestExamAttempt: StateFlow<ExamAttempt?> = _latestExamAttempt.asStateFlow()

    private val _appliedPromo = MutableStateFlow<PromoCode?>(null)
    val appliedPromo: StateFlow<PromoCode?> = _appliedPromo.asStateFlow()

    private val _videoVerifyResult = MutableStateFlow<VideoVerificationResult?>(null)
    val videoVerifyResult: StateFlow<VideoVerificationResult?> = _videoVerifyResult.asStateFlow()

    private val _verifyingVideo = MutableStateFlow(false)
    val verifyingVideo: StateFlow<Boolean> = _verifyingVideo.asStateFlow()

    private val _aiDraft = MutableStateFlow<AiCourseDraft?>(null)
    val aiDraft: StateFlow<AiCourseDraft?> = _aiDraft.asStateFlow()

    private val _aiGenerating = MutableStateFlow(false)
    val aiGenerating: StateFlow<Boolean> = _aiGenerating.asStateFlow()

    private val _aiUpdatePlan = MutableStateFlow<AiAdminUpdatePlan?>(null)
    val aiUpdatePlan: StateFlow<AiAdminUpdatePlan?> = _aiUpdatePlan.asStateFlow()

    private val _aiUpdatePlanning = MutableStateFlow(false)
    val aiUpdatePlanning: StateFlow<Boolean> = _aiUpdatePlanning.asStateFlow()

    private val _certVerifyState = MutableStateFlow<CertVerifyUiState>(CertVerifyUiState.Idle)
    val certVerifyState: StateFlow<CertVerifyUiState> = _certVerifyState.asStateFlow()

    val preferredLang: StateFlow<String> = dataStore.data
        .map { prefs -> prefs[PrefKeys.PREFERRED_LANG] ?: "ar" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), "ar")

    val darkTheme: StateFlow<Boolean> = dataStore.data
        .map { prefs -> prefs[PrefKeys.DARK_THEME] ?: true }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), true)

    val userProfile: StateFlow<UserProfile?> = repository.observeUserProfile(currentUserId)
        .catch { err ->
            handleFlowError(err)
            emit(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    val platformConfig: StateFlow<PlatformConfig> = repository.observePlatformConfig()
        .catch { err ->
            handleFlowError(err)
            emit(PlatformConfig())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), PlatformConfig())

    val courses: StateFlow<List<Course>> = repository.observeCourses(isAdmin)
        .catch { err ->
            handleFlowError(err)
            emit(CourseSeedCourses.courses)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), CourseSeedCourses.courses)

    val enrollments: StateFlow<List<Enrollment>> = repository.observeEnrollments(currentUserId)
        .catch { err ->
            handleFlowError(err)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val progress: StateFlow<List<LessonProgress>> = repository.observeProgress(currentUserId)
        .catch { err ->
            handleFlowError(err)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val examAttempts: StateFlow<List<ExamAttempt>> = repository.observeExamAttempts(currentUserId)
        .catch { err ->
            handleFlowError(err)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val studentPayments: StateFlow<List<PaymentRequest>> = repository.observeStudentPayments(currentUserId)
        .catch { err ->
            handleFlowError(err)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val studentCertificates: StateFlow<List<Certificate>> = repository.observeStudentCertificates(currentUserId)
        .catch { err ->
            handleFlowError(err)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val notifications: StateFlow<List<StudentNotification>> = repository.observeNotifications(currentUserId)
        .catch { err ->
            handleFlowError(err)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val studentTickets: StateFlow<List<SupportTicket>> = repository.observeStudentTickets(currentUserId)
        .catch { err ->
            handleFlowError(err)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val selectedCourseLessons: StateFlow<List<Lesson>> = _selectedCourseId
        .flatMapLatest { cid ->
            if (cid.isNullOrBlank()) flowOf(emptyList())
            else repository.observeLessons(cid, isAdmin)
                .catch { err ->
                    handleFlowError(err)
                    emit(CourseSeedCourses.buildLessonsForCourse(cid))
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val selectedCourseQuestions: StateFlow<List<ExamQuestion>> = _selectedCourseId
        .flatMapLatest { cid ->
            if (cid.isNullOrBlank()) flowOf(emptyList())
            else repository.observeQuestions(cid)
                .catch { err ->
                    handleFlowError(err)
                    emit(CourseSeedExams.buildQuestionsForCourse(cid).first)
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // Admin streams (active only when isAdmin == true)
    val adminPayments: StateFlow<List<PaymentRequest>> = if (isAdmin) {
        repository.observeAllPaymentsAdmin()
            .catch { err -> handleFlowError(err); emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val adminUsers: StateFlow<List<UserProfile>> = if (isAdmin) {
        repository.observeAllUsersAdmin()
            .catch { err -> handleFlowError(err); emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val adminTickets: StateFlow<List<SupportTicket>> = if (isAdmin) {
        repository.observeAllTicketsAdmin()
            .catch { err -> handleFlowError(err); emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val adminPromos: StateFlow<List<PromoCode>> = if (isAdmin) {
        repository.observePromoCodesAdmin()
            .catch { err -> handleFlowError(err); emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val adminCertificates: StateFlow<List<Certificate>> = if (isAdmin) {
        repository.observeAllCertificatesAdmin()
            .catch { err -> handleFlowError(err); emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    init {
        if (isAdmin) {
            viewModelScope.launch {
                repository.seedInitialCatalogIfNeeded()
            }
        }
    }

    private fun handleFlowError(err: Throwable) {
        val fsErr = generateSequence(err) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (fsErr == null && err is CancellationException) throw err
        _statusMessage.value = fsErr?.localizedMessage ?: err.localizedMessage
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun selectCourse(courseId: String) {
        _selectedCourseId.value = courseId
        _latestExamAttempt.value = null
        _appliedPromo.value = null
    }

    fun selectLesson(lessonId: String) {
        _selectedLessonId.value = lessonId
    }

    fun setPendingCheckoutTarget(courseId: String, lessonId: String?) {
        _pendingCheckoutTarget.value = lessonId?.takeIf { it.isNotBlank() }?.let { courseId to it }
    }

    fun clearPendingCheckoutTarget() {
        _pendingCheckoutTarget.value = null
    }

    fun verifyAndOpenLesson(
        course: Course,
        lesson: Lesson,
        onAllowed: (Lesson) -> Unit,
        onNeedsPayment: () -> Unit
    ) {
        viewModelScope.launch {
            _busy.value = true
            val res = repository.verifyLessonVideoAccess(course, lesson)
            _busy.value = false
            res.onSuccess { resolvedLesson ->
                _selectedLessonId.value = resolvedLesson.id
                onAllowed(resolvedLesson)
            }.onFailure { err ->
                setPendingCheckoutTarget(course.id, lesson.id)
                _statusMessage.value = err.localizedMessage ?: if (preferredLang.value == "ar") {
                    "هذا الكورس مدفوع. لمشاهدة الفيديوهات والدروس، يرجى تحويل رسوم الكورس أولاً."
                } else {
                    "This course is paid. To watch the videos and lessons, please transfer the course fee first."
                }
                onNeedsPayment()
            }
        }
    }

    fun toggleLanguage() {
        viewModelScope.launch {
            val next = if (preferredLang.value == "ar") "en" else "ar"
            dataStore.edit { it[PrefKeys.PREFERRED_LANG] = next }
            val existingProfile = userProfile.value
            if (existingProfile != null && SecurityUtils.isTripleName(existingProfile.fullName)) {
                repository.updateProfile(
                    fullName = existingProfile.fullName,
                    preferredLang = next,
                    firstName = existingProfile.firstName,
                    fatherName = existingProfile.fatherName,
                    familyName = existingProfile.familyName
                )
            }
        }
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch {
            dataStore.edit { it[PrefKeys.PREFERRED_LANG] = lang }
        }
    }

    fun toggleDarkTheme() {
        viewModelScope.launch {
            dataStore.edit { it[PrefKeys.DARK_THEME] = !darkTheme.value }
        }
    }

    fun saveOnboardingProfile(
        firstName: String,
        fatherName: String,
        familyName: String,
        lang: String,
        onComplete: () -> Unit
    ) {
        val combined = SecurityUtils.composeTripleName(firstName, fatherName, familyName)
        viewModelScope.launch {
            _busy.value = true
            dataStore.edit { it[PrefKeys.PREFERRED_LANG] = lang }
            val result = if (userProfile.value == null) {
                repository.ensureOrCreateProfile(
                    fullName = combined,
                    preferredLang = lang,
                    firstName = firstName,
                    fatherName = fatherName,
                    familyName = familyName
                )
            } else {
                repository.updateProfile(
                    fullName = combined,
                    preferredLang = lang,
                    firstName = firstName,
                    fatherName = fatherName,
                    familyName = familyName
                )
            }
            _busy.value = false
            result.onSuccess {
                _statusMessage.value = if (lang == "ar") "تم حفظ الاسم الثلاثي والملف الشخصي" else "Full three-part profile saved"
                onComplete()
            }.onFailure { err ->
                _statusMessage.value = err.localizedMessage
            }
        }
    }

    fun saveOnboardingProfile(fullName: String, lang: String, onComplete: () -> Unit) {
        val split = SecurityUtils.splitTripleName(fullName)
        saveOnboardingProfile(split.first, split.second, split.third, lang, onComplete)
    }

    fun showStatusMessage(msg: String) {
        _statusMessage.value = msg
    }

    fun enrollFreeCourse(courseId: String) {
        val targetCourse = courses.value.find { it.id == courseId }
        if (targetCourse?.paid == true) {
            _statusMessage.value = if (preferredLang.value == "ar") {
                "هذا الكورس مدفوع — يجب إرسال الدفع والتحقق منه أولًا"
            } else {
                "This course is paid — payment verification is required first"
            }
            return
        }
        viewModelScope.launch {
            _busy.value = true
            val res = repository.enrollFreeCourse(courseId)
            _busy.value = false
            res.onSuccess {
                _statusMessage.value = if (preferredLang.value == "ar") "تم تفعيل الكورس بنجاح" else "Course unlocked successfully"
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun toggleLessonComplete(courseId: String, lessonId: String, completed: Boolean) {
        viewModelScope.launch {
            val res = repository.toggleLessonComplete(courseId, lessonId, completed)
            res.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun applyPromoCode(code: String) {
        viewModelScope.launch {
            _busy.value = true
            val res = repository.validatePromoCode(code)
            _busy.value = false
            res.onSuccess { promo ->
                _appliedPromo.value = promo
                _statusMessage.value = if (promo != null) {
                    if (preferredLang.value == "ar") "تم تطبيق خصم ${promo.discountPercent}%" else "Applied ${promo.discountPercent}% discount"
                } else {
                    if (preferredLang.value == "ar") "كود الخصم غير صالح أو منتهي" else "Promo code invalid or inactive"
                }
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun submitWePayPayment(
        course: Course,
        paymentMethod: String,
        studentTripleName: String,
        targetLessonId: String?,
        senderPhone: String,
        transactionRef: String,
        proofBase64: String?,
        onSubmitted: () -> Unit
    ) {
        viewModelScope.launch {
            _busy.value = true
            val resolvedName = studentTripleName.trim().ifBlank {
                userProfile.value?.fullName?.trim().orEmpty()
            }
            val res = repository.submitWePayPayment(
                studentName = resolvedName,
                studentEmail = currentUserEmail,
                course = course,
                promoCode = _appliedPromo.value?.code,
                targetLessonId = targetLessonId,
                paymentMethod = paymentMethod,
                wePayNumber = platformConfig.value.wePayNumber.ifBlank { "01557701433" },
                senderPhone = senderPhone,
                transactionRef = transactionRef,
                proofBase64 = proofBase64
            )
            _busy.value = false
            res.onSuccess {
                _appliedPromo.value = null
                if (!targetLessonId.isNullOrBlank()) {
                    setPendingCheckoutTarget(course.id, targetLessonId)
                }
                _statusMessage.value = if (preferredLang.value == "ar") {
                    "تم استلام طلب تأكيد الدفع (قيد المراجعة) — سيفتح الكورس تلقائيًا فور التحقق من الدفع."
                } else {
                    "Payment confirmation submitted (Pending verification). Your course unlocks automatically once verified."
                }
                onSubmitted()
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun submitExam(
        course: Course,
        questions: List<ExamQuestion>,
        selectedIndices: Map<String, Int>,
        onResult: () -> Unit
    ) {
        viewModelScope.launch {
            _busy.value = true
            val res = repository.submitExamAttempt(course, questions, selectedIndices)
            _busy.value = false
            res.onSuccess { attempt ->
                _latestExamAttempt.value = attempt
                onResult()
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun clearLatestExamAttempt() {
        _latestExamAttempt.value = null
    }

    fun issueCertificate(course: Course, scorePercent: Long, onIssued: (Certificate) -> Unit) {
        viewModelScope.launch {
            _busy.value = true
            val res = repository.issueCertificate(course = course, scorePercent = scorePercent)
            _busy.value = false
            res.onSuccess { cert ->
                _statusMessage.value = if (preferredLang.value == "ar") "تم إصدار الشهادة باسمك المسجل بنجاح" else "Certificate issued with your verified profile name!"
                onIssued(cert)
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun verifyCertificateCode(code: String) {
        viewModelScope.launch {
            val clean = code.trim().uppercase()
            if (clean.isEmpty()) return@launch
            _certVerifyState.value = CertVerifyUiState.Loading
            val res = repository.verifyCertificateByCode(clean)
            res.onSuccess { cert ->
                _certVerifyState.value = if (cert != null) {
                    CertVerifyUiState.Found(cert)
                } else {
                    CertVerifyUiState.NotFound(clean)
                }
            }.onFailure { err ->
                _certVerifyState.value = CertVerifyUiState.Error(err.localizedMessage ?: "Verification failed")
            }
        }
    }

    fun resetCertVerify() {
        _certVerifyState.value = CertVerifyUiState.Idle
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationRead(id)
        }
    }

    fun submitSupportTicket(subject: String, message: String, onDone: () -> Unit) {
        viewModelScope.launch {
            _busy.value = true
            val name = userProfile.value?.fullName?.ifBlank { currentUserDisplayName } ?: currentUserDisplayName
            val res = repository.submitSupportTicket(name, currentUserEmail, subject, message)
            _busy.value = false
            res.onSuccess {
                _statusMessage.value = if (preferredLang.value == "ar") "تم إرسال رسالتك للدعم" else "Support ticket submitted"
                onDone()
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    // Admin actions
    fun reviewPayment(payment: PaymentRequest, approve: Boolean, note: String) {
        viewModelScope.launch {
            _busy.value = true
            val res = repository.reviewPayment(payment, approve, note)
            _busy.value = false
            res.onSuccess {
                _statusMessage.value = if (approve) "Payment approved & course unlocked" else "Payment rejected"
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun adminSaveCourse(course: Course) {
        viewModelScope.launch {
            _busy.value = true
            val res = repository.adminSaveCourse(course)
            _busy.value = false
            res.onSuccess { _statusMessage.value = "Course saved" }
                .onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun adminDeleteCourse(courseId: String) {
        viewModelScope.launch {
            _busy.value = true
            val res = repository.adminDeleteCourse(courseId)
            _busy.value = false
            res.onSuccess { _statusMessage.value = "Course deleted" }
                .onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun verifyYoutubeLink(rawInput: String) {
        viewModelScope.launch {
            _verifyingVideo.value = true
            val res = youtubeVerifier.verifyUrlOrId(rawInput)
            _videoVerifyResult.value = res
            _verifyingVideo.value = false
        }
    }

    fun clearVideoVerification() {
        _videoVerifyResult.value = null
    }

    fun adminSaveLesson(lesson: Lesson) {
        viewModelScope.launch {
            _busy.value = true
            val res = repository.adminSaveLesson(lesson)
            _busy.value = false
            res.onSuccess { _statusMessage.value = "Lesson saved" }
                .onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun generateAiCourse(topic: String, level: String) {
        viewModelScope.launch {
            _aiGenerating.value = true
            val res = aiCourseBuilder.generateCourseDraft(topic, level)
            _aiGenerating.value = false
            res.onSuccess { draft ->
                _aiDraft.value = draft
            }.onFailure { err ->
                _statusMessage.value = err.localizedMessage
            }
        }
    }

    fun publishAiCourse(paid: Boolean, priceEgp: Double) {
        val draft = _aiDraft.value ?: return
        viewModelScope.launch {
            _busy.value = true
            val res = repository.adminPublishAiCourse(draft, paid, priceEgp)
            _busy.value = false
            res.onSuccess {
                _aiDraft.value = null
                _statusMessage.value = "AI Course published to catalog!"
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun clearAiDraft() {
        _aiDraft.value = null
    }

    fun adminSavePromoCode(code: String, discountPercent: Long, description: String) {
        if (!isAdmin) return
        viewModelScope.launch {
            _busy.value = true
            val res = repository.adminSavePromoCode(code, discountPercent, description)
            _busy.value = false
            res.onSuccess {
                _statusMessage.value = if (preferredLang.value == "ar") "تم حفظ كود الخصم" else "Promo code saved"
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun adminTogglePromoActive(code: String, active: Boolean) {
        if (!isAdmin) return
        viewModelScope.launch {
            val res = repository.adminTogglePromoActive(code, active)
            res.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun adminGeneratePromoBatch(discountPercent: Long = 20L, count: Int = 5) {
        if (!isAdmin) return
        viewModelScope.launch {
            _busy.value = true
            val res = repository.adminGeneratePromoBatch(discountPercent, count)
            _busy.value = false
            res.onSuccess { list ->
                _statusMessage.value = if (preferredLang.value == "ar") {
                    "تم توليد ${list.size} أكواد خصم جديدة"
                } else {
                    "Generated ${list.size} new promo codes"
                }
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun adminSendPromoToStudent(targetUserId: String, promo: PromoCode, customNote: String) {
        if (!isAdmin) return
        viewModelScope.launch {
            _busy.value = true
            val res = repository.adminSendPromoToStudent(targetUserId, promo, customNote)
            _busy.value = false
            res.onSuccess {
                _statusMessage.value = if (preferredLang.value == "ar") {
                    "تم إرسال الكود ${promo.code} للطالب بنجاح"
                } else {
                    "Sent promo ${promo.code} to student"
                }
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun generateAiUpdatePlan(instruction: String) {
        if (!isAdmin || instruction.isBlank()) return
        viewModelScope.launch {
            _aiUpdatePlanning.value = true
            val res = aiCourseBuilder.generateAdminUpdatePlan(
                instruction = instruction.trim(),
                existingCourses = courses.value,
                currentConfig = platformConfig.value
            )
            _aiUpdatePlanning.value = false
            res.onSuccess { plan ->
                _aiUpdatePlan.value = plan
            }.onFailure { err ->
                _statusMessage.value = err.localizedMessage
            }
        }
    }

    fun applyAiUpdatePlan() {
        val plan = _aiUpdatePlan.value ?: return
        if (!isAdmin) return
        viewModelScope.launch {
            _busy.value = true
            val res = repository.adminApplyAiUpdatePlan(
                plan = plan,
                existingCourses = courses.value,
                currentConfig = platformConfig.value
            )
            _busy.value = false
            res.onSuccess {
                _aiUpdatePlan.value = null
                _statusMessage.value = if (preferredLang.value == "ar") {
                    "تم تنفيذ التحديث بالذكاء الاصطناعي ومزامنته تلقائيًا لهواتف الطلاب"
                } else {
                    "AI updates applied and synced live to all students' phones"
                }
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun clearAiUpdatePlan() {
        _aiUpdatePlan.value = null
    }

    fun adminReplyTicket(ticketId: String, reply: String) {
        viewModelScope.launch {
            _busy.value = true
            val res = repository.adminReplyTicket(ticketId, reply)
            _busy.value = false
            res.onSuccess { _statusMessage.value = "Reply sent" }
                .onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun adminUpdatePlatformConfig(
        wePayNumber: String,
        announcementAr: String,
        announcementEn: String,
        offerAr: String,
        offerEn: String,
        verificationBaseUrl: String = PlatformConfig.DEFAULT_VERIFICATION_BASE_URL
    ) {
        viewModelScope.launch {
            _busy.value = true
            val res = repository.adminUpdatePlatformConfig(
                wePayNumber = wePayNumber,
                announcementAr = announcementAr,
                announcementEn = announcementEn,
                offerAr = offerAr,
                offerEn = offerEn,
                verificationBaseUrl = verificationBaseUrl
            )
            _busy.value = false
            res.onSuccess { _statusMessage.value = "Platform settings updated" }
                .onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun adminToggleStudentStatus(userId: String, suspendAccount: Boolean) {
        viewModelScope.launch {
            val res = repository.adminToggleStudentStatus(userId, suspendAccount)
            res.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun adminSetAnnualSubscription(userId: String, activeAnnual: Boolean) {
        if (!isAdmin) return
        viewModelScope.launch {
            _busy.value = true
            val res = repository.adminSetAnnualSubscription(userId, activeAnnual)
            _busy.value = false
            res.onSuccess {
                _statusMessage.value = if (activeAnnual) "Annual subscription activated" else "Annual subscription removed"
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun adminCorrectStudentName(
        userId: String,
        firstName: String,
        fatherName: String,
        familyName: String,
        updateExistingCertificates: Boolean
    ) {
        if (!isAdmin) return
        viewModelScope.launch {
            _busy.value = true
            val res = repository.adminCorrectStudentName(
                targetUserId = userId,
                firstName = firstName,
                fatherName = fatherName,
                familyName = familyName,
                updateExistingCertificates = updateExistingCertificates
            )
            _busy.value = false
            res.onSuccess {
                adminFetchStudentDetail(userId)
                _statusMessage.value = if (preferredLang.value == "ar") "تم تحديث الاسم الثلاثي للطالب" else "Student name updated"
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun adminFetchStudentDetail(userId: String) {
        if (!isAdmin) return
        viewModelScope.launch {
            val res = repository.adminFetchStudentDetail(userId)
            res.onSuccess { (enrolls, prog, certs) ->
                _selectedAdminStudentDetail.value = AdminStudentDetail(userId, enrolls, prog, certs)
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun clearAdminStudentDetail() {
        _selectedAdminStudentDetail.value = null
    }

    fun adminToggleCertificateRevoked(certificateCode: String, revoked: Boolean) {
        if (!isAdmin) return
        viewModelScope.launch {
            _busy.value = true
            val res = repository.adminToggleCertificateRevoked(certificateCode, revoked)
            _busy.value = false
            res.onSuccess {
                _selectedAdminStudentDetail.value?.let { adminFetchStudentDetail(it.userId) }
                _statusMessage.value = if (revoked) "Certificate revoked" else "Certificate restored"
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun adminSendStudentNotification(userId: String, titleAr: String, titleEn: String, bodyAr: String, bodyEn: String) {
        viewModelScope.launch {
            val res = repository.adminSendStudentNotification(userId, titleAr, titleEn, bodyAr, bodyEn)
            res.onSuccess { _statusMessage.value = "Notification sent" }
                .onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    suspend fun encodeReceiptImageToBase64(context: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val rawBytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: return@withContext null
            val decoded = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size)
                ?: return@withContext null
            val maxDim = 900
            val scale = minOf(1f, maxDim.toFloat() / maxOf(decoded.width, decoded.height))
            val scaled = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    decoded,
                    (decoded.width * scale).toInt().coerceAtLeast(1),
                    (decoded.height * scale).toInt().coerceAtLeast(1),
                    true
                )
            } else decoded
            var quality = 80
            var outBytes: ByteArray
            do {
                val bos = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, quality, bos)
                outBytes = bos.toByteArray()
                quality -= 15
            } while (outBytes.size > 280_000 && quality >= 25)
            Base64.encodeToString(outBytes, Base64.NO_WRAP)
        }.getOrNull()
    }

    class Factory(
        private val context: Context,
        private val userId: String,
        private val email: String,
        private val displayName: String,
        private val isAdmin: Boolean
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val appCtx = context.applicationContext
            val verifier = YouTubeVerifier()
            return MainViewModel(
                repository = NexoraRepository(appCtx),
                youtubeVerifier = verifier,
                aiCourseBuilder = AiCourseBuilderService(verifier),
                dataStore = appCtx.nexoraDataStore,
                currentUserId = userId,
                currentUserEmail = email,
                currentUserDisplayName = displayName,
                isAdmin = isAdmin
            ) as T
        }
    }
}
