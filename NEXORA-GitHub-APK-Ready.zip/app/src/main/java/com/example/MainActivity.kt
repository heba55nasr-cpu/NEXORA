package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.SecurityUtils
import com.example.core.configureAppCheck
import com.example.core.stringsFor
import com.example.data.*
import com.example.model.Certificate
import com.example.ui.components.AnimatedSplashScreen
import com.example.ui.components.NexoraAtmosphericBackdrop
import com.example.ui.screens.*
import com.example.ui.theme.NexoraTheme
import com.example.viewmodel.CertVerifyUiState
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.PrefKeys
import com.example.viewmodel.nexoraDataStore
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private enum class MainTab {
    HOME, COURSES, CERTIFICATES, PROFILE, ADMIN
}

private sealed interface SubRoute {
    data class CourseDetail(val courseId: String) : SubRoute
    data class LessonPlayer(val courseId: String, val lessonId: String) : SubRoute
    data class WePayCheckout(val courseId: String, val targetLessonId: String? = null) : SubRoute
    data class Exam(val courseId: String) : SubRoute
    data class ExamResult(val courseId: String) : SubRoute
    data class CertificateDetail(val cert: Certificate) : SubRoute
    data class CertificateVerify(val initialCode: String = "") : SubRoute
    data object Notifications : SubRoute
    data object Support : SubRoute
}

class MainActivity : ComponentActivity() {

    private val deepLinkCodeState = mutableStateOf<String?>(null)

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        SecurityUtils.extractCertificateCodeFromUri(intent.data)?.let { code ->
            deepLinkCodeState.value = code
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        configureAppCheck(this, intent)
        deepLinkCodeState.value = SecurityUtils.extractCertificateCodeFromUri(intent?.data)

        setContent {
            val context = LocalContext.current
            val scope = rememberCoroutineScope()
            val credentialManager = remember { CredentialManager.create(context) }

            val langPref by context.nexoraDataStore.data
                .map { it[PrefKeys.PREFERRED_LANG] ?: "ar" }
                .collectAsStateWithLifecycle(initialValue = "ar")
            val darkPref by context.nexoraDataStore.data
                .map { it[PrefKeys.DARK_THEME] ?: true }
                .collectAsStateWithLifecycle(initialValue = true)
            val strings = remember(langPref) { stringsFor(langPref) }

            var showSplash by remember {
                mutableStateOf(
                    Firebase.auth.currentUser == null && deepLinkCodeState.value == null
                )
            }

            val currentUser by Firebase.auth.authStateFlow()
                .collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)

            var authBusy by remember { mutableStateOf(false) }
            var authError by remember { mutableStateOf<String?>(null) }
            var showPublicVerify by remember { mutableStateOf(false) }
            var publicVerifyInitialCode by remember { mutableStateOf("") }
            var publicVerifyState by remember { mutableStateOf<CertVerifyUiState>(CertVerifyUiState.Idle) }
            val pendingDeepLinkCode by deepLinkCodeState

            LaunchedEffect(Unit) {
                if (Firebase.auth.currentUser != null) {
                    runCatching {
                        context.nexoraDataStore.edit { it[PrefKeys.AUTO_LOGIN_ENABLED] = true }
                    }
                    return@LaunchedEffect
                }
                val autoLoginAllowed = runCatching {
                    context.nexoraDataStore.data.first()[PrefKeys.AUTO_LOGIN_ENABLED] ?: true
                }.getOrDefault(true)
                if (!autoLoginAllowed) return@LaunchedEffect

                authBusy = true
                attemptAutoSignIn(
                    context = this@MainActivity,
                    credentialManager = credentialManager,
                    onAuthSuccess = {
                        authBusy = false
                        authError = null
                        showSplash = false
                        scope.launch {
                            runCatching {
                                context.nexoraDataStore.edit { it[PrefKeys.AUTO_LOGIN_ENABLED] = true }
                            }
                        }
                    },
                    onUnauthenticated = {
                        authBusy = false
                    },
                    scope = scope
                )
            }

            NexoraTheme(darkTheme = darkPref, isArabic = strings.isArabic) {
                NexoraAtmosphericBackdrop(darkTheme = darkPref) {
                    Crossfade(targetState = showSplash, label = "splash_crossfade") { splashVisible ->
                        if (splashVisible) {
                            AnimatedSplashScreen(
                                shortMode = false,
                                onFinished = { showSplash = false }
                            )
                    } else if (currentUser == null) {
                        LaunchedEffect(pendingDeepLinkCode) {
                            val code = pendingDeepLinkCode
                            if (!code.isNullOrBlank()) {
                                publicVerifyInitialCode = code
                                showPublicVerify = true
                                deepLinkCodeState.value = null
                            }
                        }
                        if (showPublicVerify) {
                            val repo = remember { NexoraRepository(context) }
                            CertificateVerifyScreen(
                                strings = strings,
                                verifyState = publicVerifyState,
                                initialCode = publicVerifyInitialCode,
                                onVerify = { code ->
                                    scope.launch {
                                        publicVerifyState = CertVerifyUiState.Loading
                                        repo.verifyCertificateByCode(code)
                                            .onSuccess { cert ->
                                                publicVerifyState = if (cert != null) {
                                                    CertVerifyUiState.Found(cert)
                                                } else {
                                                    CertVerifyUiState.NotFound(code)
                                                }
                                            }
                                            .onFailure {
                                                publicVerifyState = CertVerifyUiState.Error(it.localizedMessage ?: "Error")
                                            }
                                    }
                                },
                                onBack = {
                                    publicVerifyState = CertVerifyUiState.Idle
                                    publicVerifyInitialCode = ""
                                    showPublicVerify = false
                                }
                            )
                        } else {
                            AuthScreen(
                                strings = strings,
                                darkTheme = darkPref,
                                authBusy = authBusy,
                                authError = authError,
                                onToggleLanguage = {
                                    scope.launch {
                                        val next = if (langPref == "ar") "en" else "ar"
                                        context.nexoraDataStore.edit { it[PrefKeys.PREFERRED_LANG] = next }
                                    }
                                },
                                onToggleTheme = {
                                    scope.launch {
                                        context.nexoraDataStore.edit { it[PrefKeys.DARK_THEME] = !darkPref }
                                    }
                                },
                                onGoogleSignIn = {
                                    authBusy = true
                                    authError = null
                                    onGoogleSignInClicked(
                                        context = context,
                                        credentialManager = credentialManager,
                                        onAuthSuccess = {
                                            authBusy = false
                                            authError = null
                                            scope.launch {
                                                runCatching {
                                                    context.nexoraDataStore.edit {
                                                        it[PrefKeys.AUTO_LOGIN_ENABLED] = true
                                                    }
                                                }
                                            }
                                        },
                                        onAuthError = { msg ->
                                            authBusy = false
                                            authError = msg
                                        },
                                        onAuthCancelled = {
                                            authBusy = false
                                        },
                                        scope = scope
                                    )
                                },
                                onOpenPublicVerify = { showPublicVerify = true }
                            )
                        }
                    } else {
                        val user = currentUser!!
                        var isAdmin by remember(user.uid) {
                            mutableStateOf(
                                user.email.equals(NexoraRepository.BOOTSTRAP_ADMIN_EMAIL, ignoreCase = true) &&
                                    user.isEmailVerified
                            )
                        }
                        var needsOnboarding by remember(user.uid) { mutableStateOf(false) }
                        var profileChecked by remember(user.uid) { mutableStateOf(false) }

                        LaunchedEffect(user.uid) {
                            val repo = NexoraRepository(context)
                            isAdmin = repo.checkIsAdmin(user)

                            val prefs = runCatching { context.nexoraDataStore.data.first() }.getOrNull()
                            val cachedOnboarded = prefs?.get(PrefKeys.ONBOARDED_UIDS)?.contains(user.uid) == true
                            if (cachedOnboarded) {
                                needsOnboarding = false
                                profileChecked = true
                            }

                            val db = FirebaseFirestore.getInstance(
                                context.getString(R.string.firestore_database_id)
                            )
                            val docSnap = runCatching {
                                db.collection("users").document(user.uid).get().await()
                            }.getOrNull()

                            if (docSnap != null) {
                                if (docSnap.exists()) {
                                    needsOnboarding = false
                                    runCatching {
                                        context.nexoraDataStore.edit { p ->
                                            val current = p[PrefKeys.ONBOARDED_UIDS] ?: emptySet()
                                            p[PrefKeys.ONBOARDED_UIDS] = current + user.uid
                                            p[PrefKeys.AUTO_LOGIN_ENABLED] = true
                                        }
                                    }
                                } else {
                                    needsOnboarding = true
                                    if (cachedOnboarded) {
                                        runCatching {
                                            context.nexoraDataStore.edit { p ->
                                                val current = p[PrefKeys.ONBOARDED_UIDS] ?: emptySet()
                                                p[PrefKeys.ONBOARDED_UIDS] = current - user.uid
                                            }
                                        }
                                    }
                                }
                            } else if (!cachedOnboarded) {
                                val cacheSnap = runCatching {
                                    db.collection("users").document(user.uid).get(Source.CACHE).await()
                                }.getOrNull()
                                needsOnboarding = cacheSnap != null && !cacheSnap.exists()
                            }
                            profileChecked = true
                        }

                        key(user.uid, isAdmin) {
                            val vm: MainViewModel = viewModel(
                                key = "${user.uid}_$isAdmin",
                                factory = MainViewModel.Factory(
                                    context = context,
                                    userId = user.uid,
                                    email = user.email.orEmpty(),
                                    displayName = user.displayName.orEmpty(),
                                    isAdmin = isAdmin
                                )
                            )
                            AuthenticatedNexoraShell(
                                viewModel = vm,
                                strings = strings,
                                darkTheme = darkPref,
                                profileChecked = profileChecked,
                                needsOnboarding = needsOnboarding,
                                incomingVerifyCode = pendingDeepLinkCode,
                                onConsumeIncomingVerifyCode = { deepLinkCodeState.value = null },
                                onOnboardingCompleted = {
                                    needsOnboarding = false
                                    scope.launch {
                                        runCatching {
                                            context.nexoraDataStore.edit { p ->
                                                val current = p[PrefKeys.ONBOARDED_UIDS] ?: emptySet()
                                                p[PrefKeys.ONBOARDED_UIDS] = current + user.uid
                                                p[PrefKeys.AUTO_LOGIN_ENABLED] = true
                                            }
                                        }
                                    }
                                },
                                onSignOut = {
                                    scope.launch {
                                        runCatching {
                                            context.nexoraDataStore.edit { p ->
                                                p[PrefKeys.AUTO_LOGIN_ENABLED] = false
                                            }
                                        }
                                    }
                                    signOut(credentialManager = credentialManager, scope = scope)
                                }
                            )
                        }
                    }
                }
                }
            }
        }
    }
}

@Composable
private fun AuthenticatedNexoraShell(
    viewModel: MainViewModel,
    strings: com.example.core.AppStrings,
    darkTheme: Boolean,
    profileChecked: Boolean,
    needsOnboarding: Boolean,
    incomingVerifyCode: String? = null,
    onConsumeIncomingVerifyCode: () -> Unit = {},
    onOnboardingCompleted: () -> Unit,
    onSignOut: () -> Unit
) {
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val platformConfig by viewModel.platformConfig.collectAsStateWithLifecycle()
    val courses by viewModel.courses.collectAsStateWithLifecycle()
    val enrollments by viewModel.enrollments.collectAsStateWithLifecycle()
    val progress by viewModel.progress.collectAsStateWithLifecycle()
    val examAttempts by viewModel.examAttempts.collectAsStateWithLifecycle()
    val payments by viewModel.studentPayments.collectAsStateWithLifecycle()
    val certificates by viewModel.studentCertificates.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val tickets by viewModel.studentTickets.collectAsStateWithLifecycle()
    val selectedLessons by viewModel.selectedCourseLessons.collectAsStateWithLifecycle()
    val selectedQuestions by viewModel.selectedCourseQuestions.collectAsStateWithLifecycle()
    val latestExamAttempt by viewModel.latestExamAttempt.collectAsStateWithLifecycle()
    val appliedPromo by viewModel.appliedPromo.collectAsStateWithLifecycle()
    val busy by viewModel.busy.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
    val certVerifyState by viewModel.certVerifyState.collectAsStateWithLifecycle()

    val adminPayments by viewModel.adminPayments.collectAsStateWithLifecycle()
    val adminUsers by viewModel.adminUsers.collectAsStateWithLifecycle()
    val adminTickets by viewModel.adminTickets.collectAsStateWithLifecycle()
    val adminPromos by viewModel.adminPromos.collectAsStateWithLifecycle()
    val adminCertificates by viewModel.adminCertificates.collectAsStateWithLifecycle()
    val pendingCheckoutTarget by viewModel.pendingCheckoutTarget.collectAsStateWithLifecycle()
    val selectedAdminStudentDetail by viewModel.selectedAdminStudentDetail.collectAsStateWithLifecycle()
    val videoVerifyResult by viewModel.videoVerifyResult.collectAsStateWithLifecycle()
    val verifyingVideo by viewModel.verifyingVideo.collectAsStateWithLifecycle()
    val aiDraft by viewModel.aiDraft.collectAsStateWithLifecycle()
    val aiGenerating by viewModel.aiGenerating.collectAsStateWithLifecycle()
    val aiUpdatePlan by viewModel.aiUpdatePlan.collectAsStateWithLifecycle()
    val aiUpdatePlanning by viewModel.aiUpdatePlanning.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(statusMessage) {
        statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    if (!profileChecked) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    if (needsOnboarding) {
        OnboardingProfileScreen(
            strings = strings,
            defaultName = viewModel.currentUserDisplayName,
            defaultEmail = viewModel.currentUserEmail,
            initialLang = if (strings.isArabic) "ar" else "en",
            busy = busy,
            onSave = { first, father, family, lang ->
                viewModel.saveOnboardingProfile(first, father, family, lang, onOnboardingCompleted)
            }
        )
        return
    }

    if (profile?.accountStatus == "SUSPENDED" && !viewModel.isAdmin) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = if (strings.isArabic) "الحساب موقوف مؤقتًا" else "Account Suspended",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.error
                    )
                    Text(
                        text = if (strings.isArabic) {
                            "يرجى التواصل مع الإدارة عبر البريد: ${platformConfig.supportEmail}"
                        } else {
                            "Please contact administration at ${platformConfig.supportEmail}"
                        }
                    )
                    Button(onClick = onSignOut) { Text(strings.signOut) }
                }
            }
        }
        return
    }

    var currentTab by remember { mutableStateOf(MainTab.HOME) }
    var subRoute by remember { mutableStateOf<SubRoute?>(null) }
    val context = LocalContext.current

    LaunchedEffect(incomingVerifyCode) {
        val code = incomingVerifyCode
        if (!code.isNullOrBlank()) {
            viewModel.resetCertVerify()
            subRoute = SubRoute.CertificateVerify(code)
            onConsumeIncomingVerifyCode()
        }
    }

    val enrolledIds = remember(enrollments) { enrollments.map { it.courseId }.toSet() }
    val hasAnnualSub = profile?.hasActiveAnnualSubscription() == true
    val pendingCourseIds = remember(payments) {
        payments.filter { it.status == "PENDING" }.map { it.courseId }.toSet()
    }
    val completedLessonIds = remember(progress) {
        progress.filter { it.completed }.map { it.lessonId }.toSet()
    }
    val unreadCount = remember(notifications) { notifications.count { !it.read } }

    // Auto-redirect back to the locked lesson the student tried to watch as soon as verified payment unlocks the course
    LaunchedEffect(enrolledIds, hasAnnualSub, subRoute, pendingCheckoutTarget) {
        val target = pendingCheckoutTarget ?: return@LaunchedEffect
        val (targetCourseId, targetLessonId) = target
        val unlocked = (targetCourseId in enrolledIds) || hasAnnualSub || viewModel.isAdmin
        val currentlyViewingThatCourse = (subRoute is SubRoute.WePayCheckout && (subRoute as SubRoute.WePayCheckout).courseId == targetCourseId) ||
            (subRoute is SubRoute.CourseDetail && (subRoute as SubRoute.CourseDetail).courseId == targetCourseId)
        if (unlocked && currentlyViewingThatCourse) {
            viewModel.clearPendingCheckoutTarget()
            viewModel.selectCourse(targetCourseId)
            viewModel.selectLesson(targetLessonId)
            subRoute = SubRoute.LessonPlayer(targetCourseId, targetLessonId)
        }
    }

    // Render full-screen sub-routes when active
    when (val route = subRoute) {
        is SubRoute.CourseDetail -> {
            val course = courses.find { it.id == route.courseId }
            if (course != null) {
                CourseDetailScreen(
                    strings = strings,
                    course = course,
                    lessons = selectedLessons,
                    isEnrolled = course.id in enrolledIds,
                    isPendingPayment = course.id in pendingCourseIds,
                    hasAnnualSubscription = hasAnnualSub,
                    latestCoursePayment = payments.firstOrNull { it.courseId == course.id },
                    isAdmin = viewModel.isAdmin,
                    completedLessonIds = completedLessonIds,
                    existingCertificate = certificates.firstOrNull { it.courseId == course.id && !it.revoked },
                    onBack = { subRoute = null },
                    onEnrollFree = { viewModel.enrollFreeCourse(course.id) },
                    onBuyViaWePay = { targetLessonId ->
                        viewModel.setPendingCheckoutTarget(course.id, targetLessonId)
                        subRoute = SubRoute.WePayCheckout(course.id, targetLessonId)
                    },
                    onPendingPaymentClick = {
                        subRoute = SubRoute.WePayCheckout(
                            courseId = course.id,
                            targetLessonId = pendingCheckoutTarget?.takeIf { it.first == course.id }?.second
                        )
                    },
                    onOpenLesson = { lesson ->
                        viewModel.verifyAndOpenLesson(
                            course = course,
                            lesson = lesson,
                            onAllowed = { _ ->
                                subRoute = SubRoute.LessonPlayer(course.id, lesson.id)
                            },
                            onNeedsPayment = {
                                subRoute = SubRoute.WePayCheckout(course.id, lesson.id)
                            }
                        )
                    },
                    onTakeExam = {
                        viewModel.clearLatestExamAttempt()
                        subRoute = SubRoute.Exam(course.id)
                    },
                    onViewCertificate = { cert ->
                        subRoute = SubRoute.CertificateDetail(cert)
                    }
                )
            } else subRoute = null
            return
        }
        is SubRoute.LessonPlayer -> {
            val course = courses.find { it.id == route.courseId }
            val listedLesson = selectedLessons.find { it.id == route.lessonId }
            var verifiedLesson by remember(route.courseId, route.lessonId) {
                mutableStateOf<com.example.model.Lesson?>(null)
            }
            val lesson = verifiedLesson ?: listedLesson
            val courseUnlocked = course != null && (
                !course.paid || (course.id in enrolledIds) || hasAnnualSub || viewModel.isAdmin
            )
            val hasAccess = course != null && lesson != null && (
                courseUnlocked || lesson.freePreview
            )

            LaunchedEffect(course?.id, listedLesson?.id, courseUnlocked) {
                if (course != null && listedLesson != null) {
                    viewModel.verifyAndOpenLesson(
                        course = course,
                        lesson = listedLesson,
                        onAllowed = { resolved -> verifiedLesson = resolved },
                        onNeedsPayment = {
                            subRoute = SubRoute.WePayCheckout(course.id, listedLesson.id)
                        }
                    )
                }
            }

            if (course != null && lesson == null && courseUnlocked) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (course != null && lesson != null && hasAccess) {
                LessonPlayerScreen(
                    strings = strings,
                    course = course,
                    lessons = selectedLessons,
                    currentLesson = lesson,
                    completedLessonIds = completedLessonIds,
                    onBack = { subRoute = SubRoute.CourseDetail(course.id) },
                    onSelectLesson = { next ->
                        viewModel.verifyAndOpenLesson(
                            course = course,
                            lesson = next,
                            onAllowed = { resolved ->
                                verifiedLesson = resolved
                                subRoute = SubRoute.LessonPlayer(course.id, resolved.id)
                            },
                            onNeedsPayment = {
                                subRoute = SubRoute.WePayCheckout(course.id, next.id)
                            }
                        )
                    },
                    onToggleCompleted = { done ->
                        viewModel.toggleLessonComplete(course.id, lesson.id, done)
                    }
                )
            } else if (course != null && !courseUnlocked) {
                viewModel.setPendingCheckoutTarget(course.id, route.lessonId)
                subRoute = SubRoute.WePayCheckout(course.id, route.lessonId)
            } else {
                subRoute = SubRoute.CourseDetail(route.courseId)
            }
            return
        }
        is SubRoute.WePayCheckout -> {
            val course = courses.find { it.id == route.courseId }
            if (course != null) {
                val targetLessonTitle = route.targetLessonId?.let { lid ->
                    selectedLessons.find { it.id == lid }?.let { if (strings.isArabic) it.titleAr else it.titleEn }
                }
                WePayCheckoutScreen(
                    strings = strings,
                    course = course,
                    wePayNumber = platformConfig.wePayNumber,
                    studentEmail = viewModel.currentUserEmail,
                    targetLessonTitle = targetLessonTitle,
                    existingCoursePayment = payments.firstOrNull { it.courseId == course.id },
                    appliedPromo = appliedPromo,
                    busy = busy,
                    initialFullName = profile?.fullName.orEmpty(),
                    encodeReceipt = { uri -> viewModel.encodeReceiptImageToBase64(context, uri) },
                    onApplyPromo = { code -> viewModel.applyPromoCode(code) },
                    onSubmitPayment = { method, tripleName, phone, ref, proof ->
                        viewModel.submitWePayPayment(
                            course = course,
                            paymentMethod = method,
                            studentTripleName = tripleName,
                            targetLessonId = route.targetLessonId,
                            senderPhone = phone,
                            transactionRef = ref,
                            proofBase64 = proof
                        ) {}
                    },
                    onNumberCopied = {},
                    onBack = { subRoute = SubRoute.CourseDetail(course.id) }
                )
            } else subRoute = null
            return
        }
        is SubRoute.Exam -> {
            val course = courses.find { it.id == route.courseId }
            if (course != null) {
                ExamScreen(
                    strings = strings,
                    course = course,
                    questions = selectedQuestions,
                    busy = busy,
                    onBack = { subRoute = SubRoute.CourseDetail(course.id) },
                    onSubmit = { answers ->
                        viewModel.submitExam(course, selectedQuestions, answers) {
                            subRoute = SubRoute.ExamResult(course.id)
                        }
                    }
                )
            } else subRoute = null
            return
        }
        is SubRoute.ExamResult -> {
            val course = courses.find { it.id == route.courseId }
            val attempt = latestExamAttempt
            if (course != null && attempt != null) {
                ExamResultScreen(
                    strings = strings,
                    course = course,
                    attempt = attempt,
                    existingCertificate = certificates.firstOrNull { it.courseId == course.id && !it.revoked },
                    studentName = profile?.fullName.orEmpty(),
                    busy = busy,
                    onSaveMissingTripleName = { first, father, family ->
                        viewModel.saveOnboardingProfile(
                            firstName = first,
                            fatherName = father,
                            familyName = family,
                            lang = if (strings.isArabic) "ar" else "en"
                        ) {}
                    },
                    onRetake = {
                        viewModel.clearLatestExamAttempt()
                        subRoute = SubRoute.Exam(course.id)
                    },
                    onClaimCertificate = {
                        viewModel.issueCertificate(course, attempt.scorePercent) { cert ->
                            subRoute = SubRoute.CertificateDetail(cert)
                        }
                    },
                    onViewCertificate = { cert ->
                        subRoute = SubRoute.CertificateDetail(cert)
                    },
                    onBackToCourse = { subRoute = SubRoute.CourseDetail(course.id) }
                )
            } else subRoute = SubRoute.CourseDetail(route.courseId)
            return
        }
        is SubRoute.CertificateDetail -> {
            CertificateDetailScreen(
                strings = strings,
                certificate = route.cert,
                platformConfig = platformConfig,
                onOpenVerifyCode = { code ->
                    viewModel.resetCertVerify()
                    subRoute = SubRoute.CertificateVerify(code)
                },
                onBack = { subRoute = null },
                onFeedback = {}
            )
            return
        }
        is SubRoute.CertificateVerify -> {
            CertificateVerifyScreen(
                strings = strings,
                verifyState = certVerifyState,
                initialCode = route.initialCode,
                onVerify = { viewModel.verifyCertificateCode(it) },
                onBack = {
                    viewModel.resetCertVerify()
                    subRoute = null
                }
            )
            return
        }
        SubRoute.Notifications -> {
            NotificationsScreen(
                strings = strings,
                notifications = notifications,
                onMarkRead = { viewModel.markNotificationRead(it) },
                onBack = { subRoute = null }
            )
            return
        }
        SubRoute.Support -> {
            SupportScreen(
                strings = strings,
                tickets = tickets,
                busy = busy,
                onSubmitTicket = { subj, msg -> viewModel.submitSupportTicket(subj, msg) {} },
                onBack = { subRoute = null }
            )
            return
        }
        null -> Unit
    }

    val navItems = buildList {
        add(Triple(MainTab.HOME, strings.navHome, Icons.Default.Home))
        add(Triple(MainTab.COURSES, strings.navCourses, Icons.Default.MenuBook))
        add(Triple(MainTab.CERTIFICATES, strings.navCertificates, Icons.Default.WorkspacePremium))
        add(Triple(MainTab.PROFILE, strings.navProfile, Icons.Default.Person))
        if (viewModel.isAdmin) {
            add(Triple(MainTab.ADMIN, strings.navAdmin, Icons.Default.AdminPanelSettings))
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (!useRail) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f)) {
                        navItems.forEach { (tab, label, icon) ->
                            NavigationBarItem(
                                selected = currentTab == tab,
                                onClick = { currentTab = tab },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, maxLines = 1) },
                                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                            )
                        }
                    }
                }
            }
        ) { padding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                if (useRail) {
                    NavigationRail(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f)) {
                        navItems.forEach { (tab, label, icon) ->
                            NavigationRailItem(
                                selected = currentTab == tab,
                                onClick = { currentTab = tab },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, maxLines = 1) },
                                modifier = Modifier.testTag("rail_tab_${tab.name.lowercase()}")
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    when (currentTab) {
                        MainTab.HOME -> HomeScreen(
                            strings = strings,
                            darkTheme = darkTheme,
                            profile = profile,
                            fallbackName = viewModel.currentUserDisplayName,
                            config = platformConfig,
                            courses = courses,
                            enrollments = enrollments,
                            progress = progress,
                            payments = payments,
                            certificates = certificates,
                            hasAnnualSubscription = hasAnnualSub,
                            unreadNotificationsCount = unreadCount,
                            onOpenCourse = { c ->
                                viewModel.selectCourse(c.id)
                                subRoute = SubRoute.CourseDetail(c.id)
                            },
                            onBuyCourseDirect = { c ->
                                viewModel.selectCourse(c.id)
                                if (c.paid && c.id !in enrolledIds && !hasAnnualSub && !viewModel.isAdmin) {
                                    subRoute = SubRoute.WePayCheckout(c.id)
                                } else {
                                    subRoute = SubRoute.CourseDetail(c.id)
                                }
                            },
                            onOpenAllCourses = { currentTab = MainTab.COURSES },
                            onOpenNotifications = { subRoute = SubRoute.Notifications },
                            onOpenSupport = { subRoute = SubRoute.Support },
                            onToggleLanguage = { viewModel.toggleLanguage() }
                        )
                        MainTab.COURSES -> CoursesCatalogScreen(
                            strings = strings,
                            courses = courses,
                            enrollments = enrollments,
                            progress = progress,
                            payments = payments,
                            hasAnnualSubscription = hasAnnualSub,
                            onOpenCourse = { c ->
                                viewModel.selectCourse(c.id)
                                subRoute = SubRoute.CourseDetail(c.id)
                            },
                            onBuyCourseDirect = { c ->
                                viewModel.selectCourse(c.id)
                                if (c.paid && c.id !in enrolledIds && !hasAnnualSub && !viewModel.isAdmin) {
                                    subRoute = SubRoute.WePayCheckout(c.id)
                                } else {
                                    subRoute = SubRoute.CourseDetail(c.id)
                                }
                            }
                        )
                        MainTab.CERTIFICATES -> CertificatesScreen(
                            strings = strings,
                            certificates = certificates,
                            onOpenCertificate = { cert -> subRoute = SubRoute.CertificateDetail(cert) },
                            onOpenVerify = { subRoute = SubRoute.CertificateVerify() }
                        )
                        MainTab.PROFILE -> ProfileScreen(
                            strings = strings,
                            profile = profile,
                            fallbackEmail = viewModel.currentUserEmail,
                            fallbackName = viewModel.currentUserDisplayName,
                            darkTheme = darkTheme,
                            unreadNotificationsCount = unreadCount,
                            courses = courses,
                            enrollments = enrollments,
                            progress = progress,
                            certificates = certificates,
                            payments = payments,
                            examAttempts = examAttempts,
                            busy = busy,
                            onSaveProfile = { first, father, family, lang ->
                                viewModel.saveOnboardingProfile(first, father, family, lang) {}
                            },
                            onToggleTheme = { viewModel.toggleDarkTheme() },
                            onToggleLanguage = { viewModel.toggleLanguage() },
                            onOpenCourse = { c ->
                                viewModel.selectCourse(c.id)
                                subRoute = SubRoute.CourseDetail(c.id)
                            },
                            onOpenCertificate = { cert ->
                                subRoute = SubRoute.CertificateDetail(cert)
                            },
                            onOpenNotifications = { subRoute = SubRoute.Notifications },
                            onOpenSupport = { subRoute = SubRoute.Support },
                            onOpenVerifyCertificate = { subRoute = SubRoute.CertificateVerify() },
                            onSignOut = onSignOut
                        )
                        MainTab.ADMIN -> {
                            val strictAdminAllowed = viewModel.isAdmin &&
                                viewModel.currentUserEmail.equals(NexoraRepository.BOOTSTRAP_ADMIN_EMAIL, ignoreCase = true)
                            if (strictAdminAllowed) {
                                AdminPanelScreen(
                                    strings = strings,
                                    courses = courses,
                                    payments = adminPayments,
                                    users = adminUsers,
                                    tickets = adminTickets,
                                    promos = adminPromos,
                                    platformConfig = platformConfig,
                                    selectedCourseLessons = selectedLessons,
                                    videoVerifyResult = videoVerifyResult,
                                    verifyingVideo = verifyingVideo,
                                    aiDraft = aiDraft,
                                    aiGenerating = aiGenerating,
                                    aiUpdatePlan = aiUpdatePlan,
                                    aiUpdatePlanning = aiUpdatePlanning,
                                    busy = busy,
                                    selectedAdminStudentDetail = selectedAdminStudentDetail,
                                    onSelectCourseForLessons = { cid -> viewModel.selectCourse(cid) },
                                    onReviewPayment = { p, ok, note -> viewModel.reviewPayment(p, ok, note) },
                                    onSaveCourse = { viewModel.adminSaveCourse(it) },
                                    onDeleteCourse = { viewModel.adminDeleteCourse(it) },
                                    onVerifyYoutube = { viewModel.verifyYoutubeLink(it) },
                                    onClearVideoVerify = { viewModel.clearVideoVerification() },
                                    onSaveLesson = { viewModel.adminSaveLesson(it) },
                                    onGenerateAiCourse = { t, lvl -> viewModel.generateAiCourse(t, lvl) },
                                    onPublishAiCourse = { paid, price -> viewModel.publishAiCourse(paid, price) },
                                    onClearAiDraft = { viewModel.clearAiDraft() },
                                    onGenerateAiUpdatePlan = { instr -> viewModel.generateAiUpdatePlan(instr) },
                                    onApplyAiUpdatePlan = { viewModel.applyAiUpdatePlan() },
                                    onClearAiUpdatePlan = { viewModel.clearAiUpdatePlan() },
                                    onToggleStudentStatus = { uid, susp -> viewModel.adminToggleStudentStatus(uid, susp) },
                                    onSetAnnualSubscription = { uid, active -> viewModel.adminSetAnnualSubscription(uid, active) },
                                    onCorrectStudentName = { uid, f, m, l, updateCerts ->
                                        viewModel.adminCorrectStudentName(uid, f, m, l, updateCerts)
                                    },
                                    onFetchStudentDetail = { uid -> viewModel.adminFetchStudentDetail(uid) },
                                    onClearStudentDetail = { viewModel.clearAdminStudentDetail() },
                                    onToggleCertificateRevoked = { code, rev -> viewModel.adminToggleCertificateRevoked(code, rev) },
                                    onSavePromo = { code, pct, desc -> viewModel.adminSavePromoCode(code, pct, desc) },
                                    onTogglePromoActive = { code, active -> viewModel.adminTogglePromoActive(code, active) },
                                    onGeneratePromoBatch = { pct, count -> viewModel.adminGeneratePromoBatch(pct, count) },
                                    onSendPromoToStudent = { uid, promo, note -> viewModel.adminSendPromoToStudent(uid, promo, note) },
                                    onReplyTicket = { tid, reply -> viewModel.adminReplyTicket(tid, reply) },
                                    onUpdateConfig = { num, aAr, aEn, oAr, oEn, verifyUrl ->
                                        viewModel.adminUpdatePlatformConfig(num, aAr, aEn, oAr, oEn, verifyUrl)
                                    }
                                )
                            } else {
                                LaunchedEffect(Unit) { currentTab = MainTab.HOME }
                            }
                        }
                    }
                }
            }
        }
    }
}
