const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_student_1";
const BOB_UID = "bob_student_2";
const ADMIN_UID = "heba_admin_uid";
const ADMIN_EMAIL = "heba55nasr@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function pastDate(msOffset = 5000) {
  return new Date(Date.now() - msOffset);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function adminContext() {
  return testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  });
}

async function seedPaidAndFreeCourse(adminDb, now) {
  await assertSucceeds(
    adminDb.collection("courses").doc("programming").set({
      titleAr: "البرمجة",
      titleEn: "Programming",
      descriptionAr: "دورة برمجة متكاملة",
      descriptionEn: "Complete programming course",
      category: "Technology",
      paid: true,
      priceEgp: 150,
      discountPercent: 0,
      thumbnailKey: "programming",
      defaultLang: "ar",
      supportsBilingual: true,
      passingScore: 75,
      published: true,
      lessonCount: 20,
      sortOrder: 1,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    adminDb.collection("courses").doc("programming").collection("lessons").doc("pro_01").set({
      courseId: "programming",
      orderIndex: 1,
      moduleTitleAr: "الأساسيات",
      moduleTitleEn: "Foundations",
      titleAr: "الدرس الأول",
      titleEn: "Lesson 1",
      descriptionAr: "مقدمة",
      descriptionEn: "Intro",
      objectivesAr: "",
      objectivesEn: "",
      durationLabel: "15m",
      defaultLang: "ar",
      freePreview: true,
      videoStatus: "READY",
      published: true,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    adminDb.collection("courses").doc("programming").collection("lesson_videos").doc("pro_01").set({
      courseId: "programming",
      lessonId: "pro_01",
      youtubeIdAr: "rfscVS0vtbw",
      freePreview: true,
      videoStatus: "READY",
      published: true,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    adminDb.collection("courses").doc("programming").collection("lessons").doc("pro_02").set({
      courseId: "programming",
      orderIndex: 2,
      moduleTitleAr: "الأساسيات",
      moduleTitleEn: "Foundations",
      titleAr: "الدرس الثاني",
      titleEn: "Lesson 2",
      descriptionAr: "متقدم",
      descriptionEn: "Paid lesson",
      objectivesAr: "",
      objectivesEn: "",
      durationLabel: "20m",
      defaultLang: "ar",
      freePreview: false,
      videoStatus: "READY",
      published: true,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    adminDb.collection("courses").doc("programming").collection("lesson_videos").doc("pro_02").set({
      courseId: "programming",
      lessonId: "pro_02",
      youtubeIdAr: "kqtD5dpn9C8",
      freePreview: false,
      videoStatus: "READY",
      published: true,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    adminDb.collection("courses").doc("english").set({
      titleAr: "اللغة الإنجليزية",
      titleEn: "English Language",
      descriptionAr: "دورة مجانية",
      descriptionEn: "Free course",
      category: "Languages",
      paid: false,
      priceEgp: 0,
      discountPercent: 0,
      thumbnailKey: "english",
      defaultLang: "en",
      supportsBilingual: false,
      passingScore: 75,
      published: true,
      lessonCount: 20,
      sortOrder: 5,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    adminDb.collection("courses").doc("english").collection("lesson_videos").doc("eng_01").set({
      courseId: "english",
      lessonId: "eng_01",
      youtubeIdEn: "dQw4w9WgXcQ",
      freePreview: false,
      videoStatus: "READY",
      published: true,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    adminDb.collection("courses").doc("cybersecurity").set({
      titleAr: "الأمن السيبراني",
      titleEn: "Cybersecurity",
      descriptionAr: "أمن سيبراني",
      descriptionEn: "Cybersecurity course",
      category: "Security",
      paid: true,
      priceEgp: 150,
      discountPercent: 0,
      thumbnailKey: "cybersecurity",
      defaultLang: "en",
      supportsBilingual: false,
      passingScore: 75,
      published: true,
      lessonCount: 20,
      sortOrder: 4,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    adminDb.collection("courses").doc("cybersecurity").collection("lesson_videos").doc("cyb_01").set({
      courseId: "cybersecurity",
      lessonId: "cyb_01",
      youtubeIdEn: "4t4kBkMsDbQ",
      freePreview: false,
      videoStatus: "READY",
      published: true,
      updatedAt: now,
    })
  );
}

test("Unauthenticated users cannot read private collections or list certificates, only verify by exact code", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("courses").where("published", "==", true).get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("payments").where("userId", "==", ALICE_UID).get());
  await assertFails(unauthDb.collection("certificates").get());
  await assertSucceeds(unauthDb.collection("certificates").doc("NX-2026-000001").get());
});

test("User profile isolation, 3-part name updates, and privilege escalation prevention", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: "bob@example.com", email_verified: true }).firestore();
  const now = pastDate();

  // Student creates own profile with 3-part name, role STUDENT, subscriptionPlan NONE
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      firstName: "Alice",
      fatherName: "Mohamed",
      familyName: "Hassan",
      fullName: "Alice Mohamed Hassan",
      email: "alice@example.com",
      preferredLang: "ar",
      accountStatus: "ACTIVE",
      role: "STUDENT",
      subscriptionPlan: "NONE",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Student cannot self-assign ADMIN role or ANNUAL subscription on create
  await assertFails(
    bobDb.collection("users").doc(BOB_UID).set({
      userId: BOB_UID,
      fullName: "Bob Samir Ibrahim",
      email: "bob@example.com",
      preferredLang: "en",
      accountStatus: "ACTIVE",
      role: "ADMIN",
      subscriptionPlan: "NONE",
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(
    bobDb.collection("users").doc(BOB_UID).set({
      userId: BOB_UID,
      fullName: "Bob Samir Ibrahim",
      email: "bob@example.com",
      preferredLang: "en",
      accountStatus: "ACTIVE",
      role: "STUDENT",
      subscriptionPlan: "ANNUAL",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Bob cannot read Alice's profile or list users
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").get());

  // Alice can update allowed 3-part name & lang fields while preserving role/subscriptionPlan
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      firstName: "Alice",
      fatherName: "Tarek",
      familyName: "Hassan",
      fullName: "Alice Tarek Hassan",
      preferredLang: "en",
      updatedAt: pastDate(1000),
    })
  );

  // Alice cannot escalate role or subscriptionPlan on update
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      role: "ADMIN",
      updatedAt: pastDate(1000),
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      subscriptionPlan: "ANNUAL",
      updatedAt: pastDate(1000),
    })
  );
});

test("Email spoofing or other emails cannot gain Admin access — only verified heba55nasr@gmail.com", async () => {
  const spoofDb = testEnv.authenticatedContext("spoof_uid", {
    email: ADMIN_EMAIL,
    email_verified: false,
  }).firestore();
  const otherDb = testEnv.authenticatedContext("other_uid", {
    email: "other@example.com",
    email_verified: true,
  }).firestore();

  const coursePayload = {
    titleAr: "البرمجة",
    titleEn: "Programming",
    descriptionAr: "وصف",
    descriptionEn: "Desc",
    category: "Tech",
    paid: true,
    priceEgp: 150,
    discountPercent: 0,
    thumbnailKey: "programming",
    defaultLang: "ar",
    supportsBilingual: true,
    passingScore: 75,
    published: true,
    lessonCount: 20,
    sortOrder: 1,
    createdAt: pastDate(),
    updatedAt: pastDate(),
  };

  await assertFails(spoofDb.collection("courses").doc("programming").set(coursePayload));
  await assertFails(otherDb.collection("courses").doc("programming").set(coursePayload));
});

test("Zero-trust paid course protection, free course & free preview access, WE Pay verification, and cross-course/student isolation", async () => {
  const adminDb = adminContext().firestore();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: "bob@example.com", email_verified: true }).firestore();
  const now = pastDate();

  await seedPaidAndFreeCourse(adminDb, now);

  // Student queries published courses cleanly; unfiltered list denied
  await assertSucceeds(aliceDb.collection("courses").where("published", "==", true).get());
  await assertFails(aliceDb.collection("courses").get());

  // Scenario 1: Free course video is readable immediately WITHOUT enrollment or payment
  await assertSucceeds(aliceDb.collection("courses").doc("english").collection("lesson_videos").doc("eng_01").get());

  // Scenario 2: Student can read curriculum metadata, plus FREE PREVIEW lesson video, but CANNOT read locked paid video
  await assertSucceeds(aliceDb.collection("courses").doc("programming").collection("lessons").where("published", "==", true).get());
  await assertSucceeds(aliceDb.collection("courses").doc("programming").collection("lesson_videos").doc("pro_01").get());
  await assertFails(aliceDb.collection("courses").doc("programming").collection("lesson_videos").doc("pro_02").get());

  // Student can self-enroll in FREE course
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("enrollments").doc("english").set({
      userId: ALICE_UID,
      courseId: "english",
      accessType: "FREE",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Student CANNOT self-enroll in PAID course
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("enrollments").doc("programming").set({
      userId: ALICE_UID,
      courseId: "programming",
      accessType: "PAID_APPROVED",
      paymentId: "pay_fake_1",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Tampered frontend payment price MUST fail server validation
  await assertFails(
    aliceDb.collection("payments").doc("pay_tampered").set({
      userId: ALICE_UID,
      studentName: "Alice Mohamed Hassan",
      studentEmail: "alice@example.com",
      courseId: "programming",
      courseTitle: "Programming",
      amountEgp: 1,
      originalPriceEgp: 150,
      paymentMethod: "WE Pay",
      transferNumber: "01557701433",
      senderPhone: "01550001122",
      transactionRef: "WE-TAMPER",
      status: "PENDING",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Student submits valid PENDING WE Pay request (receipt optional)
  await assertSucceeds(
    aliceDb.collection("payments").doc("pay_1").set({
      userId: ALICE_UID,
      studentName: "Alice Mohamed Hassan",
      studentEmail: "alice@example.com",
      courseId: "programming",
      courseTitle: "Programming",
      amountEgp: 150,
      originalPriceEgp: 150,
      targetLessonId: "pro_02",
      paymentMethod: "WE Pay",
      transferNumber: "01557701433",
      senderPhone: "01550001122",
      transactionRef: "WE-998811",
      status: "PENDING",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Scenario 3: While PENDING, locked lesson video MUST stay locked and student CANNOT write progress or self-approve
  await assertFails(aliceDb.collection("courses").doc("programming").collection("lesson_videos").doc("pro_02").get());
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("progress").doc("pro_02").set({
      userId: ALICE_UID,
      courseId: "programming",
      lessonId: "pro_02",
      completed: true,
      watchedSeconds: 0,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(
    aliceDb.collection("payments").doc("pay_1").update({
      status: "APPROVED",
      updatedAt: pastDate(1000),
    })
  );

  // Bob cannot view Alice's payment
  await assertFails(bobDb.collection("payments").doc("pay_1").get());

  // Scenario 4: Admin approves payment and creates PAID_APPROVED enrollment; payments cannot be deleted
  await assertSucceeds(
    adminDb.collection("payments").doc("pay_1").update({
      status: "APPROVED",
      adminNote: "Verified WE Pay transfer",
      reviewedBy: ADMIN_UID,
      updatedAt: pastDate(1000),
    })
  );
  await assertSucceeds(
    adminDb.collection("users").doc(ALICE_UID).collection("enrollments").doc("programming").set({
      userId: ALICE_UID,
      courseId: "programming",
      accessType: "PAID_APPROVED",
      paymentId: "pay_1",
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(adminDb.collection("payments").doc("pay_1").delete());

  // Scenarios 5 & 6: Now Alice CAN read locked lesson videos in Programming & record progress, while Bob STILL CANNOT!
  await assertSucceeds(aliceDb.collection("courses").doc("programming").collection("lesson_videos").doc("pro_01").get());
  await assertSucceeds(aliceDb.collection("courses").doc("programming").collection("lesson_videos").doc("pro_02").get());
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("progress").doc("pro_02").set({
      userId: ALICE_UID,
      courseId: "programming",
      lessonId: "pro_02",
      completed: true,
      watchedSeconds: 0,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(bobDb.collection("courses").doc("programming").collection("lesson_videos").doc("pro_02").get());

  // Scenario 7: Alice CANNOT read a different paid course she has not purchased (cybersecurity)
  await assertFails(aliceDb.collection("courses").doc("cybersecurity").collection("lesson_videos").doc("cyb_01").get());
});

test("Active Annual Subscription unlocks paid courses for holder only", async () => {
  const adminDb = adminContext().firestore();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: "bob@example.com", email_verified: true }).firestore();
  const now = pastDate();

  await seedPaidAndFreeCourse(adminDb, now);

  await assertSucceeds(
    bobDb.collection("users").doc(BOB_UID).set({
      userId: BOB_UID,
      firstName: "Bob",
      fatherName: "Samir",
      familyName: "Ibrahim",
      fullName: "Bob Samir Ibrahim",
      email: "bob@example.com",
      preferredLang: "en",
      accountStatus: "ACTIVE",
      role: "STUDENT",
      subscriptionPlan: "NONE",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Before annual pass, Bob cannot access locked video
  await assertFails(bobDb.collection("courses").doc("programming").collection("lesson_videos").doc("pro_02").get());

  // Admin grants Annual Subscription to Bob
  await assertSucceeds(
    adminDb.collection("users").doc(BOB_UID).update({
      subscriptionPlan: "ANNUAL",
      updatedAt: pastDate(1000),
    })
  );

  // Bob now accesses paid lesson_video; Alice (unpaid) still fails
  await assertSucceeds(bobDb.collection("courses").doc("programming").collection("lesson_videos").doc("pro_02").get());
  await assertFails(aliceDb.collection("courses").doc("programming").collection("lesson_videos").doc("pro_02").get());
});

test("Certificates enforce course access, passing score >= 75, distinct 3-part names, and public code lookup", async () => {
  const adminDb = adminContext().firestore();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: "bob@example.com", email_verified: true }).firestore();
  const now = pastDate();

  await seedPaidAndFreeCourse(adminDb, now);

  // Unenrolled student CANNOT issue certificate for paid course even with >= 75 score
  await assertFails(
    aliceDb.collection("certificates").doc("NX-2026-PRO-NOACC").set({
      userId: ALICE_UID,
      courseId: "programming",
      studentName: "Alice Mohamed Hassan",
      courseTitleAr: "البرمجة",
      courseTitleEn: "Programming",
      certificateCode: "NX-2026-PRO-NOACC",
      scorePercent: 95,
      issuedDateLabel: "2026-11-26",
      issuerName: "NEXORA by HEBA NASR",
      revoked: false,
      createdAt: now,
    })
  );

  // Score < 75 fails even on free course
  await assertFails(
    aliceDb.collection("certificates").doc("NX-2026-LOW70").set({
      userId: ALICE_UID,
      courseId: "english",
      studentName: "Alice Mohamed Hassan",
      courseTitleAr: "اللغة الإنجليزية",
      courseTitleEn: "English Language",
      certificateCode: "NX-2026-LOW70",
      scorePercent: 70,
      issuedDateLabel: "2026-11-26",
      issuerName: "NEXORA by HEBA NASR",
      revoked: false,
      createdAt: now,
    })
  );

  // Two different students issue certificates with their own 3-part full names
  await assertSucceeds(
    aliceDb.collection("certificates").doc("NX-2026-PASS90").set({
      userId: ALICE_UID,
      courseId: "english",
      studentName: "Alice Mohamed Hassan",
      courseTitleAr: "اللغة الإنجليزية",
      courseTitleEn: "English Language",
      certificateCode: "NX-2026-PASS90",
      scorePercent: 90,
      issuedDateLabel: "2026-11-26",
      issuerName: "NEXORA by HEBA NASR",
      revoked: false,
      createdAt: now,
    })
  );
  await assertSucceeds(
    bobDb.collection("certificates").doc("NX-2026-BOB88").set({
      userId: BOB_UID,
      courseId: "english",
      studentName: "Bob Samir Ibrahim",
      courseTitleAr: "اللغة الإنجليزية",
      courseTitleEn: "English Language",
      certificateCode: "NX-2026-BOB88",
      scorePercent: 88,
      issuedDateLabel: "2026-11-26",
      issuerName: "NEXORA by HEBA NASR",
      revoked: false,
      createdAt: now,
    })
  );

  // Verification lookup by exact code succeeds (both unauthenticated browser and signed-in); listing fails for non-admin
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertSucceeds(unauthDb.collection("certificates").doc("NX-2026-PASS90").get());
  await assertSucceeds(bobDb.collection("certificates").doc("NX-2026-PASS90").get());
  await assertFails(bobDb.collection("certificates").get());
  await assertFails(unauthDb.collection("certificates").get());
});

test("Sequential certificate_counters allow strict +1 atomic increment per year and block jumps or deletions", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: "bob@example.com", email_verified: true }).firestore();
  const counterRefAlice = aliceDb.collection("certificate_counters").doc("2026");
  const counterRefBob = bobDb.collection("certificate_counters").doc("2026");

  // Cannot start counter at 5
  await assertFails(counterRefAlice.set({ year: 2026, lastSeq: 5, updatedAt: pastDate() }));

  // First student creates year counter at 1
  await assertSucceeds(counterRefAlice.set({ year: 2026, lastSeq: 1, updatedAt: pastDate() }));

  // Second student increments strictly +1 to 2
  await assertSucceeds(counterRefBob.update({ year: 2026, lastSeq: 2, updatedAt: pastDate(1000) }));

  // Skipping numbers or resetting counter fails
  await assertFails(counterRefBob.update({ year: 2026, lastSeq: 4, updatedAt: pastDate(500) }));
  await assertFails(counterRefAlice.update({ year: 2026, lastSeq: 1, updatedAt: pastDate(500) }));
  await assertFails(counterRefAlice.delete());
});
